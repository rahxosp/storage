# Real-ESRGAN CUDA - Quick Reference

## 🎯 What You Have

**GPU-accelerated image upscaling** (2x, 3x, 4x) using NVIDIA RTX 3060 with CUDA.

## 📍 Server Access

```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 30714 root@112.82.115.178
cd ~/esrgan-cuda/Real-ESRGAN
```

## ⚡ Quick Commands

```bash
# Easy mode (helper script)
./upscale.sh inputs/your_image.jpg

# Anime/illustration
./upscale.sh inputs/anime.png RealESRGAN_x4plus_anime_6B

# Custom scale (2x instead of 4x)
./upscale.sh inputs/image.jpg RealESRGAN_x4plus 2

# Advanced mode (full control)
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/ --outscale 4 --fp32
```

## 📤 File Transfer

**Upload:**
```powershell
scp -i "C:\Users\AJU\.ssh\vast" -P 30714 "C:\path\to\image.jpg" root@112.82.115.178:/root/esrgan-cuda/Real-ESRGAN/inputs/
```

**Download:**
```powershell
scp -i "C:\Users\AJU\.ssh\vast" -P 30714 root@112.82.115.178:/root/esrgan-cuda/Real-ESRGAN/results/image_out.jpg "C:\Downloads\"
```

## 📚 Documentation

- **Installation Complete:** `INSTALLATION-COMPLETE.md`
- **Full Setup Guide:** `ESRGAN-CUDA-SETUP.md`
- **Vulkan Setup:** `vulkan-setup-headless.md` (backup method)

## ✅ Status

- CUDA: Working ✅
- GPU: NVIDIA GeForce RTX 3060 ✅
- Models: 2 pre-trained (82MB) ✅
- Test: 4x upscale successful ✅

---

**That's it!** Upload images to `inputs/`, run `./upscale.sh`, get results in `results/`.
