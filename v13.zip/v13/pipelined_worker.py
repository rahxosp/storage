#!/usr/bin/env python3
"""
Pipelined ESRGAN Worker - Optimized for Maximum GPU Utilization
This worker overlaps I/O operations with GPU processing using a pipeline approach:
- Downloads next job while GPU processes current job
- Uploads results in background while processing next job
- Uses separate thread pools for I/O and CPU operations
"""

import os
import sys
import time
import threading
import queue
from typing import Dict, Optional, Tuple, Any
from concurrent.futures import ThreadPoolExecutor, Future
from dataclasses import dataclass
from enum import Enum

from improved_config import (
    WorkerConfig, QueueConfig, PerformanceConfig, 
    GRACEFUL_KILLER, logger
)
from improved_storage import (
    EnhancedRedisManager, EnhancedS3Manager,
    EnhancedWorkerRegistry, EnhancedJobManager
)
from worker import EnhancedWorker, WorkerState, JobMetrics

@dataclass
class PipelineStage:
    """Represents a job at a specific pipeline stage"""
    job_uuid: str
    job_data: Dict[str, Any]
    event_queue: str
    stage: str  # 'downloading', 'processing', 'uploading'
    data: Any = None  # Stage-specific data
    start_time: float = 0.0

class PipelineWorker(EnhancedWorker):
    """
    Enhanced worker with pipelined processing for maximum GPU utilization.
    
    Pipeline stages:
    1. Download stage: Fetch image from S3 (I/O thread pool)
    2. Processing stage: ESRGAN GPU processing (main thread)
    3. Upload stage: Upload variants to S3 (I/O thread pool)
    
    The worker maintains up to 3 jobs in different stages simultaneously.
    """
    
    def __init__(self):
        super().__init__()
        
        # Pipeline queues
        self.download_queue = queue.Queue(maxsize=2)  # Pre-fetch buffer
        self.processing_queue = queue.Queue(maxsize=1)  # GPU queue
        self.upload_queue = queue.Queue(maxsize=3)  # Upload buffer
        
        # Separate thread pools for different operations
        self.io_pool = ThreadPoolExecutor(
            max_workers=WorkerConfig.THREAD_POOL_SIZE,
            thread_name_prefix="io-worker"
        )
        self.cpu_pool = ThreadPoolExecutor(
            max_workers=WorkerConfig.THREAD_POOL_SIZE,
            thread_name_prefix="cpu-worker"
        )
        
        # Pipeline metrics
        self.pipeline_metrics = {
            'downloads_active': 0,
            'processing_active': 0,
            'uploads_active': 0,
            'download_time': 0.0,
            'gpu_time': 0.0,
            'upload_time': 0.0,
            'total_pipeline_time': 0.0
        }
        
        # Pipeline control
        self.pipeline_lock = threading.Lock()
        self.pipeline_active = False
        
        logger.info("🚀 Pipelined Worker initialized with overlapping I/O and GPU processing")
    
    def download_and_prepare_job(self, job_data: Dict, job_uuid: str) -> Optional[Dict]:
        """
        Stage 1: Download and prepare image for processing
        This runs in I/O thread pool while GPU processes another job
        """
        from esrgan_processor import ESRGANProcessor
        from utils import temporary_file, parse_s3_path, validate_image, convert_image_format
        
        download_start = time.time()
        s3_path = job_data.get('s3Original', '')
        
        try:
            # Parse S3 path
            parsed = parse_s3_path(s3_path)
            if not parsed:
                logger.error(f"❌ Job {job_uuid}: Could not parse S3 path")
                return None
            
            # Download to temporary file
            with temporary_file(suffix='.tmp') as temp_input:
                logger.info(f"⬇️  [{job_uuid}] Downloading from S3...")
                if not self.s3_manager.download_file_with_retry(s3_path, temp_input):
                    logger.error(f"❌ Job {job_uuid}: Download failed")
                    return None
                
                # Validate image
                is_valid, error_msg, needs_split = validate_image(temp_input)
                if not is_valid:
                    logger.error(f"❌ Job {job_uuid}: Invalid image - {error_msg}")
                    return None
                
                # Convert to PNG for ESRGAN
                with temporary_file(suffix='.png') as temp_png:
                    if not convert_image_format(temp_input, temp_png):
                        logger.error(f"❌ Job {job_uuid}: Conversion failed")
                        return None
                    
                    # Read file into memory to release temp file
                    with open(temp_png, 'rb') as f:
                        png_data = f.read()
            
            download_time = time.time() - download_start
            with self.pipeline_lock:
                self.pipeline_metrics['download_time'] += download_time
            
            logger.info(f"✅ [{job_uuid}] Downloaded and prepared in {download_time:.2f}s")
            
            return {
                'job_uuid': job_uuid,
                'job_data': job_data,
                'parsed': parsed,
                'png_data': png_data,
                'needs_split': needs_split
            }
            
        except Exception as e:
            logger.error(f"❌ Download stage error for {job_uuid}: {e}")
            return None
    
    def process_with_gpu(self, prepared_data: Dict) -> Optional[Dict]:
        """
        Stage 2: GPU processing with ESRGAN
        This is the critical path - we want GPU always busy
        """
        from esrgan_processor import ESRGANProcessor, VariantProcessor
        from utils import temporary_file
        import psutil
        
        gpu_start = time.time()
        job_uuid = prepared_data['job_uuid']
        job_data = prepared_data['job_data']
        parsed = prepared_data['parsed']
        png_data = prepared_data['png_data']
        variants = job_data.get('variants', ['hd', 'sd', 'ds'])
        
        try:
            # Write PNG data to temp file for ESRGAN
            with temporary_file(suffix='.png') as temp_png:
                with open(temp_png, 'wb') as f:
                    f.write(png_data)
                
                logger.info(f"🎮 [{job_uuid}] Starting GPU processing...")
                
                # Run ESRGAN upscaling (GPU-bound operation)
                esrgan_processor = ESRGANProcessor(self.s3_manager)
                with temporary_file(suffix='.png') as temp_upscaled:
                    if not esrgan_processor.run_esrgan_with_fallback(temp_png, temp_upscaled):
                        logger.error(f"❌ Job {job_uuid}: ESRGAN failed")
                        return None
                    
                    logger.info(f"✅ [{job_uuid}] GPU upscaling completed")
                    
                    # Determine resource state
                    memory = psutil.virtual_memory()
                    if memory.percent > 90:
                        resource_state = 'CRITICAL'
                    elif memory.percent > 80:
                        resource_state = 'HIGH'
                    else:
                        resource_state = 'NORMAL'
                    
                    # Process variants (CPU-bound, run in separate pool)
                    variant_processor = VariantProcessor(self.s3_manager)
                    variant_results = variant_processor.process_variants_parallel(
                        temp_upscaled, parsed, variants, resource_state
                    )
                    
                    if not variant_results:
                        logger.error(f"❌ Job {job_uuid}: Variant processing failed")
                        return None
            
            gpu_time = time.time() - gpu_start
            with self.pipeline_lock:
                self.pipeline_metrics['gpu_time'] += gpu_time
            
            logger.info(f"✅ [{job_uuid}] GPU + variants completed in {gpu_time:.2f}s")
            
            return {
                'job_uuid': job_uuid,
                'job_data': job_data,
                'variant_results': variant_results,
                'resource_state': resource_state,
                'processing_time': gpu_time
            }
            
        except Exception as e:
            logger.error(f"❌ GPU processing error for {job_uuid}: {e}")
            return None
    
    def upload_results_background(self, result_data: Dict, event_queue: str):
        """
        Stage 3: Upload results in background
        This runs in I/O thread pool while GPU processes next job
        """
        upload_start = time.time()
        job_uuid = result_data['job_uuid']
        
        try:
            # Note: Variants are already uploaded by process_variants_parallel
            # This stage handles result reporting
            
            job_data = result_data['job_data']
            s3_path = job_data.get('s3Original', '')
            
            result = {
                'status': 'completed',
                'jobUuid': job_uuid,
                'chapterId': job_data.get('chapterId', 0),
                'pageIndex': job_data.get('pageIndex', 0),
                's3Original': s3_path,
                'paths': result_data['variant_results'],
                'processing_time': result_data['processing_time'],
                'worker_id': self.worker_id,
                'resource_state': result_data['resource_state']
            }
            
            # Handle job result (send event, store outcome)
            self.handle_job_result(job_uuid, result, event_queue)
            
            upload_time = time.time() - upload_start
            with self.pipeline_lock:
                self.pipeline_metrics['upload_time'] += upload_time
            
            logger.info(f"📤 [{job_uuid}] Results uploaded in {upload_time:.2f}s")
            
        except Exception as e:
            logger.error(f"❌ Upload stage error for {job_uuid}: {e}")
    
    def process_job_pipelined(self, source_queue: str, job_data: Dict) -> bool:
        """
        Process job using pipelined approach with overlapping I/O and GPU
        """
        job_uuid = job_data.get('jobUuid', 'unknown')
        event_queue = self.determine_event_queue(source_queue)
        pipeline_start = time.time()
        
        try:
            # Claim job
            if not self.job_manager.claim_job(job_uuid):
                logger.info(f"🔒 Job {job_uuid} already claimed")
                return False
            
            GRACEFUL_KILLER.add_job(job_uuid)
            
            # Stage 1: Download and prepare (can run in background)
            logger.info(f"📥 [{job_uuid}] Starting download stage...")
            prepared_data = self.download_and_prepare_job(job_data, job_uuid)
            
            if not prepared_data:
                self.handle_failed_job(job_uuid, job_data, "Download/preparation failed", event_queue)
                return False
            
            # Stage 2: GPU processing (critical path)
            result_data = self.process_with_gpu(prepared_data)
            
            if not result_data:
                self.handle_failed_job(job_uuid, job_data, "GPU processing failed", event_queue)
                return False
            
            # Stage 3: Upload results (can run in background)
            # For now run synchronously, but this could be async with proper job tracking
            self.upload_results_background(result_data, event_queue)
            
            pipeline_time = time.time() - pipeline_start
            with self.pipeline_lock:
                self.pipeline_metrics['total_pipeline_time'] += pipeline_time
            
            logger.info(f"✅ [{job_uuid}] Complete pipeline: {pipeline_time:.2f}s")
            return True
            
        except Exception as e:
            logger.error(f"❌ Pipeline error for {job_uuid}: {e}")
            self.handle_failed_job(job_uuid, job_data, str(e), event_queue)
            return False
            
        finally:
            GRACEFUL_KILLER.remove_job(job_uuid)
            self.job_manager.release_job_lock(job_uuid)
    
    def handle_failed_job(self, job_uuid: str, job_data: Dict, error: str, event_queue: str):
        """Handle job failure"""
        result = {
            'status': 'failed',
            'jobUuid': job_uuid,
            'chapterId': job_data.get('chapterId', 0),
            'pageIndex': job_data.get('pageIndex', 0),
            's3Original': job_data.get('s3Original', ''),
            'error': error,
            'worker_id': self.worker_id
        }
        self.handle_job_result(job_uuid, result, event_queue)
    
    def run(self) -> bool:
        """
        Main worker loop with pipelined processing
        """
        logger.info(f"🚀 Starting Pipelined ESRGAN Worker v{WorkerConfig.WORKER_VERSION}")
        
        try:
            # Initialize all managers
            if not self.initialize_managers():
                logger.error("❌ Failed to initialize worker")
                return False
            
            self.state = WorkerState.IDLE
            self.pipeline_active = True
            logger.info("🏃 Pipelined worker ready - overlapping I/O with GPU processing")
            
            # Main processing loop
            last_heartbeat = 0
            no_job_count = 0
            
            while not GRACEFUL_KILLER.kill_now:
                try:
                    current_time = time.time()
                    
                    # Health check
                    if not self.health_check():
                        logger.error("❌ Health check failed")
                        break
                    
                    # Heartbeat
                    if current_time - last_heartbeat > WorkerConfig.REGISTRATION_TTL / 2:
                        self.register_heartbeat()
                        last_heartbeat = current_time
                    
                    # Check for shutdown
                    if GRACEFUL_KILLER.kill_now:
                        logger.info("🛑 Graceful shutdown requested")
                        break
                    
                    # Get next job
                    job_result = self.get_job_from_queue(timeout=5)
                    
                    if job_result is None:
                        no_job_count += 1
                        if no_job_count % 12 == 0:  # Every minute
                            self.log_pipeline_metrics()
                        continue
                    
                    no_job_count = 0
                    source_queue, job_data = job_result
                    
                    # Process with pipeline
                    self.state = WorkerState.PROCESSING
                    self.process_job_pipelined(source_queue, job_data)
                    self.state = WorkerState.IDLE
                    
                except KeyboardInterrupt:
                    logger.info("⌨️ Keyboard interrupt")
                    GRACEFUL_KILLER.kill_now = True
                    break
                    
                except Exception as e:
                    logger.error(f"❌ Error in main loop: {e}")
                    time.sleep(2)
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Fatal error: {e}")
            return False
            
        finally:
            self.pipeline_active = False
            self.cleanup_resources()
            if self.io_pool:
                self.io_pool.shutdown(wait=True)
            if self.cpu_pool:
                self.cpu_pool.shutdown(wait=True)
            logger.info("👋 Pipelined worker shutdown complete")
    
    def log_pipeline_metrics(self):
        """Log pipeline-specific metrics"""
        with self.pipeline_lock:
            metrics = self.pipeline_metrics.copy()
        
        total_jobs = self.job_metrics.total_processed + self.job_metrics.total_failed
        if total_jobs > 0:
            avg_download = metrics['download_time'] / total_jobs
            avg_gpu = metrics['gpu_time'] / total_jobs
            avg_upload = metrics['upload_time'] / total_jobs
            avg_total = metrics['total_pipeline_time'] / total_jobs
            
            logger.info(f"📊 Pipeline Metrics ({total_jobs} jobs)")
            logger.info(f"   Avg Download:  {avg_download:.2f}s")
            logger.info(f"   Avg GPU:       {avg_gpu:.2f}s")
            logger.info(f"   Avg Upload:    {avg_upload:.2f}s")
            logger.info(f"   Avg Total:     {avg_total:.2f}s")
            logger.info(f"   GPU Util:      {(avg_gpu/avg_total)*100:.1f}%")
            
        self.log_metrics()

def main():
    """Main entry point"""
    exit_code = 0
    
    try:
        worker = PipelineWorker()
        success = worker.run()
        exit_code = 0 if success else 1
        
    except KeyboardInterrupt:
        logger.info("⌨️ Keyboard interrupt - shutting down...")
        exit_code = 0
        
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        exit_code = 1
    
    finally:
        logger.info(f"🔚 Pipelined worker exiting with code {exit_code}")
        sys.exit(exit_code)

if __name__ == "__main__":
    main()
