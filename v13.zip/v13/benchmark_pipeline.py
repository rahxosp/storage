#!/usr/bin/env python3
"""
Benchmark script to compare sequential vs pipelined processing.
Simulates the pipeline with timing analysis.
"""

import time
import random
from typing import List, Dict

class PipelineBenchmark:
    """Simulates and compares different processing approaches"""
    
    def __init__(self, num_jobs: int = 10):
        self.num_jobs = num_jobs
        
        # Simulated timing (seconds) - adjust based on your observations
        self.download_time = 3.0
        self.gpu_time = 10.0
        self.upload_time = 2.0
        
        print(f"🔧 Benchmark Configuration:")
        print(f"   Jobs to process: {num_jobs}")
        print(f"   Download time: {self.download_time}s")
        print(f"   GPU time: {self.gpu_time}s")
        print(f"   Upload time: {self.upload_time}s")
        print(f"   Sequential time per job: {self.download_time + self.gpu_time + self.upload_time}s")
        print()
    
    def simulate_sequential(self) -> Dict:
        """Simulate current sequential processing"""
        print("📊 Simulating Sequential Processing...")
        start = time.time()
        
        total_download = 0
        total_gpu = 0
        total_upload = 0
        gpu_active_time = 0
        
        for i in range(self.num_jobs):
            # Download
            time.sleep(0.01)  # Small delay for simulation
            total_download += self.download_time
            
            # GPU processing
            time.sleep(0.01)
            total_gpu += self.gpu_time
            gpu_active_time += self.gpu_time
            
            # Upload
            time.sleep(0.01)
            total_upload += self.upload_time
        
        elapsed = time.time() - start
        wall_time = total_download + total_gpu + total_upload
        
        return {
            'type': 'Sequential',
            'wall_time': wall_time,
            'simulation_time': elapsed,
            'total_download': total_download,
            'total_gpu': total_gpu,
            'total_upload': total_upload,
            'gpu_active': gpu_active_time,
            'gpu_util': (gpu_active_time / wall_time * 100),
            'jobs_per_hour': (self.num_jobs / wall_time * 3600),
        }
    
    def simulate_pipelined(self) -> Dict:
        """Simulate pipelined processing with overlapping I/O and GPU"""
        print("📊 Simulating Concurrent Pipeline Processing...")
        start = time.time()
        
        # Pipeline simulation
        # At any time: downloading job N+1, processing job N, uploading job N-1
        
        total_download = self.num_jobs * self.download_time
        total_gpu = self.num_jobs * self.gpu_time
        total_upload = self.num_jobs * self.upload_time
        
        # Calculate wall time with overlapping
        # The bottleneck is GPU since it's the longest operation
        # Overhead is the first download and last upload (can't overlap)
        
        # Initial download (first job)
        wall_time = self.download_time
        
        # Main pipeline: GPU is the bottleneck, others overlap
        # Each subsequent job only adds GPU time (others overlap)
        wall_time += (self.num_jobs - 1) * self.gpu_time
        
        # Add small gaps between jobs (startup/teardown)
        gap_per_job = 0.1
        wall_time += self.num_jobs * gap_per_job
        
        # Final upload (last job)
        wall_time += self.upload_time
        
        gpu_active_time = total_gpu
        elapsed = time.time() - start
        
        return {
            'type': 'Concurrent Pipeline',
            'wall_time': wall_time,
            'simulation_time': elapsed,
            'total_download': total_download,
            'total_gpu': total_gpu,
            'total_upload': total_upload,
            'gpu_active': gpu_active_time,
            'gpu_util': (gpu_active_time / wall_time * 100),
            'jobs_per_hour': (self.num_jobs / wall_time * 3600),
        }
    
    def print_results(self, seq_results: Dict, pipe_results: Dict):
        """Print comparison results"""
        print("\n" + "="*70)
        print("📊 BENCHMARK RESULTS")
        print("="*70)
        
        print(f"\n{'Metric':<25} {'Sequential':<20} {'Pipeline':<20} {'Improvement':<15}")
        print("-"*70)
        
        # Wall time
        seq_time = seq_results['wall_time']
        pipe_time = pipe_results['wall_time']
        time_saved = seq_time - pipe_time
        improvement = (time_saved / seq_time * 100)
        print(f"{'Total Time':<25} {seq_time:>8.1f}s {pipe_time:>18.1f}s {improvement:>13.1f}%")
        
        # Time per job
        seq_per = seq_time / self.num_jobs
        pipe_per = pipe_time / self.num_jobs
        print(f"{'Time per Job':<25} {seq_per:>8.1f}s {pipe_per:>18.1f}s")
        
        # GPU utilization
        seq_util = seq_results['gpu_util']
        pipe_util = pipe_results['gpu_util']
        util_gain = pipe_util - seq_util
        print(f"{'GPU Utilization':<25} {seq_util:>8.1f}% {pipe_util:>18.1f}% {util_gain:>13.1f}%")
        
        # Throughput
        seq_throughput = seq_results['jobs_per_hour']
        pipe_throughput = pipe_results['jobs_per_hour']
        throughput_gain = ((pipe_throughput - seq_throughput) / seq_throughput * 100)
        print(f"{'Throughput (jobs/hr)':<25} {seq_throughput:>8.0f} {pipe_throughput:>18.0f} {throughput_gain:>13.1f}%")
        
        # Speedup
        speedup = seq_time / pipe_time
        print(f"{'Speedup':<25} {'1.00x':>8} {speedup:>18.2f}x")
        
        print("\n" + "-"*70)
        print("Stage Breakdown:")
        print("-"*70)
        
        for stage in ['Download', 'GPU', 'Upload']:
            key = f'total_{stage.lower()}'
            seq_val = seq_results.get(key, 0)
            pipe_val = pipe_results.get(key, 0)
            print(f"{stage + ' Time':<25} {seq_val:>8.1f}s {pipe_val:>18.1f}s")
        
        print("\n" + "="*70)
        print("💡 ANALYSIS")
        print("="*70)
        
        # Calculate time savings for different scales
        print(f"\nTime savings at different scales:")
        for scale in [100, 1000, 10000]:
            seq_total = (seq_time / self.num_jobs) * scale
            pipe_total = (pipe_time / self.num_jobs) * scale
            saved = seq_total - pipe_total
            saved_hours = saved / 3600
            
            print(f"  {scale:>5} images: {saved_hours:>6.1f} hours saved ({saved/60:>6.1f} minutes)")
        
        print(f"\n✅ The pipeline approach is {speedup:.1f}x faster!")
        print(f"✅ GPU utilization improved from {seq_util:.0f}% to {pipe_util:.0f}%")
        print(f"✅ Process {throughput_gain:.0f}% more images per hour")
        
        if improvement > 30:
            print(f"\n🚀 HIGHLY RECOMMENDED: Switch to concurrent_pipeline_worker.py")
        elif improvement > 15:
            print(f"\n👍 RECOMMENDED: Consider using concurrent_pipeline_worker.py")
        else:
            print(f"\n⚠️  Limited improvement - your GPU may already be the bottleneck")
        
        print()

def main():
    """Run benchmark"""
    import sys
    
    # Get number of jobs from command line or use default
    num_jobs = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    
    print("="*70)
    print("🎯 ESRGAN WORKER PIPELINE BENCHMARK")
    print("="*70)
    print()
    
    benchmark = PipelineBenchmark(num_jobs)
    
    # Run simulations
    seq_results = benchmark.simulate_sequential()
    print(f"✅ Sequential simulation: {seq_results['wall_time']:.1f}s total\n")
    
    pipe_results = benchmark.simulate_pipelined()
    print(f"✅ Pipeline simulation: {pipe_results['wall_time']:.1f}s total\n")
    
    # Print comparison
    benchmark.print_results(seq_results, pipe_results)

if __name__ == "__main__":
    main()
