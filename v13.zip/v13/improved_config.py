#!/usr/bin/env python3
"""
Enhanced Configuration module for ESRGAN Worker v11.0
Professional-grade configuration with improved Redis integration and error handling
"""

import os
import logging
import sys
import tempfile
import signal
from pathlib import Path
from typing import Optional, List, Dict
import platform


# Python 3.10+ compatibility fix for collections.Callable
try:
    from collections.abc import Callable, MutableMapping
    import collections
    if not hasattr(collections, 'Callable'):
        collections.Callable = Callable
        collections.MutableMapping = MutableMapping
except ImportError:
    pass

# === LOGGING CONFIGURATION ===
# Create logs directory with proper permissions
LOG_BASE_DIR = os.getenv('LOG_DIR', '/tmp/cugan-worker')
LOG_DIR = Path(LOG_BASE_DIR)
LOG_DIR.mkdir(parents=True, exist_ok=True, mode=0o755)

LOG_FILE = LOG_DIR / 'cugan_worker.log'
ERROR_LOG_FILE = LOG_DIR / 'cugan_worker_error.log'
METRICS_LOG_FILE = LOG_DIR / 'cugan_worker_metrics.log'

# Enhanced logging configuration
class ColoredFormatter(logging.Formatter):
    """Custom formatter with colors for console output"""
    
    COLORS = {
        'DEBUG': '\033[36m',    # Cyan
        'INFO': '\033[32m',     # Green
        'WARNING': '\033[33m',  # Yellow
        'ERROR': '\033[31m',    # Red
        'CRITICAL': '\033[35m', # Magenta
        'RESET': '\033[0m'      # Reset
    }
    
    def format(self, record):
        if hasattr(record, 'funcName') and hasattr(record, 'lineno'):
            record.location = f"{record.funcName}:{record.lineno}"
        else:
            record.location = "unknown"
            
        log_color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        record.levelname = f"{log_color}{record.levelname}{self.COLORS['RESET']}"
        return super().format(record)

# Setup enhanced logging
def setup_logging(debug: bool = False):
    """Setup professional logging configuration"""
    level = logging.DEBUG if debug else logging.INFO
    
    # Create formatters
    detailed_formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(name)s.%(location)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    console_formatter = ColoredFormatter(
        '%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%H:%M:%S'
    )
    
    # Root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)
    
    # File handler for all logs
    try:
        file_handler = logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(detailed_formatter)
        root_logger.addHandler(file_handler)
    except Exception as e:
        print(f"Warning: Could not setup file logging: {e}")
    
    # Error file handler
    try:
        error_handler = logging.FileHandler(ERROR_LOG_FILE, mode='a', encoding='utf-8')
        error_handler.setLevel(logging.WARNING)
        error_handler.setFormatter(detailed_formatter)
        root_logger.addHandler(error_handler)
    except Exception as e:
        print(f"Warning: Could not setup error logging: {e}")
    
    # Suppress noisy third-party loggers
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('botocore').setLevel(logging.WARNING)
    logging.getLogger('boto3').setLevel(logging.WARNING)
    logging.getLogger('s3transfer').setLevel(logging.WARNING)

# Initialize logging
DEBUG_MODE = os.getenv('DEBUG', 'false').lower() in ('true', '1', 'yes')
setup_logging(DEBUG_MODE)

logger = logging.getLogger(__name__)

# === REDIS CONFIGURATION ===
class RedisConfig:
    """Enhanced Redis configuration with connection pooling and health monitoring"""
    
    HOST = os.getenv('REDIS_HOST', '152.53.142.224')
    PORT = int(os.getenv('REDIS_PORT', '6379'))
    PASSWORD = os.getenv('REDIS_PASSWORD', 'BwswSeXhpFwcxSaQYwcq7DLj1qmvmz9PDT1D5Rr62CTTSWf1jIiaP17')
    DB = int(os.getenv('REDIS_DB', '0'))
    
    # Connection pool settings
    MAX_CONNECTIONS = int(os.getenv('REDIS_MAX_CONNECTIONS', '50'))
    CONNECTION_POOL_TIMEOUT = int(os.getenv('REDIS_POOL_TIMEOUT', '30'))
    
    # Connection timeouts
    SOCKET_CONNECT_TIMEOUT = int(os.getenv('REDIS_CONNECT_TIMEOUT', '10'))
    SOCKET_TIMEOUT = int(os.getenv('REDIS_SOCKET_TIMEOUT', '10'))
    
    # Health check settings  
    HEALTH_CHECK_INTERVAL = int(os.getenv('REDIS_HEALTH_INTERVAL', '30'))
    MAX_RETRY_ATTEMPTS = int(os.getenv('REDIS_MAX_RETRIES', '5'))
    RETRY_BACKOFF_BASE = float(os.getenv('REDIS_RETRY_BACKOFF', '2.0'))
    RETRY_BACKOFF_MAX = int(os.getenv('REDIS_RETRY_MAX_DELAY', '60'))
    
    # Prefix for Laravel compatibility
    PREFIX = os.getenv('REDIS_PREFIX', 'webtoon_hub_database_')

# Queue configurations
class QueueConfig:
    """Queue configuration with priority and routing"""
    
    # Primary queues
    JOBS = ['image:jobs', f'{RedisConfig.PREFIX}image:jobs']
    EVENTS = ['image:events', f'{RedisConfig.PREFIX}image:events']
    PRIORITY = f'{RedisConfig.PREFIX}image:priority'
    
    # Dead letter queue for failed jobs
    DLQ = f'{RedisConfig.PREFIX}image:dlq'
    RETRY_QUEUE = f'{RedisConfig.PREFIX}image:retry'
    
    # Queue monitoring
    QUEUE_METRICS = f'{RedisConfig.PREFIX}queue:metrics'
    WORKER_REGISTRY = f'{RedisConfig.PREFIX}workers'
    
    # Batch processing
    BATCH_SIZE = int(os.getenv('QUEUE_BATCH_SIZE', '5'))
    MAX_QUEUE_DEPTH = int(os.getenv('MAX_QUEUE_DEPTH', '10000'))

# === MINIO/S3 CONFIGURATION ===
class S3Config:
    """Enhanced S3/MinIO configuration"""
    
    # Using IP endpoint for better reliability
    # Test results: IP endpoint has 100% success rate (vs 90% with domain)
    # Eliminates 403 Forbidden errors seen with domain-based access
    ENDPOINT = os.getenv('MINIO_ENDPOINT', 'http://152.53.140.165:9000')
    ACCESS_KEY = os.getenv('MINIO_ACCESS_KEY', 'readershub-aju')
    SECRET_KEY = os.getenv('MINIO_SECRET_KEY', '4Hlkz5o4KDtmblMW2GyO7KkYIkNnzFGneOqsBvMoxM')
    BUCKET = os.getenv('MINIO_BUCKET', 'rhub')
    REGION = os.getenv('MINIO_REGION', 'us-east-1')
    
    # Connection settings
    MAX_POOL_CONNECTIONS = int(os.getenv('S3_MAX_CONNECTIONS', '50'))
    MAX_ATTEMPTS = int(os.getenv('S3_MAX_ATTEMPTS', '3'))
    
    # Upload settings
    MULTIPART_THRESHOLD = int(os.getenv('S3_MULTIPART_THRESHOLD', '64')) * 1024 * 1024  # 64MB
    MULTIPART_CHUNKSIZE = int(os.getenv('S3_MULTIPART_CHUNKSIZE', '16')) * 1024 * 1024  # 16MB
    
    # SSL/TLS settings (HTTP for IP endpoint)
    USE_SSL = ENDPOINT.startswith('https://')
    VERIFY_SSL = os.getenv('S3_VERIFY_SSL', 'false').lower() in ('true', '1')

# === ESRGAN CONFIGURATION ===
class ESRGANConfig:
    """Enhanced ESRGAN configuration with fallbacks"""
    
    EXECUTABLE = os.getenv('ESRGAN_EXECUTABLE', 'esrgan')
    MODEL = os.getenv('ESRGAN_MODEL', 'Omni-Small')
    SCALE_FACTOR = int(os.getenv('UPSCALE_SCALE_FACTOR', '2'))
    GPU_ID = int(os.getenv('ESRGAN_GPU_ID', '0'))
    TILE_SIZE = int(os.getenv('ESRGAN_TILE_SIZE', '256'))
    
    # Fallback models in priority order
    FALLBACK_MODELS = [
        'Omni-Small',
        'RealESRGAN_x4plus',
        'RealESRGAN_x2plus', 
        'ESRGAN_x4'
    ]
    
    # Fallback configurations for OOM recovery
    FALLBACK_CONFIGS = [
        {'tile': 256, 'gpu': GPU_ID},   # Default
        {'tile': 128, 'gpu': GPU_ID},   # Smaller tiles
        {'tile': 64, 'gpu': GPU_ID},    # Very small tiles
        {'tile': 256, 'gpu': -1},       # CPU fallback
    ]
    
    # Processing timeouts
    PROCESSING_TIMEOUT = int(os.getenv('ESRGAN_TIMEOUT', '300'))  # 5 minutes
    CPU_PROCESSING_TIMEOUT = int(os.getenv('ESRGAN_CPU_TIMEOUT', '900'))  # 15 minutes

# === IMAGE PROCESSING CONFIGURATION ===
class ImageConfig:
    """Enhanced image processing configuration"""
    
    # Supported formats
    SUPPORTED_FORMATS = {'JPEG', 'PNG', 'WEBP', 'BMP', 'GIF', 'TIFF'}
    
    # Size limits
    MIN_DIMENSION = int(os.getenv('MIN_IMAGE_DIM', '50'))
    MAX_WIDTH = int(os.getenv('MAX_IMAGE_WIDTH', '2000'))
    MAX_FILE_SIZE = int(os.getenv('MAX_IMAGE_SIZE', '50')) * 1024 * 1024  # 50MB
    
    # Webtoon splitting
    SPLIT_THRESHOLD = int(os.getenv('SPLIT_THRESHOLD', '12000'))  # 12k pixels
    SPLIT_HEIGHT = int(os.getenv('SPLIT_HEIGHT', '3000'))        # 3k pixel parts
    MAX_SPLITS = int(os.getenv('MAX_SPLITS', '10'))              # Safety limit
    
    # Variant configurations
    VARIANT_WIDTHS = {
        'hd': int(os.getenv('HD_WIDTH', '1200')),
        'sd': int(os.getenv('SD_WIDTH', '800')),  
        'ds': int(os.getenv('DS_WIDTH', '600')),
    }
    
    # WebP quality settings with adaptive adjustment
    WEBP_QUALITIES = {
        'hd': int(os.getenv('HD_QUALITY', '95')),
        'sd': int(os.getenv('SD_QUALITY', '90')),
        'ds': int(os.getenv('DS_QUALITY', '75')),
    }
    
    # WebP encoder limits
    WEBP_MAX_DIMENSION = 16383
    
    # Legacy variant mapping
    LEGACY_MAPPING = {
        'xl': 'hd',
        'lg': 'sd', 
        'md': 'ds',
    }

# === WORKER CONFIGURATION ===
class WorkerConfig:
    """Enhanced worker configuration"""
    
    # Worker identification
    # WORKER_ID = os.getenv('WORKER_ID', f"{os.uname().nodename}:{os.getpid()}")
    try:
        hostname = os.uname().nodename
    except AttributeError:
        hostname = platform.node()

    WORKER_ID = os.getenv('WORKER_ID', f"{hostname}:{os.getpid()}")
    WORKER_VERSION = "11.0.0"
    
    # Processing settings
    BATCH_SIZE = int(os.getenv('WORKER_BATCH_SIZE', '3'))
    THREAD_POOL_SIZE = int(os.getenv('WORKER_THREADS', '4'))
    MAX_CONCURRENT_JOBS = int(os.getenv('MAX_CONCURRENT_JOBS', '2'))
    
    # Registration and health
    REGISTRATION_TTL = int(os.getenv('WORKER_TTL', '60'))
    HEALTH_CHECK_INTERVAL = int(os.getenv('HEALTH_CHECK_INTERVAL', '30'))
    SCALE_CHECK_INTERVAL = int(os.getenv('SCALE_CHECK_INTERVAL', '30'))
    
    # Failure handling
    MAX_CONSECUTIVE_FAILURES = int(os.getenv('MAX_FAILURES', '5'))
    CIRCUIT_BREAKER_TIMEOUT = int(os.getenv('CIRCUIT_BREAKER_TIMEOUT', '300'))
    
    # Job processing
    JOB_LOCK_TTL = int(os.getenv('JOB_LOCK_TTL', '300'))  # 5 minutes
    OUTCOME_TTL = int(os.getenv('OUTCOME_TTL', '86400'))  # 24 hours
    CHAPTER_COUNTER_TTL = int(os.getenv('CHAPTER_COUNTER_TTL', '604800'))  # 7 days

# === MONITORING CONFIGURATION ===
class MonitoringConfig:
    """Enhanced monitoring and metrics configuration"""
    
    ENABLED = os.getenv('METRICS_ENABLED', 'true').lower() in ('true', '1')
    PORT = int(os.getenv('METRICS_PORT', '8001'))
    HOST = os.getenv('METRICS_HOST', '0.0.0.0')
    
    # Resource thresholds
    MEMORY_WARNING_THRESHOLD = int(os.getenv('MEMORY_WARNING', '80'))  # 80%
    MEMORY_CRITICAL_THRESHOLD = int(os.getenv('MEMORY_CRITICAL', '90'))  # 90%
    CPU_WARNING_THRESHOLD = int(os.getenv('CPU_WARNING', '85'))  # 85%
    CPU_CRITICAL_THRESHOLD = int(os.getenv('CPU_CRITICAL', '95'))  # 95%
    
    # GPU monitoring (if available)
    GPU_MEMORY_WARNING = int(os.getenv('GPU_MEMORY_WARNING', '85'))  # 85%
    GPU_TEMP_WARNING = int(os.getenv('GPU_TEMP_WARNING', '80'))  # 80°C
    
    # Log file sizes (MB)
    MAX_LOG_SIZE = int(os.getenv('MAX_LOG_SIZE', '100'))  # 100MB
    LOG_BACKUP_COUNT = int(os.getenv('LOG_BACKUP_COUNT', '5'))

# === PERFORMANCE TUNING ===
class PerformanceConfig:
    """Performance optimization settings"""
    
    # Memory management
    GC_INTERVAL = int(os.getenv('GC_INTERVAL', '10'))  # Run GC every 10 jobs
    MAX_MEMORY_USAGE = int(os.getenv('MAX_MEMORY_USAGE', '8')) * 1024 * 1024 * 1024  # 8GB
    
    # I/O optimization
    IO_BUFFER_SIZE = int(os.getenv('IO_BUFFER_SIZE', '64')) * 1024  # 64KB
    TEMP_DIR = os.getenv('TEMP_DIR', tempfile.gettempdir())
    
    # Concurrency
    USE_THREADING = os.getenv('USE_THREADING', 'true').lower() in ('true', '1')
    USE_ASYNC_IO = os.getenv('USE_ASYNC_IO', 'true').lower() in ('true', '1')

# === GRACEFUL SHUTDOWN HANDLER ===
class GracefulKiller:
    """Enhanced signal handler for graceful shutdown"""
    
    def __init__(self):
        self.kill_now = False
        self.jobs_in_progress = set()
        
        # Register signal handlers
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)
        
        # Handle Windows signals if available
        if hasattr(signal, 'SIGBREAK'):
            signal.signal(signal.SIGBREAK, self._handle_signal)
    
    def _handle_signal(self, signum, frame):
        signal_name = signal.Signals(signum).name
        logger.info(f"🛑 Received {signal_name} signal, initiating graceful shutdown...")
        self.kill_now = True
    
    def add_job(self, job_id: str):
        """Register a job in progress"""
        self.jobs_in_progress.add(job_id)
    
    def remove_job(self, job_id: str):
        """Remove a completed job"""
        self.jobs_in_progress.discard(job_id)
    
    def wait_for_jobs(self, timeout: int = 30):
        """Wait for jobs to complete with timeout"""
        import time
        start_time = time.time()
        
        while self.jobs_in_progress and (time.time() - start_time) < timeout:
            logger.info(f"⏳ Waiting for {len(self.jobs_in_progress)} jobs to complete...")
            time.sleep(1)
        
        if self.jobs_in_progress:
            logger.warning(f"⚠️ Timeout reached, {len(self.jobs_in_progress)} jobs still in progress")

# Create global signal handler instance
GRACEFUL_KILLER = GracefulKiller()

# === VALIDATION ===
def validate_config():
    """Validate configuration settings"""
    errors = []
    
    # Validate Redis connection
    if not RedisConfig.HOST or not RedisConfig.PORT:
        errors.append("Redis host and port must be configured")
    
    # Validate S3 settings
    if not S3Config.ENDPOINT or not S3Config.ACCESS_KEY:
        errors.append("S3/MinIO endpoint and credentials must be configured")
    
    # Validate ESRGAN
    if not ESRGANConfig.EXECUTABLE:
        errors.append("ESRGAN executable path must be configured")
    
    # Validate directories
    if not LOG_DIR.exists() or not os.access(LOG_DIR, os.W_OK):
        errors.append(f"Log directory {LOG_DIR} not writable")
    
    if errors:
        logger.error("❌ Configuration validation failed:")
        for error in errors:
            logger.error(f"   - {error}")
        return False
    
    logger.info("✅ Configuration validation passed")
    return True

# Initialize configuration
if __name__ != "__main__":
    if not validate_config():
        logger.error("❌ Invalid configuration, worker cannot start")
        sys.exit(1)

logger.info(f"🔧 Enhanced ESRGAN Worker v{WorkerConfig.WORKER_VERSION} configuration loaded")