#!/usr/bin/env python3

# Suppress SSL warnings for MinIO only if explicitly configured
import urllib3
import os

# Only disable SSL warnings if MINIO_INSECURE environment variable is set to "1"
if os.environ.get('MINIO_INSECURE') == '1':
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

"""
Enhanced Main Entry Point for ESRGAN Worker v13
Professional-grade entry point with comprehensive error handling and graceful shutdown
"""

import sys
import os
import logging
import traceback
from pathlib import Path

# Add current directory to Python path for imports
sys.path.insert(0, str(Path(__file__).parent))

try:
    from improved_config import WorkerConfig, validate_config, logger
    from improved_worker import EnhancedWorker
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Please ensure all required dependencies are installed:")
    print("  pip install redis pillow boto3 psutil prometheus_client")
    sys.exit(1)

def check_requirements():
    """Check if all required dependencies are available"""
    required_packages = [
        'redis',
        'boto3', 
        'PIL',  # Pillow
        'psutil'
    ]
    
    missing = []
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    if missing:
        logger.error("❌ Missing required packages:")
        for package in missing:
            logger.error(f"   - {package}")
        logger.error("Install with: pip install redis pillow boto3 psutil")
        return False
    
    return True

def display_banner():
    """Display startup banner with configuration info"""
    banner = f"""
╔══════════════════════════════════════════════════════════════════╗
║                   Enhanced ESRGAN Worker v{WorkerConfig.WORKER_VERSION}                     ║
╠══════════════════════════════════════════════════════════════════╣
║  Professional-grade GPU image processing worker                 ║
║                                                                  ║
║  Features:                                                       ║
║  • Enhanced Redis integration with connection pooling           ║
║  • Robust S3/MinIO handling with retry logic                   ║
║  • Graceful shutdown and signal handling                       ║
║  • Comprehensive monitoring and metrics                        ║
║  • Circuit breaker and error recovery                          ║
║  • Dead letter queue support                                   ║
║                                                                  ║
║  Worker ID: {WorkerConfig.WORKER_ID:<47} ║
╚══════════════════════════════════════════════════════════════════╝
    """
    
    print(banner)
    logger.info("🚀 Enhanced ESRGAN Worker starting up...")

def main():
    """
    Main entry point with comprehensive error handling
    """
    exit_code = 0
    worker = None
    
    try:
        # Display banner
        display_banner()
        
        # Check requirements
        logger.info("🔍 Checking requirements...")
        if not check_requirements():
            return 1
        
        # Validate configuration
        logger.info("🔧 Validating configuration...")
        if not validate_config():
            logger.error("❌ Configuration validation failed")
            return 1
        
        # Create and run enhanced worker
        logger.info("🏗️ Creating enhanced worker...")
        worker = EnhancedWorker()
        
        logger.info("▶️ Starting worker main loop...")
        success = worker.run()
        
        exit_code = 0 if success else 1
        
    except KeyboardInterrupt:
        logger.info("⌨️ Keyboard interrupt received - shutting down gracefully...")
        exit_code = 0
        
    except Exception as e:
        logger.error(f"❌ Fatal error during startup: {e}")
        logger.error(f"📍 Error details:\n{traceback.format_exc()}")
        exit_code = 1
    
    finally:
        # Ensure clean shutdown
        if worker and hasattr(worker, 'cleanup_resources'):
            try:
                worker.cleanup_resources()
            except Exception as e:
                logger.error(f"❌ Error during cleanup: {e}")
        
        logger.info(f"🔚 Enhanced ESRGAN Worker exiting with code {exit_code}")
        
        # Return exit code for graceful shutdown
        return exit_code

if __name__ == "__main__":
    # Ensure all buffered log messages are flushed before exit
    logging.shutdown()
    sys.exit(main())