# Deploy GPU Worker Fixes
# PowerShell script for Windows

Write-Host "🚀 Deploying GPU Worker Fixes to Server..." -ForegroundColor Cyan
Write-Host ""

$SERVER_USER = "root"
$SERVER_HOST = "171.247.185.4"
$SERVER_PORT = "42576"
$SSH_KEY = "C:\Users\AJU\.ssh\vast"
$REMOTE_PATH = "/home/image-conversion/v13"
$LOCAL_PATH = "D:\xampp3\htdocs\readershub\ext-esrgan-laravel\v13"

# Change to the correct directory
Set-Location $LOCAL_PATH

Write-Host "📁 Uploading files..." -ForegroundColor Yellow
Write-Host ""

# Upload files
Write-Host "  → Uploading simple_improved_storage.py..."
scp -i $SSH_KEY -P $SERVER_PORT simple_improved_storage.py ${SERVER_USER}@${SERVER_HOST}:${REMOTE_PATH}/

Write-Host "  → Uploading improved_worker.py..."
scp -i $SSH_KEY -P $SERVER_PORT improved_worker.py ${SERVER_USER}@${SERVER_HOST}:${REMOTE_PATH}/

Write-Host "  → Uploading FIXES_README.md..."
scp -i $SSH_KEY -P $SERVER_PORT FIXES_README.md ${SERVER_USER}@${SERVER_HOST}:${REMOTE_PATH}/

Write-Host ""
Write-Host "✅ Files uploaded successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "🔄 Restarting worker service..." -ForegroundColor Yellow

# Restart worker
$restartScript = @"
cd /home/image-conversion/v13
pkill -f 'improved_main.py' || true
sleep 2
nohup python3 improved_main.py > worker.log 2>&1 &
echo 'Worker restarted with PID: '$!
"@

ssh -i $SSH_KEY -p $SERVER_PORT ${SERVER_USER}@${SERVER_HOST} $restartScript

Write-Host ""
Write-Host "✅ Deployment complete!" -ForegroundColor Green
Write-Host ""
Write-Host "📊 To view logs:" -ForegroundColor Cyan
Write-Host "   ssh -i `"$SSH_KEY`" -p $SERVER_PORT ${SERVER_USER}@${SERVER_HOST} 'tail -f /home/image-conversion/v13/worker.log'"
Write-Host ""
Write-Host "🔍 To check worker status:" -ForegroundColor Cyan
Write-Host "   ssh -i `"$SSH_KEY`" -p $SERVER_PORT ${SERVER_USER}@${SERVER_HOST} 'ps aux | grep improved_main.py'"
Write-Host ""
Write-Host "Press any key to continue..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
