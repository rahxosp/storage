#!/usr/bin/env python3
"""
Monitoring module for ESRGAN Worker
Contains CircuitBreaker, HealthMonitor classes and metrics setup
"""

import time
import logging
import psutil
from config import (
    MAX_CONSECUTIVE_FAILURES, CIRCUIT_BREAKER_TIMEOUT, 
    MEMORY_THRESHOLD, CPU_THRESHOLD, HEALTH_CHECK_INTERVAL,
    METRICS_PORT
)

logger = logging.getLogger(__name__)

# Prometheus metrics (optional - will work without it)
try:
    from prometheus_client import Counter, Histogram, Gauge, start_http_server
    METRICS_ENABLED = True
    
    # Define metrics
    jobs_processed_counter = Counter('worker_jobs_processed_total', 'Total processed jobs')
    jobs_failed_counter = Counter('worker_jobs_failed_total', 'Total failed jobs') 
    processing_time_histogram = Histogram('worker_processing_seconds', 'Processing time per job')
    active_jobs_gauge = Gauge('worker_active_jobs', 'Currently processing jobs')
    queue_length_gauge = Gauge('worker_queue_length', 'Current queue length')
    worker_memory_gauge = Gauge('worker_memory_percent', 'Worker memory usage')
    worker_cpu_gauge = Gauge('worker_cpu_percent', 'Worker CPU usage')
except ImportError:
    METRICS_ENABLED = False
    logging.info("Prometheus client not installed, metrics disabled")
    
    # Create dummy objects for when metrics are disabled
    class DummyMetric:
        def inc(self, *args, **kwargs): pass
        def dec(self, *args, **kwargs): pass
        def set(self, *args, **kwargs): pass
        def observe(self, *args, **kwargs): pass
    
    jobs_processed_counter = DummyMetric()
    jobs_failed_counter = DummyMetric()
    processing_time_histogram = DummyMetric()
    active_jobs_gauge = DummyMetric()
    queue_length_gauge = DummyMetric()
    worker_memory_gauge = DummyMetric()
    worker_cpu_gauge = DummyMetric()

def start_metrics_server():
    """Start Prometheus metrics server if available"""
    if METRICS_ENABLED:
        try:
            start_http_server(METRICS_PORT)
            logger.info(f"📊 Metrics server started on port {METRICS_PORT}")
            return True
        except Exception as e:
            logger.warning(f"Failed to start metrics server: {e}")
            return False
    return False

class CircuitBreaker:
    """Circuit breaker pattern implementation for fault tolerance"""
    
    def __init__(self, failure_threshold: int = MAX_CONSECUTIVE_FAILURES, timeout: int = CIRCUIT_BREAKER_TIMEOUT):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = 'CLOSED'  # CLOSED, OPEN, HALF_OPEN

    def can_proceed(self) -> bool:
        """Check if operations can proceed based on circuit breaker state"""
        if self.state == 'CLOSED':
            return True
        elif self.state == 'OPEN':
            if time.time() - self.last_failure_time > self.timeout:
                self.state = 'HALF_OPEN'
                return True
            return False
        else:  # HALF_OPEN
            return True

    def record_success(self):
        """Record successful operation"""
        self.failure_count = 0
        self.state = 'CLOSED'
        self.last_failure_time = None

    def record_failure(self):
        """Record failed operation"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        if self.failure_count >= self.failure_threshold:
            self.state = 'OPEN'
            logger.warning(f"🔴 Circuit breaker OPEN due to {self.failure_count} consecutive failures")

class HealthMonitor:
    """System health monitoring for resource management"""
    
    def __init__(self):
        self.last_check = 0
        self.memory_warnings = 0
        self.cpu_warnings = 0

    def check_health(self) -> bool:
        """Check system health and return whether system is healthy"""
        now = time.time()
        if now - self.last_check < HEALTH_CHECK_INTERVAL:
            return True
        self.last_check = now

        # Memory
        memory = psutil.virtual_memory()
        if METRICS_ENABLED:
            worker_memory_gauge.set(memory.percent)
        
        if memory.percent > MEMORY_THRESHOLD:
            self.memory_warnings += 1
            logger.warning(f"⚠️ High memory usage: {memory.percent:.1f}%")
            if self.memory_warnings > 3:
                return False
        else:
            self.memory_warnings = 0

        # CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        if METRICS_ENABLED:
            worker_cpu_gauge.set(cpu_percent)
            
        if cpu_percent > CPU_THRESHOLD:
            self.cpu_warnings += 1
            logger.warning(f"⚠️ High CPU usage: {cpu_percent:.1f}%")
            if self.cpu_warnings > 3:
                return False
        else:
            self.cpu_warnings = 0

        return True
    
    def get_resource_state(self) -> str:
        """Get current resource state for graceful degradation"""
        memory = psutil.virtual_memory()
        if memory.percent > 95:
            return 'CRITICAL'
        elif memory.percent > 90:
            return 'HIGH'
        elif memory.percent > 85:
            return 'MODERATE'
        else:
            return 'NORMAL'
