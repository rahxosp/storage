#!/usr/bin/env python3
"""
Utilities module for ESRGAN Worker
Contains helper functions and common operations
"""

import tempfile
import os
import logging
from contextlib import contextmanager
from typing import Dict, Optional, Tuple
from PIL import Image
from config import (
    WEBP_QUALITIES, WEBP_MAX_DIM, SUPPORTED_FORMATS,
    MIN_IMAGE_DIM, MAX_IMAGE_WIDTH, MAX_IMAGE_SIZE, SPLIT_THRESHOLD,
    EXPONENTIAL_BACKOFF_BASE, RETRY_DELAY, MAX_BACKOFF_DELAY
)

logger = logging.getLogger(__name__)

def get_exponential_backoff_delay(attempt: int) -> int:
    """Calculate exponential backoff delay for retry attempts"""
    return min(EXPONENTIAL_BACKOFF_BASE ** attempt * RETRY_DELAY, MAX_BACKOFF_DELAY)

def parse_s3_path(s3_path: str) -> Dict[str, str]:
    """Parse S3 path to extract manga metadata"""
    try:
        # New structure: manga-name/chapter/en/og/filename.webp
        # Old structure: manga-name/chapter/original/en/filename.webp
        parts = s3_path.split('/')
        if len(parts) >= 5:
            manga_name = parts[0]
            chapter_num = parts[1]
            if parts[2] in ['en', 'ja', 'ko', 'zh']:
                language = parts[2]
                quality_folder = parts[3]
                filename = parts[4]
            elif parts[3] in ['en', 'ja', 'ko', 'zh']:
                quality_folder = parts[2]
                language = parts[3]
                filename = parts[4]
            else:
                language = parts[2] if len(parts) > 2 else 'en'
                quality_folder = parts[3] if len(parts) > 3 else 'og'
                filename = parts[4] if len(parts) > 4 else 'unknown.webp'
            base_filename = filename.rsplit('.', 1)[0] if '.' in filename else filename
            return {
                'manga_name': manga_name,
                'chapter_num': chapter_num,
                'language': language,
                'quality_folder': quality_folder,
                'filename': filename,
                'base_filename': base_filename,
            }
        logger.warning(f"Could not parse S3 path: {s3_path}")
        return {}
    except Exception as e:
        logger.error(f"❌ Error parsing S3 path {s3_path}: {e}")
        return {}

def generate_variant_s3_path(parsed: Dict[str, str], variant_folder: str) -> str:
    """Generate S3 path for image variant"""
    if not parsed:
        return ""
    filename = f"{parsed['base_filename']}.webp"
    return f"{parsed['manga_name']}/{parsed['chapter_num']}/{parsed['language']}/{variant_folder}/{filename}"

def validate_image(path: str) -> Tuple[bool, Optional[str], bool]:
    """Validate image before processing, return (valid, error, needs_split)"""
    try:
        with Image.open(path) as img:
            # Check format
            if img.format and img.format.upper() not in SUPPORTED_FORMATS:
                return False, f"Unsupported format: {img.format}", False
            
            # Check dimensions
            if img.width > MAX_IMAGE_WIDTH:
                return False, f"Image too wide: {img.width}px (max: {MAX_IMAGE_WIDTH}px)", False
            if img.width < MIN_IMAGE_DIM or img.height < MIN_IMAGE_DIM:
                return False, f"Image too small: {img.width}x{img.height}", False
            
            # Check if needs splitting (tall webtoon)
            needs_split = img.height > SPLIT_THRESHOLD
            if needs_split:
                logger.info(f"📏 Very tall image detected: {img.width}x{img.height} - will split for processing (threshold: {SPLIT_THRESHOLD}px)")
            
            # Check file size
            file_size = os.path.getsize(path)
            if file_size > MAX_IMAGE_SIZE:
                return False, f"File too large: {file_size} bytes", False
            
            # Try to load to check for corruption
            img.load()
            
            return True, None, needs_split
    except Exception as e:
        return False, f"Invalid image: {e}", False

def determine_adaptive_quality(image_size: Tuple[int, int], variant: str) -> int:
    """Adjust quality based on source resolution"""
    width, height = image_size
    pixels = width * height
    base_quality = WEBP_QUALITIES.get(variant, 80)
    
    # DS always uses configured compression
    if variant == 'ds':
        return base_quality
    
    # Adjust quality for other variants based on resolution
    if pixels > 4000 * 3000:  # Very high res (12MP+)
        # Slightly lower quality for huge images
        return max(70, base_quality - 5)
    elif pixels < 800 * 600:  # Low res (< 0.5MP)
        # Higher quality for small images
        return min(100, base_quality + 5)
    else:
        return base_quality

def convert_image_format(input_path: str, output_path: str) -> bool:
    """Convert image to PNG format for ESRGAN compatibility"""
    try:
        with Image.open(input_path) as img:
            original_format = img.format
            # Preserve ICC profile if present
            icc = img.info.get('icc_profile')
            # Convert conservatively to preserve colors/details and alpha when present
            if img.mode in ('P', 'LA'):
                img = img.convert('RGBA')  # expand palette/LA to full-color with alpha
            elif img.mode == 'CMYK':
                img = img.convert('RGB')  # CMYK to RGB for screen rendering
            elif img.mode not in ('RGB', 'RGBA'):
                img = img.convert('RGBA' if 'A' in img.getbands() else 'RGB')
            # Save as PNG losslessly, embedding ICC if available
            save_kwargs = {'optimize': True}
            if icc:
                save_kwargs['icc_profile'] = icc
            img.save(output_path, 'PNG', **save_kwargs)
            if original_format != 'PNG':
                logger.info(f"🔄 Converted {original_format} to PNG for ESRGAN compatibility (ICC preserved if present)")
            return True
    except Exception as e:
        logger.error(f"❌ Error converting image format: {e}")
        return False

def resize_image_with_degradation(input_path: str, output_path: str, width: int, 
                                quality: int, variant: str, resource_state: str) -> bool:
    """Resize image with graceful degradation based on resources"""
    try:
        # Skip non-essential variants under memory pressure
        if resource_state == 'CRITICAL' and variant != 'hd':
            logger.warning(f"⚠️ Skipping {variant} variant due to critical memory")
            return False
        elif resource_state == 'HIGH' and variant == 'ds':
            logger.warning(f"⚠️ Skipping {variant} variant due to high memory")
            return False
        
        with Image.open(input_path) as img:
            # Get adaptive quality
            adaptive_quality = determine_adaptive_quality(img.size, variant)
            
            # Preserve color profile if present
            icc = img.info.get('icc_profile')
            # Keep alpha if present; convert palette/LA to RGBA, greyscale to RGB
            if img.mode in ('P', 'LA'):
                img = img.convert('RGBA')
            elif img.mode == 'L':
                img = img.convert('RGB')
                
            ow, oh = img.size
            nh = int((width * oh) / ow)
            
            if nh > WEBP_MAX_DIM:
                safe_width = max(1, int(WEBP_MAX_DIM * ow / oh))
                logger.warning(f"⚠️ Target resize exceeds WebP height limit ({nh}px). Clamp width to {safe_width}px.")
                width = safe_width
                nh = int((width * oh) / ow)
                
            resized = img.resize((width, nh), Image.Resampling.LANCZOS)
            save_kwargs = {'quality': adaptive_quality, 'optimize': True, 'method': 6}
            
            if icc:
                save_kwargs['icc_profile'] = icc
            # Preserve exact RGB under alpha if present
            if 'A' in resized.getbands():
                save_kwargs['exact'] = True
                
            resized.save(output_path, 'WEBP', **save_kwargs)
            logger.info(f"🔄 Resized {variant} to {width}x{nh} with quality {adaptive_quality} (adaptive, ICC preserved)")
            return True
            
    except Exception as e:
        logger.error(f"❌ Error resizing image: {e}")
        return False

@contextmanager
def temporary_file(suffix='.webp'):
    """Context manager for temporary files with automatic cleanup"""
    temp_file = None
    try:
        temp_file = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
        temp_file.close()
        yield temp_file.name
    finally:
        if temp_file and os.path.exists(temp_file.name):
            try:
                os.unlink(temp_file.name)
            except Exception as e:
                logger.warning(f"⚠️ Could not delete temp file {temp_file.name}: {e}")
