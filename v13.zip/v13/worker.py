#!/usr/bin/env python3
"""
Enhanced Worker module for ESRGAN Worker v11.0
Professional-grade main worker with improved signal handling,
graceful shutdown, optimized processing, and comprehensive monitoring
"""

import os
import sys
import json
import time
import signal
import socket
import gc
import asyncio
import threading
from typing import Dict, List, Optional, Tuple, Any
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from contextlib import contextmanager
from dataclasses import dataclass, asdict
from enum import Enum

# Enhanced imports
from improved_config import (
    WorkerConfig, QueueConfig, ESRGANConfig, ImageConfig, 
    MonitoringConfig, PerformanceConfig, GRACEFUL_KILLER, logger
)
from improved_storage import (
    EnhancedRedisManager, EnhancedS3Manager, 
    EnhancedWorkerRegistry, EnhancedJobManager
)

class WorkerState(Enum):
    """Worker state enumeration"""
    INITIALIZING = "initializing"
    CONNECTING = "connecting"
    IDLE = "idle"
    PROCESSING = "processing"
    SHUTTING_DOWN = "shutting_down"
    STOPPED = "stopped"
    ERROR = "error"

@dataclass
class JobMetrics:
    """Job processing metrics"""
    total_processed: int = 0
    total_failed: int = 0
    total_processing_time: float = 0.0
    avg_processing_time: float = 0.0
    jobs_per_hour: float = 0.0
    success_rate: float = 100.0
    last_job_at: Optional[float] = None

class EnhancedWorker:
    """
    Professional-grade ESRGAN Worker with:
    - Enhanced signal handling and graceful shutdown
    - Connection pooling and health monitoring  
    - Optimized job processing pipeline
    - Comprehensive metrics and monitoring
    - Circuit breaker and error recovery
    - Resource management and cleanup
    """
    
    def __init__(self):
        self.state = WorkerState.INITIALIZING
        self.worker_id = WorkerConfig.WORKER_ID
        self.start_time = time.time()
        
        # Core managers
        self.redis_manager: Optional[EnhancedRedisManager] = None
        self.s3_manager: Optional[EnhancedS3Manager] = None
        self.worker_registry: Optional[EnhancedWorkerRegistry] = None
        self.job_manager: Optional[EnhancedJobManager] = None
        
        # Job processing
        self.job_metrics = JobMetrics()
        self.current_jobs: Dict[str, Dict] = {}
        self.jobs_lock = threading.RLock()
        
        # Health and performance
        self.last_health_check = 0
        self.last_metrics_log = 0
        self.consecutive_failures = 0
        self.circuit_breaker_until = 0
        
        # Thread pool for concurrent processing
        self.thread_pool: Optional[ThreadPoolExecutor] = None
        
        # Enhanced signal handling
        self._setup_enhanced_signals()
        
        logger.info(f"🚀 Enhanced ESRGAN Worker v{WorkerConfig.WORKER_VERSION} initialized")
        logger.info(f"   Worker ID: {self.worker_id}")
        logger.info(f"   Max concurrent jobs: {WorkerConfig.MAX_CONCURRENT_JOBS}")
        logger.info(f"   Thread pool size: {WorkerConfig.THREAD_POOL_SIZE}")
    
    def _setup_enhanced_signals(self):
        """Setup enhanced signal handling for graceful shutdown"""
        def signal_handler(signum, frame):
            signal_name = signal.Signals(signum).name
            logger.info(f"🛑 Received {signal_name} signal")
            
            # Set graceful shutdown flag
            GRACEFUL_KILLER.kill_now = True
            
            # Change worker state
            if self.state != WorkerState.SHUTTING_DOWN:
                self.state = WorkerState.SHUTTING_DOWN
                logger.info("🔄 Initiating graceful shutdown sequence...")
        
        # Register signal handlers
        signal.signal(signal.SIGINT, signal_handler)   # Ctrl+C
        signal.signal(signal.SIGTERM, signal_handler)  # Termination
        
        # Handle additional Unix signals
        if hasattr(signal, 'SIGHUP'):
            signal.signal(signal.SIGHUP, signal_handler)
        if hasattr(signal, 'SIGQUIT'):
            signal.signal(signal.SIGQUIT, signal_handler)
        
        # Handle Windows signals
        if hasattr(signal, 'SIGBREAK'):
            signal.signal(signal.SIGBREAK, signal_handler)
        
        logger.info("✅ Enhanced signal handlers registered")
    
    def initialize_managers(self) -> bool:
        """Initialize all manager components"""
        try:
            self.state = WorkerState.CONNECTING
            
            # Initialize Redis manager
            logger.info("🔧 Initializing Redis manager...")
            self.redis_manager = EnhancedRedisManager()
            if not self.redis_manager.connect():
                logger.error("❌ Failed to initialize Redis manager")
                return False
            
            # Initialize S3 manager
            logger.info("🔧 Initializing S3 manager...")
            self.s3_manager = EnhancedS3Manager()
            if not self.s3_manager.connect():
                logger.error("❌ Failed to initialize S3 manager")
                return False
            
            # Initialize worker registry
            logger.info("🔧 Initializing worker registry...")
            self.worker_registry = EnhancedWorkerRegistry(self.redis_manager)
            
            # Initialize job manager
            logger.info("🔧 Initializing job manager...")
            self.job_manager = EnhancedJobManager(self.redis_manager)
            
            # Initialize thread pool
            logger.info("🔧 Initializing thread pool...")
            self.thread_pool = ThreadPoolExecutor(
                max_workers=WorkerConfig.THREAD_POOL_SIZE,
                thread_name_prefix="esrgan-worker"
            )
            
            # Register worker
            if not self.worker_registry.register():
                logger.error("❌ Failed to register worker")
                return False
            
            logger.info("✅ All managers initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error initializing managers: {e}")
            return False
    
    def health_check(self) -> bool:
        """Perform comprehensive health check"""
        current_time = time.time()
        
        # Skip if recently checked
        if current_time - self.last_health_check < WorkerConfig.HEALTH_CHECK_INTERVAL:
            return True
        
        self.last_health_check = current_time
        
        try:
            # Check Redis health
            if not self.redis_manager or not self.redis_manager.is_healthy():
                logger.warning("⚠️ Redis health check failed")
                return False
            
            # Check S3 health (simple bucket access test)
            if not self.s3_manager or self.s3_manager.status.name != "CONNECTED":
                logger.warning("⚠️ S3 health check failed")
                return False
            
            # Check circuit breaker
            if current_time < self.circuit_breaker_until:
                logger.warning("⚠️ Circuit breaker is active")
                return False
            
            logger.debug("✅ Health check passed")
            return True
            
        except Exception as e:
            logger.error(f"❌ Health check error: {e}")
            return False
    
    def register_heartbeat(self):
        """Register worker heartbeat with updated metrics"""
        try:
            if self.worker_registry:
                self.worker_registry.register(
                    jobs_processed=self.job_metrics.total_processed,
                    jobs_failed=self.job_metrics.total_failed
                )
        except Exception as e:
            logger.warning(f"⚠️ Failed to register heartbeat: {e}")
    
    def get_job_from_queue(self, timeout: int = 5) -> Optional[Tuple[str, Dict]]:
        """Get next job from priority queues"""
        try:
            # Build queue list with priority order
            all_queues = [QueueConfig.PRIORITY] + QueueConfig.JOBS
            
            result = self.redis_manager.pop_job(all_queues, timeout=timeout)
            if result:
                queue_name, job_data = result
                job_uuid = job_data.get('jobUuid', 'unknown')
                
                logger.info(f"📥 Received job {job_uuid} from queue {queue_name}")
                return queue_name, job_data
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Error getting job from queue: {e}")
            return None
    
    def determine_event_queue(self, source_queue: str) -> str:
        """Determine appropriate event queue based on source queue"""
        if source_queue.startswith(QueueConfig.JOBS[1].split(':')[0]):  # Laravel prefixed queue
            return QueueConfig.EVENTS[1]
        else:
            return QueueConfig.EVENTS[0]
    
    def process_job_sync(self, job_data: Dict[str, Any], attempt: int = 1) -> Dict[str, Any]:
        """Process a single job synchronously with the actual ESRGAN logic"""
        job_id = job_data.get('jobUuid', 'unknown')
        s3_path = job_data.get('s3Original', '')
        variants = job_data.get('variants', ['hd', 'sd', 'ds'])
        
        if not s3_path:
            logger.error(f"❌ Job {job_id}: Missing s3Original")
            return {
                'status': 'failed',
                'jobUuid': job_id,
                'chapterId': job_data.get('chapterId', 0),
                'pageIndex': job_data.get('pageIndex', 0),
                's3Original': s3_path,
                'error': 'Missing s3Original',
                'worker_id': self.worker_id
            }
        
        logger.info(f"🔄 Processing job {job_id}: {s3_path} (variants: {variants})")
        
        # Import the processing modules
        from esrgan_processor import ESRGANProcessor, VariantProcessor
        from utils import temporary_file, parse_s3_path, validate_image, convert_image_format
        import psutil
        
        start_time = time.time()
        
        try:
            # Parse the S3 path to get metadata
            parsed = parse_s3_path(s3_path)
            if not parsed:
                return {
                    'status': 'failed',
                    'jobUuid': job_id,
                    'chapterId': job_data.get('chapterId', 0),
                    'pageIndex': job_data.get('pageIndex', 0),
                    's3Original': s3_path,
                    'error': 'Could not parse S3 path',
                    'processing_time': time.time() - start_time,
                    'worker_id': self.worker_id
                }
                
            logger.info(f"📝 Parsed metadata: {parsed}")
            
            # Download the original image
            with temporary_file(suffix='.tmp') as temp_input:
                if not self.s3_manager.download_file_with_retry(s3_path, temp_input):
                    return {
                        'status': 'failed',
                        'jobUuid': job_id,
                        'chapterId': job_data.get('chapterId', 0),
                        'pageIndex': job_data.get('pageIndex', 0),
                        's3Original': s3_path,
                        'error': 'Failed to download input image',
                        'processing_time': time.time() - start_time,
                        'worker_id': self.worker_id
                    }
                    
                # Validate the image
                is_valid, error_msg, needs_split = validate_image(temp_input)
                if not is_valid:
                    return {
                        'status': 'failed',
                        'jobUuid': job_id,
                        'chapterId': job_data.get('chapterId', 0),
                        'pageIndex': job_data.get('pageIndex', 0),
                        's3Original': s3_path,
                        'error': f'Invalid image: {error_msg}',
                        'processing_time': time.time() - start_time,
                        'worker_id': self.worker_id
                    }
                    
                if needs_split:
                    logger.warning(f"⚠️ Image needs splitting but splitting not implemented in improved worker yet")
                
                # Convert to PNG format if needed for ESRGAN compatibility
                with temporary_file(suffix='.png') as temp_png:
                    if not convert_image_format(temp_input, temp_png):
                        return {
                            'status': 'failed',
                            'jobUuid': job_id,
                            'chapterId': job_data.get('chapterId', 0),
                            'pageIndex': job_data.get('pageIndex', 0),
                            's3Original': s3_path,
                            'error': 'Failed to convert image format',
                            'processing_time': time.time() - start_time,
                            'worker_id': self.worker_id
                        }
                        
                    # Run ESRGAN upscaling
                    esrgan_processor = ESRGANProcessor(self.s3_manager)
                    with temporary_file(suffix='.png') as temp_upscaled:
                        if not esrgan_processor.run_esrgan_with_fallback(temp_png, temp_upscaled):
                            return {
                                'status': 'failed',
                                'jobUuid': job_id,
                                'chapterId': job_data.get('chapterId', 0),
                                'pageIndex': job_data.get('pageIndex', 0),
                                's3Original': s3_path,
                                'error': 'ESRGAN processing failed',
                                'processing_time': time.time() - start_time,
                                'worker_id': self.worker_id
                            }
                            
                        logger.info(f"✅ ESRGAN upscaling completed successfully")
                        
                        # Determine resource state for variant processing
                        memory = psutil.virtual_memory()
                        if memory.percent > 90:
                            resource_state = 'CRITICAL'
                        elif memory.percent > 80:
                            resource_state = 'HIGH'
                        else:
                            resource_state = 'NORMAL'
                        
                        # Process variants
                        variant_processor = VariantProcessor(self.s3_manager)
                        variant_results = variant_processor.process_variants_parallel(
                            temp_upscaled, parsed, variants, resource_state
                        )
                        
                        if not variant_results:
                            return {
                                'status': 'failed',
                                'jobUuid': job_id,
                                'chapterId': job_data.get('chapterId', 0),
                                'pageIndex': job_data.get('pageIndex', 0),
                                's3Original': s3_path,
                                'error': 'Failed to process variants',
                                'processing_time': time.time() - start_time,
                                'worker_id': self.worker_id
                            }
                            
                        logger.info(f"✅ Successfully processed {len(variant_results)} variants: {list(variant_results.keys())}")
                        
                        # Return success result in expected format
                        return {
                            'status': 'completed',
                            'jobUuid': job_id,
                            'chapterId': job_data.get('chapterId', 0),
                            'pageIndex': job_data.get('pageIndex', 0),
                            's3Original': s3_path,
                            'paths': variant_results,
                            'processing_time': time.time() - start_time,
                            'worker_id': self.worker_id,
                            'resource_state': resource_state
                        }
            
        except Exception as e:
            logger.error(f"❌ Error processing job {job_id}: {e}", exc_info=True)
            return {
                'status': 'failed',
                'jobUuid': job_id,
                'chapterId': job_data.get('chapterId', 0),
                'pageIndex': job_data.get('pageIndex', 0),
                's3Original': s3_path,
                'error': str(e),
                'processing_time': time.time() - start_time,
                'worker_id': self.worker_id
            }
    
    def handle_job_result(self, job_uuid: str, result: Dict, event_queue: str):
        """Handle job processing result"""
        try:
            # Update metrics
            processing_time = result.get('processing_time', 0)
            self.update_job_metrics(result['status'] == 'completed', processing_time)
            
            # Check for duplicate outcome
            if self.job_manager.outcome_exists(job_uuid):
                logger.info(f"🟡 Outcome already exists for {job_uuid}, skipping event")
                return
            
            # Store outcome FIRST (atomic idempotency barrier)
            # This prevents race conditions where duplicate jobs check before outcome is saved
            self.job_manager.set_job_outcome(job_uuid, result)
            
            # Send event to Laravel (now safe - outcome is recorded)
            if self.redis_manager.push_event(event_queue, result):
                logger.debug(f"📡 Event sent for job {job_uuid}")
            else:
                logger.error(f"❌ Failed to send event for job {job_uuid}")
            
            # Handle failures
            if result['status'] != 'completed':
                self.consecutive_failures += 1
                
                # Move to DLQ if too many failures
                if self.consecutive_failures >= WorkerConfig.MAX_CONSECUTIVE_FAILURES:
                    logger.warning(f"⚠️ Moving job {job_uuid} to dead letter queue")
                    original_job_data = result.copy()
                    original_job_data.pop('status', None)
                    original_job_data.pop('error', None)
                    self.job_manager.move_to_dlq(original_job_data, result.get('error', 'Unknown error'))
            else:
                self.consecutive_failures = 0
                
        except Exception as e:
            logger.error(f"❌ Error handling job result for {job_uuid}: {e}")
    
    def update_job_metrics(self, success: bool, processing_time: float):
        """Update job processing metrics"""
        current_time = time.time()
        
        if success:
            self.job_metrics.total_processed += 1
        else:
            self.job_metrics.total_failed += 1
        
        self.job_metrics.total_processing_time += processing_time
        self.job_metrics.last_job_at = current_time
        
        # Calculate derived metrics
        total_jobs = self.job_metrics.total_processed + self.job_metrics.total_failed
        if total_jobs > 0:
            self.job_metrics.avg_processing_time = self.job_metrics.total_processing_time / total_jobs
            self.job_metrics.success_rate = (self.job_metrics.total_processed / total_jobs) * 100
        
        # Calculate jobs per hour
        uptime_hours = (current_time - self.start_time) / 3600
        if uptime_hours > 0:
            self.job_metrics.jobs_per_hour = total_jobs / uptime_hours
    
    def log_metrics(self, force: bool = False):
        """Log comprehensive metrics"""
        current_time = time.time()
        
        if not force and current_time - self.last_metrics_log < 300:  # Every 5 minutes
            return
        
        self.last_metrics_log = current_time
        uptime = current_time - self.start_time
        
        logger.info(f"📊 Worker Metrics (uptime: {uptime/3600:.1f}h)")
        logger.info(f"   Jobs: {self.job_metrics.total_processed} processed, {self.job_metrics.total_failed} failed")
        logger.info(f"   Success rate: {self.job_metrics.success_rate:.1f}%")
        logger.info(f"   Avg processing time: {self.job_metrics.avg_processing_time:.1f}s")
        logger.info(f"   Jobs per hour: {self.job_metrics.jobs_per_hour:.1f}")
        logger.info(f"   Current jobs: {len(self.current_jobs)}")
        
        # Log Redis metrics
        if self.redis_manager:
            redis_metrics = self.redis_manager.get_metrics()
            logger.info(f"   Redis: {redis_metrics['status']} ({redis_metrics['health']})")
            logger.info(f"   Redis response: {redis_metrics['connection_metrics']['avg_response_time']:.1f}ms")
        
        # Log S3 metrics  
        if self.s3_manager:
            s3_metrics = self.s3_manager.get_metrics()
            logger.info(f"   S3: {s3_metrics['status']}")
    
    def cleanup_resources(self):
        """Clean up all resources"""
        logger.info("🧹 Cleaning up resources...")
        
        try:
            # Wait for current jobs to complete
            if self.current_jobs:
                logger.info(f"⏳ Waiting for {len(self.current_jobs)} jobs to complete...")
                GRACEFUL_KILLER.wait_for_jobs(timeout=30)
            
            # Shutdown thread pool
            if self.thread_pool:
                logger.info("🛑 Shutting down thread pool...")
                self.thread_pool.shutdown(wait=True)
                self.thread_pool = None
            
            # Unregister worker
            if self.worker_registry:
                self.worker_registry.unregister()
            
            # Close connections
            if self.redis_manager:
                self.redis_manager.disconnect()
            
            # Final metrics
            self.log_metrics(force=True)
            
            # Garbage collection
            gc.collect()
            
            logger.info("✅ Cleanup completed")
            
        except Exception as e:
            logger.error(f"❌ Error during cleanup: {e}")
    
    def run(self) -> bool:
        """Main worker loop with enhanced error handling and graceful shutdown"""
        logger.info(f"🚀 Starting Enhanced ESRGAN Worker v{WorkerConfig.WORKER_VERSION}")
        
        try:
            # Initialize all managers
            if not self.initialize_managers():
                logger.error("❌ Failed to initialize worker")
                return False
            
            self.state = WorkerState.IDLE
            logger.info("🏃 Worker ready - waiting for jobs...")
            
            # Main processing loop
            last_heartbeat = 0
            no_job_count = 0
            
            while not GRACEFUL_KILLER.kill_now:
                try:
                    current_time = time.time()
                    
                    # Perform health check
                    if not self.health_check():
                        logger.error("❌ Health check failed")
                        break
                    
                    # Register heartbeat
                    if current_time - last_heartbeat > WorkerConfig.REGISTRATION_TTL / 2:
                        self.register_heartbeat()
                        last_heartbeat = current_time
                    
                    # Check for graceful shutdown
                    if GRACEFUL_KILLER.kill_now:
                        logger.info("🛑 Graceful shutdown requested")
                        break
                    
                    # Get next job
                    job_result = self.get_job_from_queue(timeout=5)
                    
                    if job_result is None:
                        no_job_count += 1
                        
                        # Log periodic status when idle
                        if no_job_count % 12 == 0:  # Every minute (12 * 5 second timeout)
                            self.log_metrics()
                        
                        continue
                    
                    # Reset no-job counter
                    no_job_count = 0
                    
                    # Process job
                    source_queue, job_data = job_result
                    job_uuid = job_data.get('jobUuid', 'unknown')
                    event_queue = self.determine_event_queue(source_queue)
                    
                    # Claim job with distributed lock
                    if not self.job_manager.claim_job(job_uuid):
                        logger.info(f"🔒 Job {job_uuid} already claimed by another worker")
                        continue
                    
                    try:
                        self.state = WorkerState.PROCESSING
                        
                        # Register job as in progress
                        GRACEFUL_KILLER.add_job(job_uuid)
                        
                        with self.jobs_lock:
                            self.current_jobs[job_uuid] = {
                                'started_at': time.time(),
                                'data': job_data
                            }
                        
                        # Process job with real ESRGAN logic
                        result = self.process_job_sync(job_data)
                        
                        # Handle result
                        self.handle_job_result(job_uuid, result, event_queue)
                        
                    finally:
                        # Always clean up job tracking
                        GRACEFUL_KILLER.remove_job(job_uuid)
                        with self.jobs_lock:
                            self.current_jobs.pop(job_uuid, None)
                        
                        # Always release job lock
                        self.job_manager.release_job_lock(job_uuid)
                        self.state = WorkerState.IDLE
                    
                    # Periodic garbage collection
                    if self.job_metrics.total_processed % PerformanceConfig.GC_INTERVAL == 0:
                        gc.collect()
                
                except KeyboardInterrupt:
                    logger.info("⌨️ Keyboard interrupt received")
                    GRACEFUL_KILLER.kill_now = True
                    break
                
                except Exception as e:
                    logger.error(f"❌ Unexpected error in main loop: {e}")
                    self.consecutive_failures += 1
                    
                    # Activate circuit breaker on repeated failures  
                    if self.consecutive_failures >= WorkerConfig.MAX_CONSECUTIVE_FAILURES:
                        self.circuit_breaker_until = time.time() + WorkerConfig.CIRCUIT_BREAKER_TIMEOUT
                        logger.warning(f"🔴 Circuit breaker activated for {WorkerConfig.CIRCUIT_BREAKER_TIMEOUT}s")
                    
                    # Brief pause to prevent tight error loops
                    time.sleep(min(2 ** self.consecutive_failures, 30))
            
            self.state = WorkerState.SHUTTING_DOWN
            logger.info("🛑 Worker main loop ended")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Fatal error in worker: {e}")
            return False
        
        finally:
            self.state = WorkerState.SHUTTING_DOWN
            self.cleanup_resources()
            self.state = WorkerState.STOPPED
            logger.info("👋 Worker shutdown complete")

# === MAIN ENTRY POINT ===

def main():
    """Main entry point with enhanced error handling"""
    exit_code = 0
    
    try:
        # Create and run worker
        worker = EnhancedWorker()
        success = worker.run()
        exit_code = 0 if success else 1
        
    except KeyboardInterrupt:
        logger.info("⌨️ Keyboard interrupt - shutting down...")
        exit_code = 0
        
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        exit_code = 1
    
    finally:
        logger.info(f"🔚 Worker exiting with code {exit_code}")
        sys.exit(exit_code)

if __name__ == "__main__":
    main()