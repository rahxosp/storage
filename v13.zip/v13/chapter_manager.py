#!/usr/bin/env python3
"""
Chapter Management module for ESRGAN Worker
Contains ChapterPartManager class for Redis-based part numbering coordination
"""

import logging
from config import CHAPTER_COUNTER_TTL

logger = logging.getLogger(__name__)

class ChapterPartManager:
    """Manages part numbering across all images in a chapter"""
    
    def __init__(self, redis_client):
        self.redis = redis_client
    
    def get_chapter_key(self, manga_name: str, chapter_num: str, language: str) -> str:
        """Generate Redis key for chapter part counter"""
        return f"chapter:parts:{manga_name}:{chapter_num}:{language}"
    
    def get_next_part_number(self, manga_name: str, chapter_num: str, language: str, 
                            num_parts: int) -> int:
        """Get the next available part number for this chapter and increment by num_parts"""
        key = self.get_chapter_key(manga_name, chapter_num, language)
        
        # Use Redis pipeline for atomic operation
        pipe = self.redis.pipeline()
        pipe.get(key)
        pipe.incrby(key, num_parts)
        pipe.expire(key, CHAPTER_COUNTER_TTL)
        
        results = pipe.execute()
        current_value = results[0]
        
        # If key didn't exist, it starts at 1
        if current_value is None:
            return 1
        
        # Return the number before increment
        return int(current_value) + 1
    
    def reset_chapter_counter(self, manga_name: str, chapter_num: str, language: str):
        """Reset the counter for a chapter (useful for reprocessing)"""
        key = self.get_chapter_key(manga_name, chapter_num, language)
        self.redis.delete(key)
        logger.info(f"Reset part counter for {manga_name}/{chapter_num}/{language}")
    
    def get_current_part_number(self, manga_name: str, chapter_num: str, language: str) -> int:
        """Get current part number without incrementing"""
        key = self.get_chapter_key(manga_name, chapter_num, language)
        value = self.redis.get(key)
        return int(value) if value else 0
