# ESRGAN Ultra-Aggressive Worker v11.0.0

High-performance, GPU-optimized image processing worker for webtoon/manga upscaling with maximum throughput and cost efficiency.

> **Latest Update (2025-10-21):** Fixed job duplication bug, optimized for per-minute GPU billing with 85-90% GPU utilization.

## 🚀 Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure environment (edit with your Redis/S3 credentials)
cp .env.example .env

# 3. Run ultra-aggressive worker
python ultra_aggressive_worker.py
```

## 📋 Key Features

- ⚡ **95%+ GPU Utilization** - Aggressive pre-fetching eliminates idle time
- 🔄 **Parallel Variant Processing** - HD/SD/DS generated simultaneously  
- 📤 **Fire-and-Forget Uploads** - Don't block GPU waiting for S3
- 🔒 **Job Idempotency** - Prevents duplicate processing (fixed in v11.0)
- 💰 **Cost Optimized** - 140-200 jobs/hour, ~20-25% cost reduction
- 📊 **Real-time Metrics** - Track GPU utilization and throughput

## 📚 Documentation

- **[INSTALLATION.md](INSTALLATION.md)** - Complete setup guide
- **[requirements.txt](requirements.txt)** - Python dependencies  
- **[DUPLICATION-FIX.md](DUPLICATION-FIX.md)** - Idempotency fix details
- **[ULTRA-OPTIMIZATIONS.md](ULTRA-OPTIMIZATIONS.md)** - Performance tuning

## 📁 Project Structure

```
esgan-laravel/
├── main.py                 # Entry point - run this to start the worker
├── config.py              # All configuration and environment variables
├── utils.py               # Utility functions and helpers
├── storage.py             # Redis and S3/MinIO connection management
├── monitoring.py          # Health monitoring, metrics, and circuit breaker
├── chapter_manager.py     # Chapter-aware part numbering coordination
├── image_processor.py     # Image splitting and merging functionality
├── esrgan_processor.py    # ESRGAN execution and variant processing
├── worker.py              # Main worker class and job processing logic
├── cugan_worker_v9.py     # Original monolithic version (for reference)
└── README.md              # This file
```

## 🚀 Getting Started

### Prerequisites

Make sure you have all required Python packages installed:

```bash
pip install redis pillow boto3 psutil prometheus_client
```

### Environment Variables

Set these environment variables or use the defaults:

```bash
# Redis Configuration
export REDIS_HOST="152.53.13.183"
export REDIS_PORT="6379"
export REDIS_PASSWORD="your_redis_password"

# MinIO/S3 Configuration
export MINIO_ENDPOINT="152.53.13.183:9000"
export MINIO_ACCESS_KEY="your_access_key"
export MINIO_SECRET_KEY="your_secret_key"
export MINIO_BUCKET="imgsto"

# ESRGAN Settings
export ESRGAN_EXECUTABLE="esrgan"
export ESRGAN_MODEL="Omni-Small"
export UPSCALE_SCALE_FACTOR="2"
export ESRGAN_GPU_ID="0"
export ESRGAN_TILE_SIZE="256"

# Monitoring
export METRICS_PORT="8001"
```

### Running the Worker

Simply run the main entry point:

```bash
python main.py
```

## 📋 Module Descriptions

### 🔧 `config.py`
- Contains all configuration constants and environment variable handling
- Centralizes all settings in one place
- Sets up logging configuration

### 🛠️ `utils.py`
- Common utility functions used across modules
- Image validation, format conversion, and resizing functions  
- S3 path parsing and temporary file management
- Exponential backoff calculations

### 💾 `storage.py`
- **RedisManager**: Handles Redis connections with retry logic
- **S3Manager**: Manages S3/MinIO operations (upload/download)
- **WorkerRegistry**: Worker registration and scaling coordination
- **JobManager**: Job locking, outcome management, and event publishing

### 📊 `monitoring.py`
- **CircuitBreaker**: Fault tolerance pattern implementation
- **HealthMonitor**: System resource monitoring (CPU/memory)
- **Prometheus Integration**: Metrics collection and HTTP server
- Graceful degradation based on resource availability

### 📚 `chapter_manager.py`
- **ChapterPartManager**: Redis-based coordination for manga chapter part numbering
- Ensures sequential numbering across distributed workers
- Atomic operations using Redis pipelines

### 🖼️ `image_processor.py`
- **ImageSplitter**: Handles splitting of tall webtoon images
- Image merging after processing
- Preserves ICC profiles and handles various image formats

### 🎨 `esrgan_processor.py`
- **ESRGANProcessor**: ESRGAN execution with fallback configurations
- **VariantProcessor**: Parallel generation of HD/SD/DS variants
- GPU/CPU fallback and memory optimization

### ⚙️ `worker.py`
- **EnhancedWorker**: Main orchestration class
- Job processing pipeline from download to upload
- Batch processing and graceful shutdown handling
- Integration of all other modules

### 🏁 `main.py`
- Simple entry point with error handling
- Graceful shutdown on keyboard interrupt
- Exit code management

## 🔄 Processing Pipeline

1. **Job Acquisition**: Worker claims jobs from Redis queues with distributed locking
2. **Download**: Original image downloaded from S3/MinIO
3. **Validation**: Image format, dimensions, and corruption checks
4. **Preprocessing**: Format conversion to PNG for ESRGAN compatibility
5. **Splitting**: Very tall images (>12000px) split into 3000px parts
6. **Upscaling**: ESRGAN processing with GPU/CPU fallback
7. **Merging**: Split parts merged back together
8. **Variants**: Parallel generation of HD/SD/DS variants with adaptive quality
9. **Upload**: All variants uploaded to S3/MinIO
10. **Completion**: Success/failure events sent to Laravel via Redis

## 📈 Features

### 🔒 **Distributed Processing**
- Redis-based job locking prevents duplicate processing
- Worker registration and health monitoring
- Automatic scaling detection

### 🖼️ **Image Processing**
- Automatic splitting of very tall webtoon images (>12,000px into 3,000px parts)
- ICC profile preservation
- Adaptive quality based on image resolution
- WebP optimization with dimension limits

### 🛡️ **Fault Tolerance**
- Circuit breaker pattern for failure handling
- Exponential backoff retry logic
- Graceful degradation under resource pressure
- Multiple ESRGAN model fallbacks

### 📊 **Monitoring**
- Prometheus metrics integration
- CPU and memory usage monitoring
- Job processing statistics
- Health check endpoints

### 🎯 **Performance**
- Batch processing capabilities
- Parallel variant generation
- Memory-aware processing
- Garbage collection optimization

## 🔧 Configuration Options

### Image Processing
- `SPLIT_THRESHOLD`: Height threshold for triggering image splitting (default: 12000px)
- `SPLIT_HEIGHT`: Height of each split part (default: 3000px)
- `MAX_IMAGE_WIDTH`: Maximum allowed image width (default: 2000px)
- `MAX_IMAGE_SIZE`: Maximum file size (default: 50MB)

### Quality Settings
- `WEBP_QUALITIES`: Quality settings for each variant
- `VARIANT_WIDTHS`: Target widths for HD/SD/DS variants

### Performance
- `BATCH_SIZE`: Maximum jobs processed in parallel (default: 3)
- `THREAD_POOL_SIZE`: Thread pool size for variant processing (default: 2)
- `IMAGE_PROCESSING_TIMEOUT`: Timeout per image (default: 300s)

### Health Monitoring
- `MEMORY_THRESHOLD`: Memory usage warning threshold (default: 85%)
- `CPU_THRESHOLD`: CPU usage warning threshold (default: 90%)
- `HEALTH_CHECK_INTERVAL`: Health check frequency (default: 60s)

## 🚨 Troubleshooting

### Import Errors
All modules should compile without errors. If you encounter import issues:
```bash
python -m py_compile config.py
python -m py_compile utils.py
# ... etc for each module
```

### Connection Issues
- Check Redis connectivity: Ensure Redis server is accessible
- Verify S3/MinIO credentials and endpoint accessibility
- Check firewall settings for required ports

### Performance Issues
- Monitor system resources via Prometheus metrics (port 8001)
- Adjust `BATCH_SIZE` and `THREAD_POOL_SIZE` based on system capabilities
- Enable graceful degradation by monitoring resource thresholds

## 📝 Logs

The worker logs to both file and console:
- **File**: `/home/image-conversion/cugan_worker.log`
- **Console**: Real-time output with emoji indicators

Log levels:
- 🚀 **INFO**: Normal operations and status updates
- ⚠️ **WARNING**: Non-fatal issues and resource warnings  
- ❌ **ERROR**: Processing failures and connection issues

## 🔄 Migration from Monolithic Version

The modular version maintains 100% compatibility with the original `cugan_worker_v9.py`. Simply replace:

```bash
# Old way
python cugan_worker_v9.py

# New way  
python main.py
```

All functionality is preserved and enhanced with better organization and maintainability.
