#!/usr/bin/env python3
"""
Concurrent Pipeline ESRGAN Worker - Maximum GPU Utilization
This worker uses a fully concurrent multi-stage pipeline:
- Downloads job N+1 while GPU processes job N
- Uploads results of job N-1 while GPU processes job N
- Multiple jobs in flight simultaneously across different pipeline stages
- Maintains GPU at near 100% utilization
"""

import os
import sys
import time
import threading
import queue
from typing import Dict, Optional, Any, List
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from dataclasses import dataclass, field

from improved_config import (
    WorkerConfig, QueueConfig, PerformanceConfig, 
    GRACEFUL_KILLER, logger
)
from improved_storage import (
    EnhancedRedisManager, EnhancedS3Manager,
    EnhancedWorkerRegistry, EnhancedJobManager
)
from worker import EnhancedWorker, WorkerState

@dataclass
class PipelineJob:
    """Represents a job in the pipeline"""
    job_uuid: str
    job_data: Dict[str, Any]
    source_queue: str
    event_queue: str
    
    # Stage data
    prepared_data: Optional[Dict] = None
    result_data: Optional[Dict] = None
    
    # Timing
    enqueued_at: float = field(default_factory=time.time)
    download_start: Optional[float] = None
    download_end: Optional[float] = None
    gpu_start: Optional[float] = None
    gpu_end: Optional[float] = None
    upload_start: Optional[float] = None
    upload_end: Optional[float] = None
    
    # Futures
    download_future: Optional[Future] = None
    gpu_future: Optional[Future] = None
    upload_future: Optional[Future] = None

class ConcurrentPipelineWorker(EnhancedWorker):
    """
    Worker with fully concurrent pipeline processing.
    
    Architecture:
    - Download thread pool: Fetches images from S3
    - GPU processing: Single threaded (GPU serializes anyway)
    - Upload thread pool: Uploads results to S3
    - Pipeline coordinator: Manages job flow between stages
    
    This allows:
    - Job N: GPU processing
    - Job N+1: Downloading (parallel with N)
    - Job N-1: Uploading (parallel with N)
    """
    
    def __init__(self):
        super().__init__()
        
        # Pipeline queues (thread-safe)
        self.download_queue = queue.Queue()  # Jobs waiting to download
        self.gpu_queue = queue.Queue()  # Jobs ready for GPU
        self.upload_queue = queue.Queue()  # Jobs ready to upload
        
        # Active jobs tracking
        self.active_jobs: Dict[str, PipelineJob] = {}
        self.active_jobs_lock = threading.Lock()
        
        # Thread pools
        self.download_pool = ThreadPoolExecutor(
            max_workers=2,  # Pre-fetch 2 jobs ahead
            thread_name_prefix="download"
        )
        self.upload_pool = ThreadPoolExecutor(
            max_workers=3,  # Can upload 3 jobs concurrently
            thread_name_prefix="upload"
        )
        
        # Pipeline control
        self.pipeline_running = False
        self.pipeline_thread = None
        
        # Enhanced metrics
        self.pipeline_metrics = {
            'jobs_in_download': 0,
            'jobs_in_gpu': 0,
            'jobs_in_upload': 0,
            'total_download_time': 0.0,
            'total_gpu_time': 0.0,
            'total_upload_time': 0.0,
            'total_pipeline_time': 0.0,
            'gpu_idle_time': 0.0,
            'last_gpu_finish': None
        }
        self.metrics_lock = threading.Lock()
        
        logger.info("🚀 Concurrent Pipeline Worker initialized")
        logger.info("   Download workers: 2")
        logger.info("   GPU workers: 1 (serialized)")
        logger.info("   Upload workers: 3")
    
    def download_stage(self, pipeline_job: PipelineJob) -> bool:
        """Stage 1: Download and prepare image"""
        from utils import temporary_file, parse_s3_path, validate_image, convert_image_format
        
        job_uuid = pipeline_job.job_uuid
        job_data = pipeline_job.job_data
        
        pipeline_job.download_start = time.time()
        
        with self.metrics_lock:
            self.pipeline_metrics['jobs_in_download'] += 1
        
        try:
            s3_path = job_data.get('s3Original', '')
            logger.info(f"⬇️  [{job_uuid}] Download stage started")
            
            # Parse S3 path
            parsed = parse_s3_path(s3_path)
            if not parsed:
                logger.error(f"❌ [{job_uuid}] Could not parse S3 path")
                return False
            
            # Download and prepare
            with temporary_file(suffix='.tmp') as temp_input:
                if not self.s3_manager.download_file_with_retry(s3_path, temp_input):
                    logger.error(f"❌ [{job_uuid}] Download failed")
                    return False
                
                # Validate
                is_valid, error_msg, needs_split = validate_image(temp_input)
                if not is_valid:
                    logger.error(f"❌ [{job_uuid}] Invalid: {error_msg}")
                    return False
                
                # Convert to PNG
                with temporary_file(suffix='.png') as temp_png:
                    if not convert_image_format(temp_input, temp_png):
                        logger.error(f"❌ [{job_uuid}] Conversion failed")
                        return False
                    
                    # Load into memory
                    with open(temp_png, 'rb') as f:
                        png_data = f.read()
            
            pipeline_job.prepared_data = {
                'job_uuid': job_uuid,
                'job_data': job_data,
                'parsed': parsed,
                'png_data': png_data,
                'needs_split': needs_split
            }
            
            pipeline_job.download_end = time.time()
            download_time = pipeline_job.download_end - pipeline_job.download_start
            
            with self.metrics_lock:
                self.pipeline_metrics['jobs_in_download'] -= 1
                self.pipeline_metrics['total_download_time'] += download_time
            
            logger.info(f"✅ [{job_uuid}] Download completed in {download_time:.2f}s")
            
            # Move to GPU queue
            self.gpu_queue.put(pipeline_job)
            return True
            
        except Exception as e:
            logger.error(f"❌ [{job_uuid}] Download error: {e}")
            return False
        finally:
            with self.metrics_lock:
                if self.pipeline_metrics['jobs_in_download'] > 0:
                    self.pipeline_metrics['jobs_in_download'] -= 1
    
    def gpu_stage(self, pipeline_job: PipelineJob) -> bool:
        """Stage 2: GPU processing (ESRGAN)"""
        from esrgan_processor import ESRGANProcessor, VariantProcessor
        from utils import temporary_file
        import psutil
        
        job_uuid = pipeline_job.job_uuid
        prepared_data = pipeline_job.prepared_data
        
        if not prepared_data:
            logger.error(f"❌ [{job_uuid}] No prepared data")
            return False
        
        pipeline_job.gpu_start = time.time()
        
        # Track GPU idle time
        with self.metrics_lock:
            if self.pipeline_metrics['last_gpu_finish']:
                idle = pipeline_job.gpu_start - self.pipeline_metrics['last_gpu_finish']
                self.pipeline_metrics['gpu_idle_time'] += idle
                if idle > 0.1:  # Only log significant gaps
                    logger.warning(f"⏱️  GPU was idle for {idle:.2f}s")
            self.pipeline_metrics['jobs_in_gpu'] += 1
        
        try:
            job_data = prepared_data['job_data']
            parsed = prepared_data['parsed']
            png_data = prepared_data['png_data']
            variants = job_data.get('variants', ['hd', 'sd', 'ds'])
            
            logger.info(f"🎮 [{job_uuid}] GPU stage started")
            
            # Write PNG to temp file
            with temporary_file(suffix='.png') as temp_png:
                with open(temp_png, 'wb') as f:
                    f.write(png_data)
                
                # ESRGAN upscaling
                esrgan_processor = ESRGANProcessor(self.s3_manager)
                with temporary_file(suffix='.png') as temp_upscaled:
                    if not esrgan_processor.run_esrgan_with_fallback(temp_png, temp_upscaled):
                        logger.error(f"❌ [{job_uuid}] ESRGAN failed")
                        return False
                    
                    # Determine resource state
                    memory = psutil.virtual_memory()
                    resource_state = 'CRITICAL' if memory.percent > 90 else 'HIGH' if memory.percent > 80 else 'NORMAL'
                    
                    # Process variants
                    variant_processor = VariantProcessor(self.s3_manager)
                    variant_results = variant_processor.process_variants_parallel(
                        temp_upscaled, parsed, variants, resource_state
                    )
                    
                    if not variant_results:
                        logger.error(f"❌ [{job_uuid}] Variant processing failed")
                        return False
            
            pipeline_job.gpu_end = time.time()
            gpu_time = pipeline_job.gpu_end - pipeline_job.gpu_start
            
            pipeline_job.result_data = {
                'job_uuid': job_uuid,
                'job_data': job_data,
                'variant_results': variant_results,
                'resource_state': resource_state,
                'processing_time': gpu_time
            }
            
            with self.metrics_lock:
                self.pipeline_metrics['jobs_in_gpu'] -= 1
                self.pipeline_metrics['total_gpu_time'] += gpu_time
                self.pipeline_metrics['last_gpu_finish'] = pipeline_job.gpu_end
            
            logger.info(f"✅ [{job_uuid}] GPU completed in {gpu_time:.2f}s")
            
            # Move to upload queue
            self.upload_queue.put(pipeline_job)
            return True
            
        except Exception as e:
            logger.error(f"❌ [{job_uuid}] GPU error: {e}")
            return False
        finally:
            with self.metrics_lock:
                if self.pipeline_metrics['jobs_in_gpu'] > 0:
                    self.pipeline_metrics['jobs_in_gpu'] -= 1
    
    def upload_stage(self, pipeline_job: PipelineJob) -> bool:
        """Stage 3: Upload results and report"""
        job_uuid = pipeline_job.job_uuid
        result_data = pipeline_job.result_data
        
        if not result_data:
            logger.error(f"❌ [{job_uuid}] No result data")
            return False
        
        pipeline_job.upload_start = time.time()
        
        with self.metrics_lock:
            self.pipeline_metrics['jobs_in_upload'] += 1
        
        try:
            logger.info(f"📤 [{job_uuid}] Upload stage started")
            
            job_data = result_data['job_data']
            s3_path = job_data.get('s3Original', '')
            
            # Prepare result
            result = {
                'status': 'completed',
                'jobUuid': job_uuid,
                'chapterId': job_data.get('chapterId', 0),
                'pageIndex': job_data.get('pageIndex', 0),
                's3Original': s3_path,
                'paths': result_data['variant_results'],
                'processing_time': result_data['processing_time'],
                'worker_id': self.worker_id,
                'resource_state': result_data['resource_state']
            }
            
            # Send result
            self.handle_job_result(job_uuid, result, pipeline_job.event_queue)
            
            pipeline_job.upload_end = time.time()
            upload_time = pipeline_job.upload_end - pipeline_job.upload_start
            
            with self.metrics_lock:
                self.pipeline_metrics['jobs_in_upload'] -= 1
                self.pipeline_metrics['total_upload_time'] += upload_time
            
            # Calculate total pipeline time
            total_time = pipeline_job.upload_end - pipeline_job.enqueued_at
            with self.metrics_lock:
                self.pipeline_metrics['total_pipeline_time'] += total_time
            
            logger.info(f"✅ [{job_uuid}] Upload completed in {upload_time:.2f}s (total: {total_time:.2f}s)")
            
            # Clean up
            with self.active_jobs_lock:
                self.active_jobs.pop(job_uuid, None)
            
            return True
            
        except Exception as e:
            logger.error(f"❌ [{job_uuid}] Upload error: {e}")
            return False
        finally:
            with self.metrics_lock:
                if self.pipeline_metrics['jobs_in_upload'] > 0:
                    self.pipeline_metrics['jobs_in_upload'] -= 1
    
    def pipeline_coordinator(self):
        """
        Coordinates job flow through pipeline stages.
        Runs GPU processing sequentially while I/O happens in parallel.
        """
        logger.info("🔄 Pipeline coordinator started")
        
        while self.pipeline_running and not GRACEFUL_KILLER.kill_now:
            try:
                # Process GPU queue (this is the critical path)
                try:
                    pipeline_job = self.gpu_queue.get(timeout=0.5)
                    
                    # Process on GPU (blocks until complete)
                    success = self.gpu_stage(pipeline_job)
                    
                    if not success:
                        # Handle failure
                        self.handle_failed_job(
                            pipeline_job.job_uuid,
                            pipeline_job.job_data,
                            "GPU processing failed",
                            pipeline_job.event_queue
                        )
                        with self.active_jobs_lock:
                            self.active_jobs.pop(pipeline_job.job_uuid, None)
                    
                except queue.Empty:
                    # No GPU work, brief sleep
                    time.sleep(0.1)
                    
            except Exception as e:
                logger.error(f"❌ Pipeline coordinator error: {e}")
                time.sleep(1)
        
        logger.info("🛑 Pipeline coordinator stopped")
    
    def handle_failed_job(self, job_uuid: str, job_data: Dict, error: str, event_queue: str):
        """Handle job failure"""
        result = {
            'status': 'failed',
            'jobUuid': job_uuid,
            'chapterId': job_data.get('chapterId', 0),
            'pageIndex': job_data.get('pageIndex', 0),
            's3Original': job_data.get('s3Original', ''),
            'error': error,
            'worker_id': self.worker_id
        }
        self.handle_job_result(job_uuid, result, event_queue)
    
    def enqueue_job(self, source_queue: str, job_data: Dict) -> bool:
        """Enqueue a new job into the pipeline with atomic claim check"""
        job_uuid = job_data.get('jobUuid', 'unknown')
        
        try:
            # CRITICAL: Claim job FIRST before any processing
            # This prevents duplicate processing by multiple workers
            if not self.job_manager.claim_job(job_uuid):
                logger.debug(f"⏭️  [{job_uuid}] Already claimed by another worker, skipping")
                return False
            
            # Check if outcome already exists (job was already completed)
            if self.job_manager.outcome_exists(job_uuid):
                logger.info(f"✅ [{job_uuid}] Already completed, skipping")
                self.job_manager.release_job_lock(job_uuid)
                return False
            
            GRACEFUL_KILLER.add_job(job_uuid)
            
            # Create pipeline job
            event_queue = self.determine_event_queue(source_queue)
            pipeline_job = PipelineJob(
                job_uuid=job_uuid,
                job_data=job_data,
                source_queue=source_queue,
                event_queue=event_queue
            )
            
            with self.active_jobs_lock:
                # Double-check we don't already have this job
                if job_uuid in self.active_jobs:
                    logger.warning(f"⚠️  [{job_uuid}] Already in active jobs, skipping")
                    GRACEFUL_KILLER.remove_job(job_uuid)
                    self.job_manager.release_job_lock(job_uuid)
                    return False
                
                self.active_jobs[job_uuid] = pipeline_job
            
            logger.info(f"📥 [{job_uuid}] Enqueued to pipeline")
            
            # Start download in background
            pipeline_job.download_future = self.download_pool.submit(
                self.download_stage, pipeline_job
            )
            
            # Start upload monitor in background (will process when ready)
            def monitor_upload():
                try:
                    upload_job = self.upload_queue.get()
                    self.upload_stage(upload_job)
                finally:
                    GRACEFUL_KILLER.remove_job(upload_job.job_uuid)
                    self.job_manager.release_job_lock(upload_job.job_uuid)
            
            self.upload_pool.submit(monitor_upload)
            
            return True
            
        except Exception as e:
            logger.error(f"❌ [{job_uuid}] Enqueue error: {e}")
            GRACEFUL_KILLER.remove_job(job_uuid)
            self.job_manager.release_job_lock(job_uuid)
            return False
    
    def run(self) -> bool:
        """Main worker loop with concurrent pipeline"""
        logger.info(f"🚀 Starting Concurrent Pipeline Worker v{WorkerConfig.WORKER_VERSION}")
        
        try:
            # Initialize
            if not self.initialize_managers():
                logger.error("❌ Initialization failed")
                return False
            
            self.state = WorkerState.IDLE
            self.pipeline_running = True
            
            # Start pipeline coordinator thread
            self.pipeline_thread = threading.Thread(
                target=self.pipeline_coordinator,
                name="pipeline-coordinator",
                daemon=True
            )
            self.pipeline_thread.start()
            
            logger.info("🏃 Concurrent pipeline worker ready")
            logger.info("   Pipeline stages running in parallel")
            logger.info("   GPU processing will overlap with I/O operations")
            
            # Main loop: Feed jobs into pipeline
            last_heartbeat = 0
            no_job_count = 0
            
            while not GRACEFUL_KILLER.kill_now:
                try:
                    current_time = time.time()
                    
                    # Health check
                    if not self.health_check():
                        logger.error("❌ Health check failed")
                        break
                    
                    # Heartbeat
                    if current_time - last_heartbeat > WorkerConfig.REGISTRATION_TTL / 2:
                        self.register_heartbeat()
                        last_heartbeat = current_time
                    
                    # Get next job
                    job_result = self.get_job_from_queue(timeout=5)
                    
                    if job_result is None:
                        no_job_count += 1
                        if no_job_count % 12 == 0:
                            self.log_pipeline_metrics()
                        continue
                    
                    no_job_count = 0
                    source_queue, job_data = job_result
                    
                    # Enqueue into pipeline
                    self.state = WorkerState.PROCESSING
                    self.enqueue_job(source_queue, job_data)
                    self.state = WorkerState.IDLE
                    
                except KeyboardInterrupt:
                    logger.info("⌨️ Keyboard interrupt")
                    GRACEFUL_KILLER.kill_now = True
                    break
                    
                except Exception as e:
                    logger.error(f"❌ Main loop error: {e}")
                    time.sleep(2)
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Fatal error: {e}")
            return False
            
        finally:
            self.pipeline_running = False
            
            # Wait for pipeline to finish
            logger.info("⏳ Waiting for pipeline to drain...")
            time.sleep(2)
            
            # Shutdown pools
            logger.info("🛑 Shutting down thread pools...")
            self.download_pool.shutdown(wait=True)
            self.upload_pool.shutdown(wait=True)
            
            self.cleanup_resources()
            logger.info("👋 Concurrent pipeline worker shutdown complete")
    
    def log_pipeline_metrics(self):
        """Log detailed pipeline metrics"""
        with self.metrics_lock:
            m = self.pipeline_metrics.copy()
        
        total_jobs = self.job_metrics.total_processed + self.job_metrics.total_failed
        
        if total_jobs > 0:
            avg_download = m['total_download_time'] / total_jobs
            avg_gpu = m['total_gpu_time'] / total_jobs
            avg_upload = m['total_upload_time'] / total_jobs
            avg_total = m['total_pipeline_time'] / total_jobs
            
            # GPU utilization calculation
            total_time = time.time() - self.start_time
            gpu_active_time = m['total_gpu_time']
            gpu_util = (gpu_active_time / total_time * 100) if total_time > 0 else 0
            
            logger.info(f"📊 Concurrent Pipeline Metrics ({total_jobs} jobs)")
            logger.info(f"   Active: Download={m['jobs_in_download']}, GPU={m['jobs_in_gpu']}, Upload={m['jobs_in_upload']}")
            logger.info(f"   Avg Download:  {avg_download:.2f}s")
            logger.info(f"   Avg GPU:       {avg_gpu:.2f}s")
            logger.info(f"   Avg Upload:    {avg_upload:.2f}s")
            logger.info(f"   Avg Pipeline:  {avg_total:.2f}s")
            logger.info(f"   GPU Util:      {gpu_util:.1f}% (wall time)")
            logger.info(f"   GPU Idle:      {m['gpu_idle_time']:.1f}s total")
            
            # Speedup calculation
            sequential_time = avg_download + avg_gpu + avg_upload
            speedup = sequential_time / avg_total if avg_total > 0 else 1.0
            logger.info(f"   Pipeline Speedup: {speedup:.2f}x vs sequential")
        
        with self.active_jobs_lock:
            logger.info(f"   Jobs in pipeline: {len(self.active_jobs)}")
        
        self.log_metrics()

def main():
    """Main entry point"""
    exit_code = 0
    
    try:
        worker = ConcurrentPipelineWorker()
        success = worker.run()
        exit_code = 0 if success else 1
        
    except KeyboardInterrupt:
        logger.info("⌨️ Keyboard interrupt - shutting down...")
        exit_code = 0
        
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        exit_code = 1
    
    finally:
        logger.info(f"🔚 Concurrent pipeline worker exiting with code {exit_code}")
        sys.exit(exit_code)

if __name__ == "__main__":
    main()
