#!/usr/bin/env python3
"""
Test script to compare S3/MinIO access using domain vs IP address
Tests stability, speed, and reliability of both approaches
"""

# Python 3.10+ compatibility fix
try:
    from collections.abc import Callable
    import collections
    collections.Callable = Callable
except (ImportError, AttributeError):
    pass

import boto3
import time
import statistics
from botocore.config import Config
from botocore.exceptions import ClientError
import os
import sys

# Import credentials from config.py
try:
    from config import MINIO_ENDPOINT, MINIO_ACCESS_KEY, MINIO_SECRET_KEY, MINIO_BUCKET
    ACCESS_KEY = MINIO_ACCESS_KEY
    SECRET_KEY = MINIO_SECRET_KEY
    BUCKET = MINIO_BUCKET
    DOMAIN_ENDPOINT = MINIO_ENDPOINT
    print(f"✓ Loaded credentials from config.py")
except ImportError:
    print("✗ Could not import config.py, using environment variables")
    ACCESS_KEY = os.getenv("S3_ACCESS_KEY", "your-access-key")
    SECRET_KEY = os.getenv("S3_SECRET_KEY", "your-secret-key")
    BUCKET = "rhub"
    DOMAIN_ENDPOINT = "https://readershub.space"

# Configuration
IP_ENDPOINT = "http://152.53.140.165:9000"  # Using HTTP for IP
TEST_KEY = "top-tier-providence/107/en/og/01.jpg"  # From your logs
NUM_TESTS = 10

def create_s3_client(endpoint_url: str, use_ssl: bool = True):
    """Create S3 client with specific endpoint"""
    config = Config(
        region_name='us-east-1',
        signature_version='s3v4',
        retries={'max_attempts': 1, 'mode': 'standard'},
        connect_timeout=5,
        read_timeout=10,
        max_pool_connections=50
    )
    
    return boto3.client(
        's3',
        endpoint_url=endpoint_url,
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        config=config,
        verify=False,  # Disable SSL verification for testing
        use_ssl=use_ssl
    )

def test_connection(client, endpoint_name: str):
    """Test basic connection to S3"""
    print(f"\n{'='*60}")
    print(f"Testing: {endpoint_name}")
    print(f"{'='*60}")
    
    # Test 1: List buckets
    try:
        start = time.time()
        response = client.list_buckets()
        elapsed = (time.time() - start) * 1000
        print(f"✓ List buckets: {elapsed:.2f}ms")
        print(f"  Found {len(response['Buckets'])} buckets")
    except Exception as e:
        print(f"✗ List buckets failed: {e}")
        return False
    
    # Test 2: Check bucket exists
    try:
        start = time.time()
        client.head_bucket(Bucket=BUCKET)
        elapsed = (time.time() - start) * 1000
        print(f"✓ Head bucket: {elapsed:.2f}ms")
    except Exception as e:
        print(f"✗ Head bucket failed: {e}")
        return False
    
    return True

def test_object_access(client, endpoint_name: str, num_tests: int = 10):
    """Test object access speed and reliability"""
    print(f"\n{'-'*60}")
    print(f"Testing object access: {TEST_KEY}")
    print(f"{'-'*60}")
    
    head_times = []
    head_failures = 0
    download_times = []
    download_failures = 0
    
    for i in range(num_tests):
        # Test HEAD object (metadata only)
        try:
            start = time.time()
            response = client.head_object(Bucket=BUCKET, Key=TEST_KEY)
            elapsed = (time.time() - start) * 1000
            head_times.append(elapsed)
            size_mb = response['ContentLength'] / (1024 * 1024)
            if i == 0:
                print(f"  Object size: {size_mb:.2f} MB")
        except ClientError as e:
            head_failures += 1
            error_code = e.response['Error']['Code']
            print(f"  ✗ HEAD attempt {i+1} failed: {error_code}")
        except Exception as e:
            head_failures += 1
            print(f"  ✗ HEAD attempt {i+1} failed: {e}")
        
        time.sleep(0.1)  # Brief pause between tests
        
        # Test GET object (full download) every 3rd attempt
        if i % 3 == 0:
            try:
                start = time.time()
                response = client.get_object(Bucket=BUCKET, Key=TEST_KEY)
                data = response['Body'].read()
                elapsed = (time.time() - start) * 1000
                download_times.append(elapsed)
                speed_mbps = (len(data) / (1024 * 1024)) / (elapsed / 1000)
                print(f"  ✓ Download {i+1}: {elapsed:.2f}ms ({speed_mbps:.2f} MB/s)")
            except ClientError as e:
                download_failures += 1
                error_code = e.response['Error']['Code']
                print(f"  ✗ Download attempt {i+1} failed: {error_code}")
            except Exception as e:
                download_failures += 1
                print(f"  ✗ Download attempt {i+1} failed: {e}")
    
    # Calculate statistics
    print(f"\n{'='*60}")
    print(f"Results for {endpoint_name}")
    print(f"{'='*60}")
    
    if head_times:
        print(f"\nHEAD Object Stats ({len(head_times)} successful):")
        print(f"  Min:     {min(head_times):.2f}ms")
        print(f"  Max:     {max(head_times):.2f}ms")
        print(f"  Mean:    {statistics.mean(head_times):.2f}ms")
        print(f"  Median:  {statistics.median(head_times):.2f}ms")
        if len(head_times) > 1:
            print(f"  StdDev:  {statistics.stdev(head_times):.2f}ms")
        print(f"  Failures: {head_failures}/{num_tests}")
        print(f"  Success rate: {((num_tests - head_failures) / num_tests * 100):.1f}%")
    else:
        print(f"\n✗ All HEAD requests failed ({head_failures}/{num_tests})")
    
    if download_times:
        print(f"\nGET Object Stats ({len(download_times)} successful):")
        print(f"  Min:     {min(download_times):.2f}ms")
        print(f"  Max:     {max(download_times):.2f}ms")
        print(f"  Mean:    {statistics.mean(download_times):.2f}ms")
        print(f"  Median:  {statistics.median(download_times):.2f}ms")
        if len(download_times) > 1:
            print(f"  StdDev:  {statistics.stdev(download_times):.2f}ms")
        expected_downloads = (num_tests // 3) + 1
        print(f"  Failures: {download_failures}/{expected_downloads}")
        print(f"  Success rate: {((expected_downloads - download_failures) / expected_downloads * 100):.1f}%")
    else:
        print(f"\n✗ All download requests failed")
    
    return {
        'head_times': head_times,
        'head_failures': head_failures,
        'head_success_rate': ((num_tests - head_failures) / num_tests * 100),
        'download_times': download_times,
        'download_failures': download_failures,
        'avg_head_time': statistics.mean(head_times) if head_times else float('inf'),
        'avg_download_time': statistics.mean(download_times) if download_times else float('inf')
    }

def main():
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║      MinIO S3 Access: Domain vs IP Comparison Test          ║
╚══════════════════════════════════════════════════════════════╝

Configuration:
  Domain endpoint:  {DOMAIN_ENDPOINT}
  IP endpoint:      {IP_ENDPOINT}
  Bucket:           {BUCKET}
  Test object:      {TEST_KEY}
  Number of tests:  {NUM_TESTS}

Note: Credentials loaded from config.py
""")
    
    if ACCESS_KEY == "your-access-key" or not ACCESS_KEY:
        print("⚠️  ERROR: No valid credentials found!")
        print("   Make sure config.py has MINIO_ACCESS_KEY and MINIO_SECRET_KEY")
        return
    
    # Test 1: Domain-based endpoint
    print("\n" + "█" * 60)
    print("TEST 1: Domain-based endpoint (HTTPS)")
    print("█" * 60)
    
    try:
        domain_client = create_s3_client(DOMAIN_ENDPOINT, use_ssl=True)
        if test_connection(domain_client, "Domain (HTTPS)"):
            domain_results = test_object_access(domain_client, "Domain (HTTPS)", NUM_TESTS)
        else:
            domain_results = None
            print("✗ Domain connection failed, skipping object tests")
    except Exception as e:
        print(f"✗ Failed to create domain client: {e}")
        domain_results = None
    
    time.sleep(1)  # Pause between tests
    
    # Test 2: IP-based endpoint
    print("\n" + "█" * 60)
    print("TEST 2: IP-based endpoint (HTTP)")
    print("█" * 60)
    
    try:
        ip_client = create_s3_client(IP_ENDPOINT, use_ssl=False)
        if test_connection(ip_client, "IP (HTTP)"):
            ip_results = test_object_access(ip_client, "IP (HTTP)", NUM_TESTS)
        else:
            ip_results = None
            print("✗ IP connection failed, skipping object tests")
    except Exception as e:
        print(f"✗ Failed to create IP client: {e}")
        ip_results = None
    
    # Comparison
    print("\n" + "█" * 60)
    print("FINAL COMPARISON")
    print("█" * 60)
    
    if domain_results and ip_results:
        print(f"\n{'Metric':<30} {'Domain (HTTPS)':<20} {'IP (HTTP)':<20} {'Winner':<10}")
        print("-" * 80)
        
        # HEAD success rate
        domain_head_rate = domain_results['head_success_rate']
        ip_head_rate = ip_results['head_success_rate']
        winner = "IP" if ip_head_rate > domain_head_rate else "Domain" if domain_head_rate > ip_head_rate else "Tie"
        print(f"{'HEAD Success Rate':<30} {domain_head_rate:>6.1f}%{'':<13} {ip_head_rate:>6.1f}%{'':<13} {winner:<10}")
        
        # HEAD speed
        domain_head_avg = domain_results['avg_head_time']
        ip_head_avg = ip_results['avg_head_time']
        winner = "IP" if ip_head_avg < domain_head_avg else "Domain" if domain_head_avg < ip_head_avg else "Tie"
        print(f"{'Avg HEAD Time':<30} {domain_head_avg:>6.1f}ms{'':<12} {ip_head_avg:>6.1f}ms{'':<12} {winner:<10}")
        
        # Download speed
        domain_dl_avg = domain_results['avg_download_time']
        ip_dl_avg = ip_results['avg_download_time']
        if domain_dl_avg != float('inf') and ip_dl_avg != float('inf'):
            winner = "IP" if ip_dl_avg < domain_dl_avg else "Domain" if domain_dl_avg < ip_dl_avg else "Tie"
            print(f"{'Avg Download Time':<30} {domain_dl_avg:>6.1f}ms{'':<12} {ip_dl_avg:>6.1f}ms{'':<12} {winner:<10}")
        
        print("\n" + "=" * 80)
        print("RECOMMENDATION:")
        print("=" * 80)
        
        # Calculate overall score
        domain_score = 0
        ip_score = 0
        
        if ip_head_rate > domain_head_rate:
            ip_score += 2
        elif domain_head_rate > ip_head_rate:
            domain_score += 2
        
        if ip_head_avg < domain_head_avg:
            ip_score += 1
        elif domain_head_avg < ip_head_avg:
            domain_score += 1
        
        if domain_dl_avg != float('inf') and ip_dl_avg != float('inf'):
            if ip_dl_avg < domain_dl_avg:
                ip_score += 1
            elif domain_dl_avg < ip_dl_avg:
                domain_score += 1
        
        if ip_score > domain_score:
            print(f"\n✅ USE IP ENDPOINT: {IP_ENDPOINT}")
            print("   Better reliability and/or speed")
            print("\n   To use in your worker, update improved_config.py:")
            print(f"   S3Config.ENDPOINT = '{IP_ENDPOINT}'")
            print(f"   S3Config.USE_SSL = False")
        elif domain_score > ip_score:
            print(f"\n✅ USE DOMAIN ENDPOINT: {DOMAIN_ENDPOINT}")
            print("   Better reliability and/or speed")
            print("   Keep current configuration")
        else:
            print("\n⚖️  BOTH ENDPOINTS PERFORM SIMILARLY")
            print("   Choose based on your preference:")
            print(f"   - Domain: Easier to remember, works with SSL")
            print(f"   - IP: Bypasses DNS, potentially more stable")
    
    elif domain_results:
        print("\n✅ Only domain endpoint worked")
        print("   IP endpoint failed - check firewall/network settings")
    elif ip_results:
        print("\n✅ Only IP endpoint worked")
        print(f"   Use IP endpoint: {IP_ENDPOINT}")
        print("\n   To use in your worker, update improved_config.py:")
        print(f"   S3Config.ENDPOINT = '{IP_ENDPOINT}'")
        print(f"   S3Config.USE_SSL = False")
    else:
        print("\n✗ Both endpoints failed!")
        print("   Check:")
        print("   - Access key and secret key")
        print("   - Network connectivity")
        print("   - MinIO server is running")
        print("   - Firewall rules")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrupted by user")
    except Exception as e:
        print(f"\n\n✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
