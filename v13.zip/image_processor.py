#!/usr/bin/env python3
"""
Image Processing module for ESRGAN Worker
Contains ImageSplitter class and image manipulation functions
"""

import os
import logging
import shutil
from typing import List, Dict, Tuple
from PIL import Image
from config import SPLIT_HEIGHT, SPLIT_THRESHOLD

logger = logging.getLogger(__name__)

class ImageSplitter:
    """Handles splitting of tall images into parts"""
    
    @staticmethod
    def should_split(height: int, threshold: int = SPLIT_THRESHOLD) -> bool:
        """Determine if an image should be split based on height threshold"""
        return height > threshold
    
    @staticmethod
    def calculate_splits(height: int, split_height: int = SPLIT_HEIGHT) -> List[Tuple[int, int]]:
        """Calculate split boundaries for an image"""
        splits = []
        num_parts = (height + split_height - 1) // split_height
        
        for i in range(num_parts):
            top = i * split_height
            bottom = min((i + 1) * split_height, height)
            splits.append((top, bottom))
        
        return splits
    
    @staticmethod
    def split_image(image_path: str, split_height: int = SPLIT_HEIGHT) -> List[Dict]:
        """
        Split image into parts and return info about each part
        Returns list of dicts with keys: path, part_index, height
        """
        try:
            with Image.open(image_path) as img:
                width, height = img.size
                
                # Check if splitting is needed based on threshold
                if not ImageSplitter.should_split(height):
                    return [{'path': image_path, 'part_index': 0, 'height': height}]
                
                splits = ImageSplitter.calculate_splits(height, split_height)
                
                logger.info(f"🔪 Splitting {width}x{height} into {len(splits)} parts of {split_height}px each (threshold: {SPLIT_THRESHOLD}px)")
                
                parts_info = []
                base_path = os.path.splitext(image_path)[0]
                
                # Preserve ICC profile if present
                icc = img.info.get('icc_profile')
                
                for i, (top, bottom) in enumerate(splits):
                    part = img.crop((0, top, width, bottom))
                    part_path = f"{base_path}_split{i+1:03d}.png"
                    
                    save_kwargs = {'optimize': True}
                    if icc:
                        save_kwargs['icc_profile'] = icc
                    
                    part.save(part_path, 'PNG', **save_kwargs)
                    
                    parts_info.append({
                        'path': part_path,
                        'part_index': i,
                        'height': bottom - top,
                        'original_top': top,
                        'original_bottom': bottom
                    })
                    
                    logger.info(f"  Part {i+1}/{len(splits)}: {width}x{bottom-top} saved")
                
                return parts_info
                
        except Exception as e:
            logger.error(f"Failed to split image {image_path}: {e}")
            return [{'path': image_path, 'part_index': 0, 'height': 0}]

def split_tall_image(image_path: str) -> List[str]:
    """Split tall webtoon images into manageable chunks"""
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            
            # Don't split if below threshold
            if height <= SPLIT_THRESHOLD:
                return [image_path]
            
            # Calculate number of parts needed
            num_parts = (height + SPLIT_HEIGHT - 1) // SPLIT_HEIGHT
            part_height = height // num_parts
            
            logger.info(f"🔪 Splitting image {width}x{height} into {num_parts} parts of {SPLIT_HEIGHT}px each (threshold: {SPLIT_THRESHOLD}px)")
            
            split_paths = []
            for i in range(num_parts):
                # Calculate crop box
                top = i * part_height
                bottom = min((i + 1) * part_height, height)
                if i == num_parts - 1:  # Last part gets any remaining pixels
                    bottom = height
                
                # Crop and save part
                part = img.crop((0, top, width, bottom))
                
                # Save with part suffix
                base_path = os.path.splitext(image_path)[0]
                part_path = f"{base_path}_part{i+1:03d}.png"
                
                # Preserve ICC profile if present
                save_kwargs = {'optimize': True}
                if 'icc_profile' in img.info:
                    save_kwargs['icc_profile'] = img.info['icc_profile']
                
                part.save(part_path, 'PNG', **save_kwargs)
                split_paths.append(part_path)
                
                logger.info(f"  Part {i+1}/{num_parts}: {width}x{bottom-top} saved to {part_path}")
            
            return split_paths
            
    except Exception as e:
        logger.error(f"Failed to split image: {e}")
        return [image_path]  # Return original if split fails

def merge_processed_parts(part_paths: List[str], output_path: str) -> bool:
    """Merge processed image parts back together"""
    try:
        if len(part_paths) == 1:
            # No merging needed
            shutil.copy2(part_paths[0], output_path)
            return True
        
        # Load all parts and get dimensions
        parts = []
        total_height = 0
        width = 0
        
        for path in part_paths:
            part = Image.open(path)
            parts.append(part)
            if width == 0:
                width = part.width
            total_height += part.height
        
        # Create merged image
        merged = Image.new('RGB', (width, total_height))
        
        # Paste parts
        y_offset = 0
        for part in parts:
            merged.paste(part, (0, y_offset))
            y_offset += part.height
            part.close()
        
        # Save merged image
        save_kwargs = {'optimize': True}
        if parts and 'icc_profile' in parts[0].info:
            save_kwargs['icc_profile'] = parts[0].info['icc_profile']
        
        merged.save(output_path, 'PNG', **save_kwargs)
        merged.close()
        
        logger.info(f"🔗 Merged {len(parts)} parts into {width}x{total_height} image")
        return True
        
    except Exception as e:
        logger.error(f"Failed to merge image parts: {e}")
        return False
