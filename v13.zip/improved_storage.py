#!/usr/bin/env python3
"""
Enhanced Storage module for ESRGAN Worker v11.0
Professional-grade Redis and S3/MinIO management with connection pooling,
health monitoring, and robust error handling
"""

import os
import time
import json
import logging
import threading
import socket
import asyncio
from typing import Optional, Dict, List, Any, Union
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass, asdict
from enum import Enum

import redis
from redis.connection import ConnectionPool
from redis.exceptions import RedisError, ConnectionError as RedisConnectionError, TimeoutError as RedisTimeoutError

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError, NoCredentialsError, EndpointConnectionError

from improved_config import (
    RedisConfig, S3Config, QueueConfig, WorkerConfig, 
    MonitoringConfig, GRACEFUL_KILLER, logger
)

# === ENUMS AND DATA CLASSES ===

class ConnectionStatus(Enum):
    """Connection status enumeration"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"
    DEGRADED = "degraded"

class HealthStatus(Enum):
    """Health status enumeration"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"

@dataclass
class ConnectionMetrics:
    """Connection performance metrics"""
    total_connections: int = 0
    active_connections: int = 0
    failed_connections: int = 0
    avg_response_time: float = 0.0
    last_error: Optional[str] = None
    last_success: Optional[float] = None

@dataclass
class WorkerInfo:
    """Worker registration information"""
    worker_id: str
    hostname: str
    pid: int
    version: str
    started_at: float
    last_heartbeat: float
    jobs_processed: int = 0
    jobs_failed: int = 0
    status: str = "active"
    capabilities: List[str] = None

    def __post_init__(self):
        if self.capabilities is None:
            self.capabilities = ["esrgan", "image_processing", "variants"]

# === ENHANCED REDIS MANAGER ===

class EnhancedRedisManager:
    """
    Professional-grade Redis connection manager with:
    - Connection pooling
    - Health monitoring
    - Automatic failover
    - Metrics collection
    - Circuit breaker pattern
    """
    
    def __init__(self):
        self.pool: Optional[ConnectionPool] = None
        self.client: Optional[redis.Redis] = None
        self.status = ConnectionStatus.DISCONNECTED
        self.metrics = ConnectionMetrics()
        self.health_status = HealthStatus.UNKNOWN
        
        # Health monitoring
        self._last_health_check = 0
        self._health_check_lock = threading.Lock()
        self._circuit_breaker_until = 0
        
        # Performance tracking
        self._response_times = []
        self._max_response_history = 100
        
        logger.info("🔧 Enhanced Redis Manager initialized")
    
    def connect(self) -> bool:
        """Establish Redis connection with enhanced configuration"""
        try:
            self.status = ConnectionStatus.CONNECTING
            logger.info(f"🔗 Connecting to Redis at {RedisConfig.HOST}:{RedisConfig.PORT}")
            
            # Create connection pool with advanced settings
            self.pool = ConnectionPool(
                host=RedisConfig.HOST,
                port=RedisConfig.PORT,
                password=RedisConfig.PASSWORD,
                db=RedisConfig.DB,
                max_connections=RedisConfig.MAX_CONNECTIONS,
                socket_connect_timeout=RedisConfig.SOCKET_CONNECT_TIMEOUT,
                socket_timeout=RedisConfig.SOCKET_TIMEOUT,
                health_check_interval=RedisConfig.HEALTH_CHECK_INTERVAL,
                retry_on_timeout=True,
                retry_on_error=[ConnectionError, TimeoutError],
                encoding='utf-8',
                decode_responses=True
            )
            
            # Create Redis client with pool
            self.client = redis.Redis(
                connection_pool=self.pool,
                socket_keepalive=True,
                socket_keepalive_options={},
                health_check_interval=RedisConfig.HEALTH_CHECK_INTERVAL
            )
            
            # Test connection with timeout
            start_time = time.time()
            result = self.client.ping()
            response_time = (time.time() - start_time) * 1000
            
            if result:
                self.status = ConnectionStatus.CONNECTED
                self.health_status = HealthStatus.HEALTHY
                self.metrics.total_connections += 1
                self.metrics.last_success = time.time()
                self._update_response_time(response_time)
                
                # Get Redis info for diagnostics
                info = self.client.info()
                redis_version = info.get('redis_version', 'unknown')
                connected_clients = info.get('connected_clients', 0)
                
                logger.info(f"✅ Connected to Redis successfully")
                logger.info(f"   Redis version: {redis_version}")
                logger.info(f"   Connected clients: {connected_clients}")
                logger.info(f"   Response time: {response_time:.2f}ms")
                logger.info(f"   Pool max connections: {RedisConfig.MAX_CONNECTIONS}")
                
                return True
            else:
                raise RedisError("Ping returned False")
                
        except Exception as e:
            self.status = ConnectionStatus.ERROR
            self.health_status = HealthStatus.UNHEALTHY
            self.metrics.failed_connections += 1
            self.metrics.last_error = str(e)
            
            logger.error(f"❌ Redis connection failed: {e}")
            return False
    
    def disconnect(self):
        """Gracefully disconnect from Redis"""
        try:
            if self.client:
                logger.info("🔌 Disconnecting from Redis...")
                self.client.close()
                self.client = None
            
            if self.pool:
                self.pool.disconnect()
                self.pool = None
                
            self.status = ConnectionStatus.DISCONNECTED
            logger.info("✅ Redis disconnected successfully")
            
        except Exception as e:
            logger.error(f"❌ Error during Redis disconnect: {e}")
    
    def is_healthy(self) -> bool:
        """Check Redis health with caching and circuit breaker"""
        current_time = time.time()
        
        # Circuit breaker check
        if current_time < self._circuit_breaker_until:
            return False
        
        # Use cached result if recent
        with self._health_check_lock:
            if current_time - self._last_health_check < RedisConfig.HEALTH_CHECK_INTERVAL:
                return self.health_status in [HealthStatus.HEALTHY, HealthStatus.DEGRADED]
            
            self._last_health_check = current_time
        
        # Perform health check
        try:
            if not self.client:
                return False
            
            start_time = time.time()
            result = self.client.ping()
            response_time = (time.time() - start_time) * 1000
            
            if result:
                self._update_response_time(response_time)
                
                # Determine health based on response time
                if response_time < 100:  # < 100ms = healthy
                    self.health_status = HealthStatus.HEALTHY
                elif response_time < 500:  # 100-500ms = degraded
                    self.health_status = HealthStatus.DEGRADED
                else:  # > 500ms = unhealthy
                    self.health_status = HealthStatus.UNHEALTHY
                
                return True
            else:
                self.health_status = HealthStatus.UNHEALTHY
                return False
                
        except Exception as e:
            self.health_status = HealthStatus.UNHEALTHY
            self.metrics.last_error = str(e)
            logger.warning(f"⚠️ Redis health check failed: {e}")
            
            # Activate circuit breaker on repeated failures
            self._circuit_breaker_until = current_time + 30  # 30 second circuit breaker
            
            return False
    
    def execute_with_retry(self, operation: callable, *args, max_retries: int = 3, **kwargs):
        """Execute Redis operation with automatic retry and exponential backoff"""
        last_exception = None
        
        for attempt in range(max_retries + 1):
            try:
                if not self.is_healthy() and attempt == 0:
                    # Try to reconnect if unhealthy
                    logger.warning("🔄 Redis unhealthy, attempting reconnection...")
                    if not self.connect():
                        continue
                
                start_time = time.time()
                result = operation(*args, **kwargs)
                response_time = (time.time() - start_time) * 1000
                
                self._update_response_time(response_time)
                return result
                
            except (RedisConnectionError, RedisTimeoutError) as e:
                last_exception = e
                self.metrics.failed_connections += 1
                
                if attempt < max_retries:
                    delay = min(2 ** attempt, RedisConfig.RETRY_BACKOFF_MAX)
                    logger.warning(f"⚠️ Redis operation failed (attempt {attempt + 1}), retrying in {delay}s...")
                    time.sleep(delay)
                    
                    # Try to reconnect
                    self.connect()
                else:
                    logger.error(f"❌ Redis operation failed after {max_retries + 1} attempts")
                    raise
            
            except Exception as e:
                logger.error(f"❌ Unexpected Redis error: {e}")
                raise
        
        raise last_exception
    
    def _update_response_time(self, response_time: float):
        """Update response time metrics"""
        self._response_times.append(response_time)
        if len(self._response_times) > self._max_response_history:
            self._response_times.pop(0)
        
        self.metrics.avg_response_time = sum(self._response_times) / len(self._response_times)
    
    # === QUEUE OPERATIONS ===
    
    def push_job(self, queue: str, job_data: Dict[str, Any]) -> bool:
        """Push job to queue with enhanced error handling"""
        try:
            job_json = json.dumps(job_data, ensure_ascii=False)
            result = self.execute_with_retry(self.client.lpush, queue, job_json)
            logger.debug(f"📤 Pushed job to queue {queue}: {job_data.get('jobUuid', 'unknown')}")
            return bool(result)
        except Exception as e:
            logger.error(f"❌ Failed to push job to queue {queue}: {e}")
            return False
    
    def pop_job(self, queues: List[str], timeout: int = 5) -> Optional[tuple]:
        """Pop job from queues with timeout"""
        try:
            result = self.execute_with_retry(self.client.brpop, queues, timeout=timeout)
            if result:
                queue_name, job_json = result
                job_data = json.loads(job_json)
                logger.debug(f"📥 Popped job from queue {queue_name}: {job_data.get('jobUuid', 'unknown')}")
                return queue_name, job_data
            return None
        except Exception as e:
            logger.error(f"❌ Failed to pop job from queues {queues}: {e}")
            return None
    
    def push_event(self, queue: str, event_data: Dict[str, Any]) -> bool:
        """Push event to queue"""
        try:
            event_json = json.dumps(event_data, ensure_ascii=False)
            result = self.execute_with_retry(self.client.lpush, queue, event_json)
            logger.debug(f"📡 Pushed event to queue {queue}: {event_data.get('status', 'unknown')}")
            return bool(result)
        except Exception as e:
            logger.error(f"❌ Failed to push event to queue {queue}: {e}")
            return False
    
    def get_queue_length(self, queue: str) -> int:
        """Get queue length"""
        try:
            return self.execute_with_retry(self.client.llen, queue)
        except Exception as e:
            logger.error(f"❌ Failed to get queue length for {queue}: {e}")
            return 0
    
    # === LOCKING OPERATIONS ===
    
    def acquire_lock(self, lock_key: str, worker_id: str, ttl: int = 300) -> bool:
        """Acquire distributed lock"""
        try:
            result = self.execute_with_retry(
                self.client.set, lock_key, worker_id, 
                nx=True, ex=ttl
            )
            if result:
                logger.debug(f"🔒 Acquired lock: {lock_key}")
                return True
            else:
                logger.debug(f"🔒 Lock already held: {lock_key}")
                return False
        except Exception as e:
            logger.error(f"❌ Failed to acquire lock {lock_key}: {e}")
            return False
    
    def release_lock(self, lock_key: str, worker_id: str) -> bool:
        """Release distributed lock with ownership verification"""
        lua_script = """
        if redis.call("GET", KEYS[1]) == ARGV[1] then
            return redis.call("DEL", KEYS[1])
        else
            return 0
        end
        """
        try:
            result = self.execute_with_retry(
                self.client.eval, lua_script, 1, lock_key, worker_id
            )
            if result:
                logger.debug(f"🔓 Released lock: {lock_key}")
                return True
            else:
                logger.debug(f"🔓 Lock not owned by worker: {lock_key}")
                return False
        except Exception as e:
            logger.error(f"❌ Failed to release lock {lock_key}: {e}")
            return False
    
    # === KEY-VALUE OPERATIONS ===
    
    def set_with_ttl(self, key: str, value: Any, ttl: int) -> bool:
        """Set key with TTL"""
        try:
            if isinstance(value, (dict, list)):
                value = json.dumps(value)
            result = self.execute_with_retry(self.client.setex, key, ttl, value)
            return bool(result)
        except Exception as e:
            logger.error(f"❌ Failed to set key {key}: {e}")
            return False
    
    def get_value(self, key: str, as_json: bool = False) -> Optional[Any]:
        """Get key value with optional JSON parsing"""
        try:
            value = self.execute_with_retry(self.client.get, key)
            if value and as_json:
                return json.loads(value)
            return value
        except Exception as e:
            logger.error(f"❌ Failed to get key {key}: {e}")
            return None
    
    def exists(self, key: str) -> bool:
        """Check if key exists"""
        try:
            return bool(self.execute_with_retry(self.client.exists, key))
        except Exception as e:
            logger.error(f"❌ Failed to check existence of key {key}: {e}")
            return False
    
    def delete_key(self, key: str) -> bool:
        """Delete key"""
        try:
            result = self.execute_with_retry(self.client.delete, key)
            return bool(result)
        except Exception as e:
            logger.error(f"❌ Failed to delete key {key}: {e}")
            return False
    
    # === METRICS AND MONITORING ===
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get connection metrics"""
        pool_stats = {}
        if self.pool:
            pool_stats = {
                'max_connections': self.pool.max_connections,
                'created_connections': getattr(self.pool, '_created_connections', 0),
                'available_connections': len(getattr(self.pool, '_available_connections', [])),
                'in_use_connections': len(getattr(self.pool, '_in_use_connections', []))
            }
        
        return {
            'status': self.status.value,
            'health': self.health_status.value,
            'connection_metrics': asdict(self.metrics),
            'pool_stats': pool_stats,
            'response_times': self._response_times[-10:] if self._response_times else []
        }

# === ENHANCED S3 MANAGER ===

class EnhancedS3Manager:
    """
    Professional-grade S3/MinIO manager with:
    - Advanced connection configuration
    - Multipart upload support
    - Retry logic with exponential backoff
    - Performance optimization
    """
    
    def __init__(self):
        self.client: Optional[boto3.client] = None
        self.status = ConnectionStatus.DISCONNECTED
        self.metrics = ConnectionMetrics()
        
        logger.info("🔧 Enhanced S3 Manager initialized")
    
    def connect(self) -> bool:
        """Establish S3/MinIO connection with advanced configuration"""
        try:
            self.status = ConnectionStatus.CONNECTING
            logger.info(f"🔗 Connecting to S3/MinIO at {S3Config.ENDPOINT}")
            
            # Advanced boto3 configuration
            config = Config(
                region_name=S3Config.REGION,
                retries={
                    'max_attempts': S3Config.MAX_ATTEMPTS,
                    'mode': 'adaptive'
                },
                max_pool_connections=S3Config.MAX_POOL_CONNECTIONS,
                connect_timeout=30,
                read_timeout=60,
                # Multipart upload settings
                s3={
                    'multipart_threshold': S3Config.MULTIPART_THRESHOLD,
                    'multipart_chunksize': S3Config.MULTIPART_CHUNKSIZE,
                    'use_accelerate_endpoint': False,
                    'addressing_style': 'path'
                }
            )
            
            # Handle endpoint URL
            endpoint_url = S3Config.ENDPOINT
            if not endpoint_url.startswith(('http://', 'https://')):
                endpoint_url = f"{'https' if S3Config.USE_SSL else 'http'}://{endpoint_url}"
            
            # Create S3 client
            self.client = boto3.client(
                's3',
                endpoint_url=endpoint_url,
                aws_access_key_id=S3Config.ACCESS_KEY,
                aws_secret_access_key=S3Config.SECRET_KEY,
                config=config,
                use_ssl=S3Config.USE_SSL,
                verify=S3Config.VERIFY_SSL
            )
            
            # Test connection
            start_time = time.time()
            self.client.head_bucket(Bucket=S3Config.BUCKET)
            response_time = (time.time() - start_time) * 1000
            
            self.status = ConnectionStatus.CONNECTED
            self.metrics.total_connections += 1
            self.metrics.last_success = time.time()
            self.metrics.avg_response_time = response_time
            
            logger.info(f"✅ Connected to S3/MinIO successfully")
            logger.info(f"   Endpoint: {endpoint_url}")
            logger.info(f"   Bucket: {S3Config.BUCKET}")
            logger.info(f"   SSL: {S3Config.USE_SSL}")
            logger.info(f"   Response time: {response_time:.2f}ms")
            
            return True
            
        except Exception as e:
            self.status = ConnectionStatus.ERROR
            self.metrics.failed_connections += 1
            self.metrics.last_error = str(e)
            
            logger.error(f"❌ S3/MinIO connection failed: {e}")
            return False
    
    def download_file_with_retry(self, s3_key: str, local_path: str, max_retries: int = 3) -> bool:
        """Download file with retry logic and progress tracking"""
        for attempt in range(max_retries + 1):
            try:
                start_time = time.time()
                
                # Use download_file for better performance and automatic multipart handling
                self.client.download_file(
                    Bucket=S3Config.BUCKET,
                    Key=s3_key,
                    Filename=local_path
                )
                
                download_time = time.time() - start_time
                file_size = os.path.getsize(local_path) if os.path.exists(local_path) else 0
                
                if file_size > 0:
                    speed_mbps = (file_size / 1024 / 1024) / max(download_time, 0.1)
                    logger.info(f"📥 Downloaded {s3_key} ({file_size:,} bytes) in {download_time:.2f}s ({speed_mbps:.1f} MB/s)")
                    return True
                else:
                    raise Exception(f"Downloaded file is empty: {local_path}")
                
            except Exception as e:
                self.metrics.failed_connections += 1
                
                if attempt < max_retries:
                    delay = min(2 ** attempt, 30)  # Max 30 second delay
                    logger.warning(f"⚠️ Download failed (attempt {attempt + 1}), retrying in {delay}s: {e}")
                    time.sleep(delay)
                else:
                    logger.error(f"❌ Download failed after {max_retries + 1} attempts: {s3_key}")
                    return False
        
        return False
    
    def upload_file_with_retry(self, local_path: str, s3_key: str, max_retries: int = 3, 
                              content_type: str = 'image/webp', 
                              extra_metadata: Dict[str, str] = None) -> bool:
        """Upload file with retry logic, metadata, and progress tracking"""
        if not os.path.exists(local_path):
            logger.error(f"❌ Local file not found: {local_path}")
            return False
        
        file_size = os.path.getsize(local_path)
        if file_size == 0:
            logger.error(f"❌ Local file is empty: {local_path}")
            return False
        
        # Prepare extra args
        extra_args = {
            'ContentType': content_type,
            'CacheControl': 'max-age=31536000',  # 1 year cache
            'Tagging': 'public=yes&processed=yes',
        }
        
        # Add custom metadata
        if extra_metadata:
            extra_args['Metadata'] = extra_metadata
        
        for attempt in range(max_retries + 1):
            try:
                start_time = time.time()
                
                # Use upload_file for better performance and automatic multipart handling
                self.client.upload_file(
                    Filename=local_path,
                    Bucket=S3Config.BUCKET,
                    Key=s3_key,
                    ExtraArgs=extra_args
                )
                
                upload_time = time.time() - start_time
                speed_mbps = (file_size / 1024 / 1024) / max(upload_time, 0.1)
                
                logger.info(f"📤 Uploaded {s3_key} ({file_size:,} bytes) in {upload_time:.2f}s ({speed_mbps:.1f} MB/s)")
                return True
                
            except Exception as e:
                self.metrics.failed_connections += 1
                
                if attempt < max_retries:
                    delay = min(2 ** attempt, 30)  # Max 30 second delay
                    logger.warning(f"⚠️ Upload failed (attempt {attempt + 1}), retrying in {delay}s: {e}")
                    time.sleep(delay)
                else:
                    logger.error(f"❌ Upload failed after {max_retries + 1} attempts: {s3_key}")
                    return False
        
        return False
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get S3 connection metrics"""
        return {
            'status': self.status.value,
            'connection_metrics': asdict(self.metrics)
        }

# === ENHANCED WORKER REGISTRY ===

class EnhancedWorkerRegistry:
    """
    Professional worker registry with:
    - Comprehensive worker information
    - Health monitoring
    - Load balancing support
    - Scaling recommendations
    """
    
    def __init__(self, redis_manager: EnhancedRedisManager):
        self.redis = redis_manager
        self.worker_info = WorkerInfo(
            worker_id=WorkerConfig.WORKER_ID,
            hostname=socket.gethostname(),
            pid=os.getpid(),
            version=WorkerConfig.WORKER_VERSION,
            started_at=time.time(),
            last_heartbeat=time.time()
        )
        
        logger.info(f"🏷️ Worker registry initialized for {self.worker_info.worker_id}")
    
    def register(self, jobs_processed: int = 0, jobs_failed: int = 0) -> bool:
        """Register/update worker with comprehensive information"""
        try:
            self.worker_info.last_heartbeat = time.time()
            self.worker_info.jobs_processed = jobs_processed
            self.worker_info.jobs_failed = jobs_failed
            
            worker_data = asdict(self.worker_info)
            
            # Register in worker set and individual key
            pipeline = self.redis.client.pipeline()
            pipeline.sadd(QueueConfig.WORKER_REGISTRY, self.worker_info.worker_id)
            pipeline.setex(
                f"{QueueConfig.WORKER_REGISTRY}:{self.worker_info.worker_id}",
                WorkerConfig.REGISTRATION_TTL,
                json.dumps(worker_data)
            )
            pipeline.execute()
            
            logger.debug(f"📝 Worker registered: {jobs_processed} processed, {jobs_failed} failed")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to register worker: {e}")
            return False
    
    def unregister(self) -> bool:
        """Unregister worker"""
        try:
            pipeline = self.redis.client.pipeline()
            pipeline.srem(QueueConfig.WORKER_REGISTRY, self.worker_info.worker_id)
            pipeline.delete(f"{QueueConfig.WORKER_REGISTRY}:{self.worker_info.worker_id}")
            pipeline.execute()
            
            logger.info(f"📝 Worker {self.worker_info.worker_id} unregistered")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to unregister worker: {e}")
            return False
    
    def get_all_workers(self) -> List[WorkerInfo]:
        """Get information about all registered workers"""
        try:
            worker_ids = self.redis.execute_with_retry(
                self.redis.client.smembers, QueueConfig.WORKER_REGISTRY
            )
            
            workers = []
            for worker_id in worker_ids:
                worker_data = self.redis.get_value(
                    f"{QueueConfig.WORKER_REGISTRY}:{worker_id}", as_json=True
                )
                if worker_data:
                    workers.append(WorkerInfo(**worker_data))
            
            return workers
            
        except Exception as e:
            logger.error(f"❌ Failed to get worker list: {e}")
            return []
    
    def should_scale_up(self) -> bool:
        """Determine if more workers are needed based on queue depth and worker count"""
        try:
            # Get total queue depth
            total_jobs = sum(
                self.redis.get_queue_length(queue) 
                for queue in QueueConfig.JOBS + [QueueConfig.PRIORITY]
            )
            
            # Get active worker count
            active_workers = len(self.get_all_workers())
            
            # Simple scaling logic: if jobs per worker > 10, recommend scaling
            if active_workers == 0:
                return total_jobs > 0
            
            jobs_per_worker = total_jobs / active_workers
            should_scale = jobs_per_worker > 10
            
            if should_scale:
                logger.info(f"📈 Scaling recommended: {total_jobs} jobs / {active_workers} workers = {jobs_per_worker:.1f} jobs/worker")
            
            return should_scale
            
        except Exception as e:
            logger.error(f"❌ Failed to check scaling needs: {e}")
            return False

# === ENHANCED JOB MANAGER ===

class EnhancedJobManager:
    """
    Professional job management with:
    - Distributed locking
    - Job outcome tracking
    - Dead letter queue support
    - Performance metrics
    """
    
    def __init__(self, redis_manager: EnhancedRedisManager):
        self.redis = redis_manager
        self.worker_id = WorkerConfig.WORKER_ID
        
        logger.info("🔧 Enhanced Job Manager initialized")
    
    def claim_job(self, job_uuid: str) -> bool:
        """Claim job with distributed lock"""
        lock_key = f"job:lock:{job_uuid}"
        return self.redis.acquire_lock(lock_key, self.worker_id, WorkerConfig.JOB_LOCK_TTL)
    
    def release_job_lock(self, job_uuid: str) -> bool:
        """Release job lock"""
        lock_key = f"job:lock:{job_uuid}"
        return self.redis.release_lock(lock_key, self.worker_id)
    
    def set_job_outcome(self, job_uuid: str, outcome: Dict[str, Any]) -> bool:
        """Set job outcome with TTL"""
        outcome_key = f"job:outcome:{job_uuid}"
        return self.redis.set_with_ttl(outcome_key, outcome, WorkerConfig.OUTCOME_TTL)
    
    def get_job_outcome(self, job_uuid: str) -> Optional[Dict[str, Any]]:
        """Get job outcome"""
        outcome_key = f"job:outcome:{job_uuid}"
        return self.redis.get_value(outcome_key, as_json=True)
    
    def outcome_exists(self, job_uuid: str) -> bool:
        """Check if job outcome exists"""
        outcome_key = f"job:outcome:{job_uuid}"
        done_key = f"job:done:{job_uuid}"
        return self.redis.exists(outcome_key) or self.redis.exists(done_key)
    
    def move_to_dlq(self, job_data: Dict[str, Any], error: str) -> bool:
        """Move failed job to dead letter queue"""
        dlq_entry = {
            **job_data,
            'failed_at': time.time(),
            'error': error,
            'worker_id': self.worker_id
        }
        return self.redis.push_job(QueueConfig.DLQ, dlq_entry)