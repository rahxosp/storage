#!/usr/bin/env python3
"""
ESRGAN Processing module for ESRGAN Worker
Contains ESRGAN execution logic and variant processing
"""

import os
import subprocess
import logging
from typing import Optional, Dict
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils import temporary_file, generate_variant_s3_path, resize_image_with_degradation
from config import (
    ESRGAN_EXECUTABLE, ESRGAN_MODEL, SCALE_FACTOR, GPU_ID, TILE_SIZE,
    IMAGE_PROCESSING_TIMEOUT, MAX_IMAGE_SIZE, THREAD_POOL_SIZE,
    VARIANT_WIDTHS, WEBP_QUALITIES, LEGACY_VARIANT_MAPPING
)

logger = logging.getLogger(__name__)

class ESRGANProcessor:
    """Handles ESRGAN upscaling operations"""
    
    def __init__(self, s3_manager):
        self.s3_manager = s3_manager
    
    def run_esrgan_with_fallback(self, input_path: str, output_path: str, scale: int = SCALE_FACTOR) -> bool:
        """Run ESRGAN with fallback to different models and settings"""
        if not os.path.exists(input_path):
            logger.error(f"❌ Input file does not exist: {input_path}")
            return False
            
        file_size = os.path.getsize(input_path)
        if file_size > MAX_IMAGE_SIZE:
            logger.error(f"❌ Input file too large: {file_size} bytes")
            return False
        
        # Try with different configurations
        configurations = [
            {'model': ESRGAN_MODEL, 'tile': TILE_SIZE, 'gpu': GPU_ID},
            {'model': ESRGAN_MODEL, 'tile': 128, 'gpu': GPU_ID},  # Smaller tile for OOM
            {'model': ESRGAN_MODEL, 'tile': 256, 'gpu': -1},  # CPU fallback
        ]
        
        for config in configurations:
            try:
                cmd = [
                    ESRGAN_EXECUTABLE,
                    '-i', input_path,
                    '-o', output_path,
                    '-s', str(scale),
                    '-n', config['model'],
                    '-g', str(config['gpu']),
                    '-t', str(config['tile']),
                ]
                
                logger.info(f"🔄 Running ESRGAN: {' '.join(cmd)}")
                result = subprocess.run(
                    cmd,
                    timeout=IMAGE_PROCESSING_TIMEOUT,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                
                if result.returncode == 0:
                    if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                        logger.info(f"✅ ESRGAN processing completed with config: {config}")
                        return True
                    logger.error(f"❌ ESRGAN output missing or empty: {output_path}")
                else:
                    error_msg = result.stderr.lower()
                    if 'out of memory' in error_msg or 'cuda' in error_msg:
                        logger.warning(f"GPU issue detected, trying next configuration...")
                        continue
                    logger.error(f"❌ ESRGAN failed with code {result.returncode}")
                    
            except subprocess.TimeoutExpired:
                logger.error(f"❌ ESRGAN processing timeout after {IMAGE_PROCESSING_TIMEOUT}s")
            except Exception as e:
                logger.error(f"❌ Error running ESRGAN: {e}")
        
        return False

class VariantProcessor:
    """Handles creation of image variants (HD, SD, DS)"""
    
    def __init__(self, s3_manager):
        self.s3_manager = s3_manager
    
    def process_variant(self, upscaled_path: str, parsed: Dict[str, str], variant: str, 
                       mapped_variant: str, resource_state: str) -> Optional[str]:
        """Process a single image variant"""
        try:
            with temporary_file(suffix='.webp') as temp_variant:
                # We skip 'og' by default; only hd/sd/ds are processed
                if variant == 'og':
                    return None
                    
                width = VARIANT_WIDTHS.get(mapped_variant, 800)
                quality = WEBP_QUALITIES.get(mapped_variant, 80)
                
                if resize_image_with_degradation(upscaled_path, temp_variant, width, 
                                                quality, mapped_variant, resource_state):
                    s3_variant_path = generate_variant_s3_path(parsed, mapped_variant)
                    if not s3_variant_path:
                        return None
                    if self.s3_manager.upload_file_with_retry(temp_variant, s3_variant_path):
                        return s3_variant_path
            return None
        except Exception as e:
            logger.error(f"❌ Error processing variant {variant}: {e}")
            return None
    
    def process_variants_parallel(self, upscaled_path: str, parsed: Dict[str, str], 
                                 variants: list, resource_state: str) -> Dict[str, str]:
        """Process multiple variants in parallel"""
        variant_results = {}
        
        with ThreadPoolExecutor(max_workers=THREAD_POOL_SIZE) as executor:
            futures = {}
            for variant in variants:
                mapped = LEGACY_VARIANT_MAPPING.get(variant, variant)
                futures[executor.submit(
                    self.process_variant, upscaled_path, parsed, 
                    variant, mapped, resource_state
                )] = variant
                
            for future in as_completed(futures, timeout=IMAGE_PROCESSING_TIMEOUT):
                variant = futures[future]
                try:
                    result = future.result()
                    if result:
                        variant_results[variant] = result
                    # Don't fail if variant skipped due to resources
                    elif resource_state == 'NORMAL':
                        logger.error(f"❌ Failed to process variant {variant}")
                        return {}
                except Exception as e:
                    logger.error(f"❌ Error processing variant {variant}: {e}")
                    if resource_state == 'NORMAL':
                        return {}
        
        return variant_results
