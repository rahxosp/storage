# Vulkan Setup on Headless VPS (vast.ai)

## Problem
Vulkan was not detecting NVIDIA GPU on Ubuntu 24.04 headless server despite working NVIDIA drivers (565.77).

## Root Cause
The NVIDIA Vulkan ICD configuration was pointing to `libGLX_nvidia.so.0` (X11/display library) instead of `libEGL_nvidia.so.0` (headless/offscreen library).

## Solution
Install Vulkan runtime and update ICD configuration to use EGL library for headless operation.

---

## Installation Commands (In Order)

### 1. Update and Install Vulkan Packages
```bash
apt update
apt install -y vulkan-tools libvulkan1 mesa-vulkan-drivers vulkan-validationlayers
```

### 2. Install X11 Libraries (Required Dependencies)
```bash
apt install -y xvfb x11-utils libx11-6 libxext6 libxrandr2 libxrender1 libxxf86vm1 libxfixes3
```

### 3. Fix NVIDIA ICD Configuration (Critical Step)
```bash
echo 'ewogICAgImZpbGVfZm9ybWF0X3ZlcnNpb24iIDogIjEuMC4wIiwKICAgICJJQ0QiOiB7CiAgICAgICAgImxpYnJhcnlfcGF0aCI6ICJsaWJFR0xfbnZpZGlhLnNvLjAiLAogICAgICAgICJhcGlfdmVyc2lvbiIgOiAiMS4zLjI4OSIKICAgIH0KfQo=' | base64 -d > /etc/vulkan/icd.d/nvidia_icd.json
```

**What this does:** Creates proper ICD config pointing to EGL library instead of GLX.

The decoded JSON content:
```json
{
    "file_format_version" : "1.0.0",
    "ICD": {
        "library_path": "libEGL_nvidia.so.0",
        "api_version" : "1.3.289"
    }
}
```

### 4. Verify Vulkan Detects GPU
```bash
vulkaninfo --summary
```

**Expected output:**
```
GPU0:
    deviceName         = NVIDIA GeForce RTX 3060
    deviceType         = PHYSICAL_DEVICE_TYPE_DISCRETE_GPU
    driverName         = NVIDIA
```

---

## Key Difference: GLX vs EGL

| Library | Purpose | Use Case |
|---------|---------|----------|
| `libGLX_nvidia.so.0` | X11/Display rendering | Desktop with monitor |
| `libEGL_nvidia.so.0` | Headless/Offscreen rendering | SSH/CLI servers (✓ Correct) |

---

## Troubleshooting

### Check NVIDIA Driver
```bash
nvidia-smi
cat /proc/driver/nvidia/version
```

### Check Current ICD Config
```bash
cat /etc/vulkan/icd.d/nvidia_icd.json
```

### Debug Vulkan Loading
```bash
VK_LOADER_DEBUG=all vulkaninfo --summary 2>&1 | grep ERROR
```

---

## Result
✅ Vulkan now detects NVIDIA RTX 3060 on headless VPS  
✅ Ready for GPU-accelerated image processing (ESRGAN, etc.)  
✅ Works via SSH/CLI without display server
