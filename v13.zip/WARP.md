# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project Overview

This is an **ESRGAN GPU Worker v13** - a distributed image upscaling service for manga/webtoon processing. The worker connects to a Laravel backend via Redis queues and processes images using ESRGAN (Enhanced Super-Resolution Generative Adversarial Networks) to create HD/SD/DS variants.

## Architecture

### Core Components

- **Main Entry Points**: `main.py` (v13) and `improved_main.py` (production version)
- **Configuration**: `config.py` and `improved_config.py` contain all environment variables and settings
- **Storage Management**: Redis connection handling and S3/MinIO operations in `storage.py` and `simple_improved_storage.py`
- **Image Processing**: ESRGAN execution in `esrgan_processor.py`, image splitting/merging in `image_processor.py`
- **Worker Logic**: Main processing pipeline in `worker.py` and `improved_worker.py`
- **Monitoring**: Health checks, metrics, and circuit breaker patterns in `monitoring.py`

### Processing Pipeline

1. **Job Acquisition**: Worker claims jobs from Redis queues with distributed locking
2. **Download**: Original image downloaded from S3/MinIO storage
3. **Preprocessing**: Image validation and format conversion to PNG
4. **Image Splitting**: Very tall webtoon images (>12,000px) are split into 3,000px parts
5. **ESRGAN Processing**: GPU-based upscaling with CPU fallback
6. **Variant Generation**: Parallel creation of HD (1200px), SD (800px), DS (600px) variants
7. **Upload**: All variants uploaded to S3/MinIO as WebP format
8. **Completion**: Success/failure events sent to Laravel backend

### Key Technologies

- **Python 3.10+** with PIL, Redis, boto3, psutil
- **ESRGAN** executable for GPU-accelerated upscaling
- **Redis** for job queues and worker coordination
- **S3/MinIO** for image storage
- **WebP** format for optimized output variants
- **Prometheus** metrics for monitoring

## Development Commands

### Running the Worker

**Production (Recommended)**:
```bash
python3 improved_main.py
```

**Development**:
```bash
python main.py
```

### Testing Components

**Test S3 connection**:
```bash
python3 -c "from simple_improved_storage import EnhancedS3Manager; s = EnhancedS3Manager(); print('OK' if s.connect() else 'FAIL')"
```

**Test Redis connection**:
```bash
python3 -c "from simple_improved_storage import EnhancedRedisManager; r = EnhancedRedisManager(); print('OK' if r.connect() else 'FAIL')"
```

**Check imports**:
```bash
python3 -c "from simple_improved_storage import *; from improved_worker import *; print('All imports OK')"
```

**Compile all modules**:
```bash
python -m py_compile *.py
```

### Remote Deployment

**Deploy to GPU server** (from Windows PowerShell):
```powershell
.\deploy_fixes.ps1
```

**Monitor logs**:
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'tail -f /home/image-conversion/v13/worker.log'
```

**Check worker status**:
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'ps aux | grep improved_main.py'
```

## Configuration

### Environment Variables

All configuration is centralized in `config.py` with these key settings:

**Redis Configuration**:
- `REDIS_HOST`: Redis server hostname
- `REDIS_PORT`: Redis port (default: 6379)
- `REDIS_PASSWORD`: Authentication password
- `REDIS_PREFIX`: Laravel app prefix (`webtoon_hub_database_`)

**S3/MinIO Configuration**:
- `MINIO_ENDPOINT`: Storage endpoint URL
- `MINIO_ACCESS_KEY` / `MINIO_SECRET_KEY`: Authentication credentials
- `MINIO_BUCKET`: Target bucket name

**ESRGAN Settings**:
- `ESRGAN_EXECUTABLE`: Path to ESRGAN binary
- `ESRGAN_MODEL`: Default model (`Omni-Small`)
- `SCALE_FACTOR`: Upscaling factor (default: 2x)
- `GPU_ID`: GPU device ID for processing
- `TILE_SIZE`: Processing tile size for memory management

**Image Processing**:
- `SPLIT_THRESHOLD`: Height threshold for image splitting (12,000px)
- `SPLIT_HEIGHT`: Height of split parts (3,000px)
- `VARIANT_WIDTHS`: Target widths for HD/SD/DS variants
- `WEBP_QUALITIES`: Quality settings per variant

## File Structure

### Production Files
- `improved_main.py`: Production entry point
- `improved_config.py`: Production configuration
- `improved_worker.py`: Production worker implementation
- `simple_improved_storage.py`: Optimized storage module with clean logging

### Development/Modular Files
- `main.py`: Development entry point
- `config.py`: Development configuration
- `worker.py`: Modular worker implementation
- `storage.py`: Full-featured storage module

### Supporting Modules
- `esrgan_processor.py`: ESRGAN execution and variant processing
- `image_processor.py`: Image splitting, merging, and format handling
- `chapter_manager.py`: Chapter-aware part numbering coordination
- `monitoring.py`: Health monitoring, metrics, circuit breaker
- `utils.py`: Common utilities and helpers

### Deployment Scripts
- `deploy_fixes.ps1`: PowerShell deployment script for Windows
- `deploy_fixes.sh`: Bash deployment script

### Documentation
- `README.md`: Comprehensive project documentation
- `QUICK_REFERENCE.md`: Quick command reference for operations
- `FIXES_README.md`: Details of recent bug fixes and improvements
- `SUMMARY.md`: Summary of major fixes and changes

## Key Features

### Fault Tolerance
- **Circuit Breaker Pattern**: Handles repeated failures gracefully
- **Retry Logic**: Exponential backoff for transient failures
- **GPU/CPU Fallback**: Automatic fallback to CPU processing when GPU fails
- **Memory Management**: Resource monitoring and graceful degradation

### Performance Optimization
- **Parallel Processing**: Concurrent variant generation using ThreadPoolExecutor
- **Batch Processing**: Multiple jobs processed simultaneously
- **Image Splitting**: Handles very tall webtoon images by splitting into manageable parts
- **Memory Optimization**: Garbage collection and resource cleanup

### Monitoring & Observability
- **Prometheus Metrics**: Performance and health metrics on port 8001
- **Structured Logging**: Clean, emoji-enhanced logs for easy debugging
- **Worker Registration**: Distributed worker coordination via Redis
- **Health Checks**: System resource monitoring (CPU, memory, GPU)

## Common Issues & Solutions

### 403 Forbidden Errors
These are expected when MinIO user lacks `ListBucket` permission but has read/write access. The worker handles these gracefully by retrying without the initial HeadObject check.

### SSL/HTTPS Warnings
urllib3 warnings are suppressed in production builds. Set `MINIO_INSECURE=1` environment variable if needed for development.

### Memory Issues
Adjust `TILE_SIZE` and `BATCH_SIZE` based on GPU memory. The worker automatically falls back to smaller tiles and CPU processing when needed.

### Image Format Issues
The worker automatically converts images to PNG for ESRGAN compatibility and outputs WebP variants for optimal storage.

## Integration with Laravel Backend

The worker integrates with a Laravel application through:
- **Redis Queues**: Jobs received from `image:jobs` queue
- **Event Publishing**: Results sent to `image:events` queue
- **Worker Registry**: Registration and scaling coordination
- **Job Outcomes**: Success/failure tracking with TTL

The Laravel backend should use Spatie Media Library, MinIO S3 driver, and Redis for queues as specified in the user's development environment.

<citations>
<document>
<document_type>RULE</document_type>
<document_id>slgOx6C5GVRsUTr6ND6blz</document_id>
</document>
</citations>