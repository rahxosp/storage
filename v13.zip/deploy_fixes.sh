#!/bin/bash
# Deploy fixes to GPU server

echo "🚀 Deploying GPU Worker Fixes to Server..."
echo ""

SERVER_USER="root"
SERVER_HOST="171.247.185.4"
SERVER_PORT="42576"
SSH_KEY="C:/Users/AJU/.ssh/vast"
REMOTE_PATH="/home/image-conversion/v13"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}📁 Uploading files...${NC}"

# Upload the new simplified storage module
scp -i "$SSH_KEY" -P $SERVER_PORT \
    simple_improved_storage.py \
    ${SERVER_USER}@${SERVER_HOST}:${REMOTE_PATH}/

# Upload the modified worker
scp -i "$SSH_KEY" -P $SERVER_PORT \
    improved_worker.py \
    ${SERVER_USER}@${SERVER_HOST}:${REMOTE_PATH}/

# Upload README
scp -i "$SSH_KEY" -P $SERVER_PORT \
    FIXES_README.md \
    ${SERVER_USER}@${SERVER_HOST}:${REMOTE_PATH}/

echo ""
echo -e "${GREEN}✅ Files uploaded successfully!${NC}"
echo ""
echo -e "${YELLOW}🔄 Restarting worker service...${NC}"

# Restart the worker (adjust this based on how you manage the service)
ssh -i "$SSH_KEY" -p $SERVER_PORT ${SERVER_USER}@${SERVER_HOST} << 'ENDSSH'
cd /home/image-conversion/v13

# Kill existing worker if running
pkill -f "improved_main.py" || true
sleep 2

# Start the worker in background
nohup python3 improved_main.py > worker.log 2>&1 &

echo "Worker restarted with PID: $!"
ENDSSH

echo ""
echo -e "${GREEN}✅ Deployment complete!${NC}"
echo ""
echo "📊 To view logs:"
echo "   ssh -i \"$SSH_KEY\" -p $SERVER_PORT ${SERVER_USER}@${SERVER_HOST} 'tail -f /home/image-conversion/v13/worker.log'"
echo ""
echo "🔍 To check worker status:"
echo "   ssh -i \"$SSH_KEY\" -p $SERVER_PORT ${SERVER_USER}@${SERVER_HOST} 'ps aux | grep improved_main.py'"
