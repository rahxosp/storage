# Real-ESRGAN CUDA Setup - Complete Guide

## Installation Summary

### What Was Installed

✅ **PyTorch 2.5.1 with CUDA 12.1 support**  
✅ **Real-ESRGAN from GitHub** (https://github.com/xinntao/Real-ESRGAN)  
✅ **Pre-trained models:**
- RealESRGAN_x4plus (64MB) - General images
- RealESRGAN_x4plus_anime_6B (18MB) - Anime/illustration optimized

### Location
```
~/esrgan-cuda/Real-ESRGAN/
├── inputs/          # Input images
├── results/         # Upscaled outputs
├── weights/         # Pre-trained models
└── inference_realesrgan.py
```

### System Specs
- **GPU:** NVIDIA GeForce RTX 3060 (12GB)
- **Driver:** 565.77
- **CUDA:** 12.7 (driver) / 12.1 (PyTorch)
- **Python:** 3.12.3

---

## ⚡ Quick Usage

### SSH into Server
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 30714 root@112.82.115.178
cd ~/esrgan-cuda/Real-ESRGAN
```

### Basic Upscaling (4x)
```bash
# Upscale single image
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/your_image.jpg

# Upscale all images in folder
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/

# Custom output folder
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/ -o outputs/
```

### Anime/Illustration Images
```bash
python3 inference_realesrgan.py -n RealESRGAN_x4plus_anime_6B -i inputs/anime.jpg
```

### Advanced Options
```bash
# Custom scale (2x, 3x, etc.)
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i input.jpg --outscale 2

# With face enhancement (uses GFPGAN)
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i portrait.jpg --face_enhance

# Tile processing (for large images/low VRAM)
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i huge.jpg -t 256

# Full precision (slower but potentially better quality)
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i input.jpg --fp32
```

---

## 📊 Performance Test Results

**Test Image:** 179x179 pixels → 716x716 pixels (4x upscale)  
**Status:** ✅ Working perfectly with CUDA acceleration

---

## 🎯 Available Models

| Model | Size | Best For | Command Flag |
|-------|------|----------|--------------|
| RealESRGAN_x4plus | 64MB | General photos, realistic images | `-n RealESRGAN_x4plus` |
| RealESRGAN_x4plus_anime_6B | 18MB | Anime, illustrations, cartoons | `-n RealESRGAN_x4plus_anime_6B` |

---

## 🔧 All Command Options

```bash
python3 inference_realesrgan.py [options]

Options:
  -i, --input          Input image or folder (default: inputs)
  -o, --output         Output folder (default: results)
  -n, --model_name     Model name (default: RealESRGAN_x4plus)
  -s, --outscale       Final upscaling scale (default: 4)
  --suffix            Suffix for output files (default: out)
  -t, --tile          Tile size, 0 for no tile (default: 0)
  --face_enhance      Use GFPGAN for face enhancement
  --fp32              Use full precision (default: fp16/half)
  --ext               Output extension: auto|jpg|png (default: auto)
```

---

## 📁 File Transfer (Windows → Server)

### Upload Image to Server
```powershell
# From Windows PowerShell
scp -i "C:\Users\AJU\.ssh\vast" -P 30714 "C:\path\to\image.jpg" root@112.82.115.178:/root/esrgan-cuda/Real-ESRGAN/inputs/
```

### Download Result from Server
```powershell
# From Windows PowerShell
scp -i "C:\Users\AJU\.ssh\vast" -P 30714 root@112.82.115.178:/root/esrgan-cuda/Real-ESRGAN/results/image_out.jpg "C:\path\to\save\"
```

---

## 🐛 Troubleshooting

### Check CUDA is Working
```bash
cd ~/esrgan-cuda/Real-ESRGAN
python3 -c "import torch; print('CUDA:', torch.cuda.is_available()); print('GPU:', torch.cuda.get_device_name(0))"
```

**Expected output:**
```
CUDA: True
GPU: NVIDIA GeForce RTX 3060
```

### Out of Memory Error
Use tile processing:
```bash
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i large.jpg -t 400
```

### Import Error (torchvision)
Already fixed during installation. If it reoccurs:
```bash
python3 << 'EOF'
degradations_path = '/usr/local/lib/python3.12/dist-packages/basicsr/data/degradations.py'
with open(degradations_path, 'r') as f:
    content = f.read()
content = content.replace('from torchvision.transforms.functional_tensor import rgb_to_grayscale', 
                         'from torchvision.transforms.functional import rgb_to_grayscale')
with open(degradations_path, 'w') as f:
    f.write(content)
EOF
```

---

## 📦 Batch Processing Script

Create `batch_upscale.sh`:
```bash
#!/bin/bash
cd ~/esrgan-cuda/Real-ESRGAN

echo "🚀 Batch upscaling all images in inputs/"
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/ -o results/ --fp32

echo "✅ Done! Results in results/ folder"
ls -lh results/
```

Make it executable:
```bash
chmod +x batch_upscale.sh
./batch_upscale.sh
```

---

## 🎨 Example Workflows

### Workflow 1: Photo Enhancement
```bash
# 1. Upload photo
# 2. Upscale 4x with face enhancement
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/photo.jpg --face_enhance --fp32
```

### Workflow 2: Anime Art
```bash
# Use anime-optimized model
python3 inference_realesrgan.py -n RealESRGAN_x4plus_anime_6B -i inputs/anime.png
```

### Workflow 3: Custom 2x Upscale
```bash
# Sometimes 4x is too much, use 2x instead
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/image.jpg --outscale 2
```

---

## 🔗 Resources

- **GitHub:** https://github.com/xinntao/Real-ESRGAN
- **Paper:** https://arxiv.org/abs/2107.10833
- **More models:** Check `docs/model_zoo.md` in the repo

---

## ✅ Installation Verification

Run this to verify everything:
```bash
cd ~/esrgan-cuda/Real-ESRGAN
python3 -c "import torch; import cv2; print('✅ PyTorch:', torch.__version__); print('✅ CUDA:', torch.cuda.is_available()); print('✅ OpenCV:', cv2.__version__)"
ls weights/
```

**Expected output:**
```
✅ PyTorch: 2.5.1+cu121
✅ CUDA: True
✅ OpenCV: 4.12.0
RealESRGAN_x4plus.pth
RealESRGAN_x4plus_anime_6B.pth
```

---

## 🚀 Pro Tips

1. **Use `--fp32` for best quality** (slower but better)
2. **Use tile processing** (`-t 256`) for images larger than 2000px
3. **Anime model is smaller and faster** for illustrations
4. **Face enhance works well** for portraits and group photos
5. **Batch process** entire folders to save time

---

## Server Info
- **IP:** 112.82.115.178
- **Port:** 30714
- **Path:** ~/esrgan-cuda/Real-ESRGAN/
