# ✅ Real-ESRGAN CUDA Installation Complete!

## 🎉 What's Been Installed

### Software Stack
- ✅ PyTorch 2.5.1 with CUDA 12.1 support  
- ✅ Real-ESRGAN from GitHub (latest)  
- ✅ BasicSR, facexlib, GFPGAN  
- ✅ OpenCV 4.12 + NumPy + SciPy  

### Pre-trained Models
- ✅ **RealESRGAN_x4plus** (64MB) - General purpose  
- ✅ **RealESRGAN_x4plus_anime_6B** (18MB) - Anime/illustrations  

### Helper Scripts
- ✅ `upscale.sh` - Simple wrapper for quick upscaling  
- ✅ `test_cuda.py` - CUDA verification script  

---

## 📍 Server Details

```
IP:   112.82.115.178
Port: 30714
SSH:  ssh -i "C:\Users\AJU\.ssh\vast" -p 30714 root@112.82.115.178
Path: ~/esrgan-cuda/Real-ESRGAN/
```

### Hardware
- **GPU:** NVIDIA GeForce RTX 3060 (12GB VRAM)  
- **Driver:** 565.77  
- **CUDA:** 12.7 (driver) / 12.1 (PyTorch)  

---

## ⚡ Quick Start (3 Commands)

```bash
# 1. SSH into server
ssh -i "C:\Users\AJU\.ssh\vast" -p 30714 root@112.82.115.178

# 2. Navigate to Real-ESRGAN
cd ~/esrgan-cuda/Real-ESRGAN

# 3. Upscale an image
./upscale.sh inputs/0014.jpg
```

---

## 📋 Common Commands

### Method 1: Helper Script (Easiest)
```bash
cd ~/esrgan-cuda/Real-ESRGAN

# Basic usage (4x upscale)
./upscale.sh inputs/image.jpg

# Anime model
./upscale.sh inputs/anime.png RealESRGAN_x4plus_anime_6B

# Custom scale (2x)
./upscale.sh inputs/image.jpg RealESRGAN_x4plus 2
```

### Method 2: Direct Python Script
```bash
cd ~/esrgan-cuda/Real-ESRGAN

# Single image
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/image.jpg

# Entire folder
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/

# With options
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i inputs/ --outscale 2 --fp32
```

---

## 📤 File Transfer

### Upload to Server (Windows PowerShell)
```powershell
scp -i "C:\Users\AJU\.ssh\vast" -P 30714 "C:\path\to\image.jpg" root@112.82.115.178:/root/esrgan-cuda/Real-ESRGAN/inputs/
```

### Download from Server (Windows PowerShell)
```powershell
scp -i "C:\Users\AJU\.ssh\vast" -P 30714 root@112.82.115.178:/root/esrgan-cuda/Real-ESRGAN/results/image_out.jpg "C:\Downloads\"
```

---

## 🧪 Test Results

✅ **CUDA Status:** Working  
✅ **GPU Detection:** NVIDIA GeForce RTX 3060  
✅ **Test Upscale:** 179x179 → 716x716 (4x) - Success!  

---

## 🔧 Verification Commands

### Check CUDA
```bash
cd ~/esrgan-cuda/Real-ESRGAN
python3 test_cuda.py
```

**Expected:**
```
PyTorch: 2.5.1+cu121
CUDA Available: True
CUDA Version: 12.1
GPU: NVIDIA GeForce RTX 3060
```

### Check Models
```bash
ls -lh ~/esrgan-cuda/Real-ESRGAN/weights/
```

**Expected:**
```
RealESRGAN_x4plus.pth              (64M)
RealESRGAN_x4plus_anime_6B.pth     (18M)
```

---

## 🎯 Model Selection Guide

| Input Type | Recommended Model | Command |
|------------|------------------|---------|
| Photos, landscapes, realistic | RealESRGAN_x4plus | `-n RealESRGAN_x4plus` |
| Anime, manga, illustrations | RealESRGAN_x4plus_anime_6B | `-n RealESRGAN_x4plus_anime_6B` |
| Portraits (with faces) | RealESRGAN_x4plus + face_enhance | `--face_enhance` |

---

## 💡 Pro Tips

1. **Use `--fp32` for best quality** (half precision is default for speed)
2. **Tile processing** for large images: `-t 256` or `-t 400`
3. **Batch process folders** instead of individual files
4. **Anime model is 3.5x smaller** and faster for illustrations
5. **Results folder** is automatically created if it doesn't exist

---

## 🐛 Troubleshooting

### "CUDA out of memory"
```bash
# Use tile processing
python3 inference_realesrgan.py -n RealESRGAN_x4plus -i image.jpg -t 256
```

### "Module not found" errors
```bash
# Reinstall dependencies
cd ~/esrgan-cuda/Real-ESRGAN
pip3 install --upgrade basicsr facexlib gfpgan realesrgan
```

### Check GPU is being used
```bash
# Run nvidia-smi in another terminal while processing
watch -n 1 nvidia-smi
```

---

## 📦 Directory Structure

```
~/esrgan-cuda/Real-ESRGAN/
│
├── inputs/              # Place images here
│   ├── 0014.jpg
│   ├── OST_009.png
│   └── (your images)
│
├── results/             # Upscaled outputs appear here
│   └── 0014_out.jpg
│
├── weights/             # Pre-trained models
│   ├── RealESRGAN_x4plus.pth
│   └── RealESRGAN_x4plus_anime_6B.pth
│
├── inference_realesrgan.py    # Main script
├── upscale.sh                  # Helper script
└── test_cuda.py               # CUDA test
```

---

## 🔗 Documentation

- **Full Guide:** `ESRGAN-CUDA-SETUP.md`
- **GitHub:** https://github.com/xinntao/Real-ESRGAN
- **Paper:** https://arxiv.org/abs/2107.10833

---

## ✅ Installation Steps Performed

1. ✅ Created directory: `~/esrgan-cuda/`
2. ✅ Cloned Real-ESRGAN from GitHub
3. ✅ Installed PyTorch 2.5.1 with CUDA 12.1
4. ✅ Installed dependencies (basicsr, facexlib, gfpgan)
5. ✅ Fixed torchvision import compatibility issue
6. ✅ Downloaded pre-trained models (82MB total)
7. ✅ Created helper scripts (upscale.sh, test_cuda.py)
8. ✅ Tested CUDA acceleration - Working!
9. ✅ Verified 4x upscaling - Success!

---

## 🚀 Ready to Use!

Your Real-ESRGAN CUDA setup is complete and tested. You can now:
- Upscale images up to 4x resolution
- Process photos and anime/illustrations
- Use GPU acceleration for fast processing
- Batch process entire folders

**Next Steps:**
1. Upload your images to `inputs/` folder
2. Run `./upscale.sh inputs/your_image.jpg`
3. Check `results/` folder for upscaled images

Enjoy your GPU-accelerated image upscaling! 🎨
