# ESRGAN Ultra-Aggressive Worker Installation Guide

## Prerequisites

### System Requirements

**Minimum:**
- Python 3.10 or higher
- 8GB RAM
- 50GB free disk space
- Network access to Redis and S3/MinIO

**Recommended for GPU Processing:**
- NVIDIA GPU with 6GB+ VRAM (RTX 3060 or better)
- CUDA 11.8 or higher
- 16GB+ RAM
- SSD storage

**Supported Platforms:**
- Linux (Ubuntu 20.04+, Debian 11+)
- Windows 10/11
- Docker (with NVIDIA Container Toolkit)

---

## Installation Steps

### 1. Python Environment Setup

#### Create Virtual Environment (Recommended)

**Linux/macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**Windows:**
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 2. Install Python Dependencies

```bash
# Install core dependencies
pip install -r requirements.txt

# Verify installation
pip list | grep -E "redis|boto3|Pillow|psutil"
```

Expected output:
```
boto3        1.34.x
botocore     1.34.x
Pillow       10.x.x
psutil       5.9.x
redis        4.6.x
```

### 3. Install ESRGAN CLI Tool

The worker requires the Real-ESRGAN command-line tool.

#### Option A: Using pip (Easiest)

```bash
pip install realesrgan
```

#### Option B: From Source (Advanced)

```bash
git clone https://github.com/xinntao/Real-ESRGAN.git
cd Real-ESRGAN
pip install -e .
```

#### Verify Installation

```bash
esrgan --version
# or
realesrgan-ncnn-vulkan --version
```

### 4. GPU Setup (NVIDIA GPUs Only)

#### Install CUDA Toolkit

**Ubuntu/Debian:**
```bash
# CUDA 11.8
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-ubuntu2204.pin
sudo mv cuda-ubuntu2204.pin /etc/apt/preferences.d/cuda-repository-pin-600
wget https://developer.download.nvidia.com/compute/cuda/11.8.0/local_installers/cuda-repo-ubuntu2204-11-8-local_11.8.0-520.61.05-1_amd64.deb
sudo dpkg -i cuda-repo-ubuntu2204-11-8-local_11.8.0-520.61.05-1_amd64.deb
sudo cp /var/cuda-repo-ubuntu2204-11-8-local/cuda-*-keyring.gpg /usr/share/keyrings/
sudo apt-get update
sudo apt-get -y install cuda
```

**Windows:**
Download and install from: https://developer.nvidia.com/cuda-downloads

#### Verify GPU Setup

```bash
nvidia-smi
```

Expected output should show your GPU(s).

---

## Configuration

### 1. Create Environment File

Create `.env` file in the project directory:

```bash
# Redis Configuration
REDIS_HOST=your-redis-host.com
REDIS_PORT=6379
REDIS_PASSWORD=your-redis-password
REDIS_DB=0

# S3/MinIO Configuration
S3_ENDPOINT=https://your-minio-endpoint.com
S3_ACCESS_KEY=your-access-key
S3_SECRET_KEY=your-secret-key
S3_BUCKET=your-bucket-name
S3_REGION=us-east-1

# Worker Configuration
WORKER_ID=worker-$(hostname)
GPU_ID=0
ESRGAN_MODEL=Omni-Small
TILE_SIZE=256
```

### 2. Configure Worker Settings

Edit `improved_config.py` if needed to adjust:
- Thread pool sizes
- Queue names
- Timeout values
- Monitoring intervals

### 3. Test Configuration

```bash
python -c "from improved_config import *; print('Config loaded successfully')"
```

---

## Running the Worker

### Development Mode

```bash
python ultra_aggressive_worker.py
```

### Production Mode (systemd on Linux)

Create `/etc/systemd/system/esrgan-worker.service`:

```ini
[Unit]
Description=ESRGAN Ultra-Aggressive Worker
After=network.target

[Service]
Type=simple
User=esrgan
WorkingDirectory=/home/esrgan/v13
Environment="PATH=/home/esrgan/v13/venv/bin"
ExecStart=/home/esrgan/v13/venv/bin/python ultra_aggressive_worker.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable esrgan-worker
sudo systemctl start esrgan-worker

# Check status
sudo systemctl status esrgan-worker

# View logs
sudo journalctl -u esrgan-worker -f
```

### Production Mode (Windows Service)

Use NSSM (Non-Sucking Service Manager):

```powershell
# Download NSSM from https://nssm.cc/download
nssm install ESRGANWorker "D:\path\to\venv\Scripts\python.exe" "D:\path\to\ultra_aggressive_worker.py"
nssm set ESRGANWorker AppDirectory "D:\path\to\v13"
nssm start ESRGANWorker
```

---

## Docker Deployment (Recommended for Production)

### Dockerfile

```dockerfile
FROM nvidia/cuda:11.8.0-runtime-ubuntu22.04

# Install system dependencies
RUN apt-get update && apt-get install -y \
    python3.10 \
    python3-pip \
    libjpeg-dev \
    libpng-dev \
    libwebp-dev \
    && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy requirements and install
COPY requirements.txt .
RUN pip3 install --no-cache-dir -r requirements.txt

# Install ESRGAN
RUN pip3 install --no-cache-dir realesrgan

# Copy application code
COPY . .

# Run worker
CMD ["python3", "ultra_aggressive_worker.py"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  esrgan-worker:
    build: .
    runtime: nvidia
    environment:
      - NVIDIA_VISIBLE_DEVICES=all
      - REDIS_HOST=redis-host
      - REDIS_PORT=6379
      - S3_ENDPOINT=https://minio-endpoint
      - S3_ACCESS_KEY=${S3_ACCESS_KEY}
      - S3_SECRET_KEY=${S3_SECRET_KEY}
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    restart: unless-stopped
```

Build and run:
```bash
docker-compose up -d
docker-compose logs -f esrgan-worker
```

---

## Verification

### 1. Check Worker Status

Look for startup messages:
```
🔥 Starting ULTRA-AGGRESSIVE Worker v11.0.0
✅ Connected to Redis successfully
✅ Connected to S3/MinIO successfully
🏃 Ultra-aggressive pipeline ready
```

### 2. Monitor GPU Usage

```bash
watch -n 1 nvidia-smi
```

Look for GPU utilization 80-90% when processing jobs.

### 3. Check Redis Queue

```bash
redis-cli -h your-redis-host -a your-password LLEN webtoon_hub_database_image:jobs
```

### 4. Monitor Logs

Watch for these key metrics every 30 seconds:
```
💰 GPU Utilization: 85.9% (billing efficiency!)
📊 Throughput: 208 jobs/hour
💵 Good! 80%+ utilization
```

---

## Troubleshooting

### Redis Connection Issues

**Error:** `❌ Redis connection failed`

**Solutions:**
1. Verify Redis host/port: `telnet your-redis-host 6379`
2. Check password: `redis-cli -h host -a password ping`
3. Verify network: `ping your-redis-host`
4. Check firewall rules

### S3/MinIO Connection Issues

**Error:** `❌ S3 connection failed` or `403 Forbidden`

**Solutions:**
1. Test credentials:
   ```bash
   aws s3 ls s3://your-bucket --endpoint-url=https://your-endpoint
   ```
2. Verify bucket permissions
3. Check SSL certificate if using HTTPS
4. Review access key permissions in MinIO console

### GPU Not Detected

**Error:** `CUDA not available` or `GPU processing failed`

**Solutions:**
1. Check NVIDIA driver: `nvidia-smi`
2. Verify CUDA installation: `nvcc --version`
3. Test PyTorch GPU: `python -c "import torch; print(torch.cuda.is_available())"`
4. Check GPU_ID in config matches available GPU

### Out of Memory (OOM)

**Error:** `CUDA out of memory` or `RuntimeError: out of memory`

**Solutions:**
1. Reduce TILE_SIZE in config (256 → 128)
2. Reduce concurrent workers
3. Enable CPU fallback
4. Upgrade GPU memory

### Jobs Not Processing

**Error:** Jobs stuck in Redis queue

**Solutions:**
1. Check worker is running: `ps aux | grep ultra_aggressive`
2. Verify no errors in logs
3. Check Redis queue length
4. Look for "DUPLICATE" messages (idempotency working)
5. Verify S3 paths are valid

---

## Performance Tuning

### For Slow Networks
```python
# In improved_config.py
S3Config.MAX_POOL_CONNECTIONS = 100  # Increase
download_pool.max_workers = 8        # More concurrent downloads
```

### For Limited GPU Memory
```python
TILE_SIZE = 128              # Smaller tiles
gpu_queue.maxsize = 1        # Process one at a time
```

### For Maximum Throughput
```python
download_pool.max_workers = 10
upload_pool.max_workers = 12
gpu_queue.maxsize = 5
```

---

## Monitoring

### Key Metrics to Watch

1. **GPU Utilization:** Should be 80-90%
2. **Throughput:** 140-200 jobs/hour (depending on image size)
3. **Queue Depth:** Should stay 2-5 jobs
4. **Duplicates:** Should see "DUPLICATE: ignoring" messages if Laravel retries

### Recommended Monitoring Stack

- **Prometheus + Grafana** for metrics visualization
- **ELK Stack** for log aggregation
- **nvidia-smi** for real-time GPU monitoring

---

## Maintenance

### Regular Tasks

- **Daily:** Check logs for errors
- **Weekly:** Review throughput metrics
- **Monthly:** Update dependencies
- **Quarterly:** Test failover scenarios

### Backup Strategy

Critical files to backup:
- `.env` configuration
- `improved_config.py` customizations
- Systemd service files
- Docker compose configurations

---

## Support

For issues and questions:
1. Check `DUPLICATION-FIX.md` for known issues
2. Review `ULTRA-OPTIMIZATIONS.md` for performance tips
3. Check system logs: `journalctl -u esrgan-worker`
4. Monitor Redis/S3 connectivity

---

## Version Information

- Worker Version: v11.0.0
- Python: 3.10+
- CUDA: 11.8+
- Redis: 4.5.0+
- Last Updated: 2025-10-21
