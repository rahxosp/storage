# Vulkan Quick Setup - vast.ai

## One-Command Setup

### Method 1: Direct Download & Run (Easiest)
```bash
curl -O https://your-domain.com/setup-vulkan.sh && bash setup-vulkan.sh
```

### Method 2: Copy Script to Server
```bash
# From your local machine (Windows PowerShell)
scp -i "C:\Users\AJU\.ssh\vast" -P PORT setup-vulkan.sh root@IP:/root/

# SSH into server
ssh -i "C:\Users\AJU\.ssh\vast" -p PORT root@IP

# Run the script
bash setup-vulkan.sh
```

### Method 3: Direct Paste (No File Transfer)
```bash
# SSH into your new instance
ssh -i "C:\Users\AJU\.ssh\vast" -p PORT root@IP

# Paste this entire command block:
cat > setup-vulkan.sh << 'SCRIPT_END'
#!/bin/bash
set -e
echo "=========================================="
echo "  Vulkan Setup for Headless NVIDIA VPS"
echo "=========================================="
echo ""

if [ "$EUID" -ne 0 ]; then 
    echo "❌ Please run as root"
    exit 1
fi

echo "🔍 Checking NVIDIA driver..."
if ! command -v nvidia-smi &> /dev/null; then
    echo "❌ nvidia-smi not found"
    exit 1
fi

DRIVER_VERSION=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1)
echo "✅ NVIDIA Driver: $DRIVER_VERSION"
echo ""

echo "📦 Installing Vulkan packages..."
apt update -qq
apt install -y vulkan-tools libvulkan1 mesa-vulkan-drivers vulkan-validationlayers > /dev/null 2>&1
echo "✅ Vulkan packages installed"
echo ""

echo "📦 Installing X11 libraries..."
apt install -y xvfb x11-utils libx11-6 libxext6 libxrandr2 libxrender1 libxxf86vm1 libxfixes3 > /dev/null 2>&1
echo "✅ X11 libraries installed"
echo ""

echo "🔧 Configuring NVIDIA Vulkan ICD..."
cat > /etc/vulkan/icd.d/nvidia_icd.json << 'EOF'
{
    "file_format_version" : "1.0.0",
    "ICD": {
        "library_path": "libEGL_nvidia.so.0",
        "api_version" : "1.3.289"
    }
}
EOF
echo "✅ NVIDIA ICD configured for headless operation"
echo ""

echo "🧪 Verifying Vulkan installation..."
ldconfig

if VULKAN_OUTPUT=$(vulkaninfo --summary 2>&1); then
    if echo "$VULKAN_OUTPUT" | grep -q "NVIDIA GeForce"; then
        GPU_NAME=$(echo "$VULKAN_OUTPUT" | grep "deviceName" | head -1 | awk '{print $3, $4, $5, $6}')
        DRIVER_INFO=$(echo "$VULKAN_OUTPUT" | grep "driverInfo" | head -1 | awk '{print $3}')
        echo ""
        echo "=========================================="
        echo "  ✅ SUCCESS! Vulkan is configured!"
        echo "=========================================="
        echo "GPU: $GPU_NAME"
        echo "Driver: $DRIVER_INFO"
        echo "=========================================="
        exit 0
    else
        echo "⚠️  NVIDIA GPU not detected"
        exit 1
    fi
else
    echo "❌ Vulkan installation failed"
    exit 1
fi
SCRIPT_END

# Now run it
bash setup-vulkan.sh
```

---

## What the Script Does

1. ✅ Checks NVIDIA driver is present
2. 📦 Installs Vulkan runtime & tools
3. 📦 Installs required X11 dependencies
4. 🔧 Fixes ICD config (GLX → EGL for headless)
5. 🧪 Verifies GPU detection
6. ✅ Shows success message with GPU info

---

## Expected Output

```
==========================================
  Vulkan Setup for Headless NVIDIA VPS
==========================================

🔍 Checking NVIDIA driver...
✅ NVIDIA Driver: 565.77

📦 Installing Vulkan packages...
✅ Vulkan packages installed

📦 Installing X11 libraries...
✅ X11 libraries installed

🔧 Configuring NVIDIA Vulkan ICD...
✅ NVIDIA ICD configured for headless operation

🧪 Verifying Vulkan installation...

==========================================
  ✅ SUCCESS! Vulkan is configured!
==========================================
GPU Detected: NVIDIA GeForce RTX 3060
Driver: 565.77

You can now use Vulkan for GPU-accelerated
image processing (ESRGAN, etc.) via SSH/CLI
==========================================
```

---

## Troubleshooting

### Script fails at NVIDIA check
```bash
# Check if driver is loaded
nvidia-smi
```

### Script succeeds but app doesn't use GPU
```bash
# Verify Vulkan sees GPU
vulkaninfo --summary | grep "deviceName"

# Should show: NVIDIA GeForce RTX 3060
```

### Manual verification
```bash
# Check ICD config
cat /etc/vulkan/icd.d/nvidia_icd.json

# Should use "libEGL_nvidia.so.0" not "libGLX_nvidia.so.0"
```

---

## Time to Complete
**~2-3 minutes** (depending on connection speed)
