#!/usr/bin/env python3
"""
Configuration module for ESRGAN Worker
Contains all environment variables, constants, and settings
"""

import os
import logging

# Python 3.10+ compatibility fix for collections.Callable\ntry:\n    from collections.abc import Callable\n    import collections\n    collections.Callable = Callable\nexcept ImportError:\n    pass\n
import sys

# Setup logging with OS-specific log path
import tempfile
log_dir = os.path.join(tempfile.gettempdir(), 'cugan-worker')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'cugan_worker.log')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler(sys.stdout)
    ]
)

# Redis Configuration
REDIS_HOST = os.getenv('REDIS_HOST', '152.53.142.224')
REDIS_PORT = int(os.getenv('REDIS_PORT', '6379'))
REDIS_PASSWORD = os.getenv('REDIS_PASSWORD', 'BwswSeXhpFwcxSaQYwcq7DLj1qmvmz9PDT1D5Rr62CTTSWf1jIiaP17')

# Laravel uses a Redis prefix based on APP_NAME
REDIS_PREFIX = 'webtoon_hub_database_'

# Job queues: support both with and without prefix for compatibility
JOB_QUEUES = ['image:jobs', REDIS_PREFIX + 'image:jobs']
EVENT_QUEUES = ['image:events', REDIS_PREFIX + 'image:events']

# Priority queue for urgent jobs
PRIORITY_QUEUE = REDIS_PREFIX + 'image:priority'

# MinIO/S3 Configuration
# Using IP endpoint for better reliability (100% success rate vs 90% with domain)
# Test results: IP has no 403 errors, more stable connection
MINIO_ENDPOINT = os.getenv('MINIO_ENDPOINT', 'http://152.53.140.165:9000')
MINIO_ACCESS_KEY = os.getenv('MINIO_ACCESS_KEY', 'readershub-aju')
MINIO_SECRET_KEY = os.getenv('MINIO_SECRET_KEY', '4Hlkz5o4KDtmblMW2GyO7KkYIkNnzFGneOqsBvMoxM')
MINIO_BUCKET = os.getenv('MINIO_BUCKET', 'rhub')

# ESRGAN Settings
ESRGAN_EXECUTABLE = os.getenv('ESRGAN_EXECUTABLE', 'esrgan')
ESRGAN_MODEL = os.getenv('ESRGAN_MODEL', 'Omni-Small')  # Default ESRGAN model
SCALE_FACTOR = int(os.getenv('UPSCALE_SCALE_FACTOR', '2'))  # 2x upscaling
GPU_ID = int(os.getenv('ESRGAN_GPU_ID', '0'))
TILE_SIZE = int(os.getenv('ESRGAN_TILE_SIZE', '256'))

# Fallback models for error recovery
ESRGAN_FALLBACK_MODELS = [
    'Omni-Small',
    'RealESRGAN_x4',
    'ESRGAN_SRx4'
]

# Quality Settings
WEBP_QUALITIES = {
    'original': 100,  # If ever used
    'hd': 95,
    'sd': 90,
    'ds': 50,  # higher compression for DS
}

# Variant widths
VARIANT_WIDTHS = {
    'hd': 1200,
    'sd': 800,
    'ds': 600,
}

# WebP encoder maximum dimension (width or height)
WEBP_MAX_DIM = 16383

# Image splitting settings - CRITICAL FOR WEBTOONS
SPLIT_THRESHOLD = 12000  # Split images taller than 12000px
SPLIT_HEIGHT = 3000     # Split images into 3000px tall parts
MIN_IMAGE_DIM = 50  # Minimum width/height
MAX_IMAGE_WIDTH = 2000  # Maximum width (reasonable for processing)
MAX_IMAGE_SIZE = 50 * 1024 * 1024  # 50MB
SUPPORTED_FORMATS = {'JPEG', 'PNG', 'WEBP', 'BMP', 'GIF', 'TIFF'}

# Legacy mapping for backward compatibility
LEGACY_VARIANT_MAPPING = {
    'xl': 'hd',
    'lg': 'sd',
    'md': 'ds',
}

# Circuit Breaker Settings
MAX_CONSECUTIVE_FAILURES = 5
CIRCUIT_BREAKER_TIMEOUT = 300  # 5 minutes
EXPONENTIAL_BACKOFF_BASE = 2
MAX_BACKOFF_DELAY = 300  # 5 minutes

# Health monitoring
MEMORY_THRESHOLD = 85  # Percentage
CPU_THRESHOLD = 90     # Percentage
HEALTH_CHECK_INTERVAL = 60  # seconds

# Performance settings
THREAD_POOL_SIZE = 2
IMAGE_PROCESSING_TIMEOUT = 300  # 5 minutes per image
BATCH_SIZE = 3  # Process up to 3 jobs in parallel
MAX_RETRIES = 3
RETRY_DELAY = 5

# Dedupe/outcome TTL (seconds)
OUTCOME_TTL = 86400
JOB_LOCK_TTL = 300  # 5 minutes
CHAPTER_COUNTER_TTL = 86400 * 7  # 7 days for chapter counters

# Worker registration
WORKER_TTL = 60  # Worker registration expires after 60s
SCALE_CHECK_INTERVAL = 30  # Check for scaling every 30s

# Metrics port
METRICS_PORT = int(os.getenv('METRICS_PORT', '8001'))
