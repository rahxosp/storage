#!/usr/bin/env python3
"""
Simplified Storage module - Clean logs, handles 403 errors gracefully
"""

import os
import time
import json
import logging
import threading
import socket
import warnings
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, asdict
from enum import Enum

# Suppress all SSL/HTTP warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings('ignore')

import redis
from redis.connection import ConnectionPool
from redis.exceptions import RedisError, ConnectionError as RedisConnectionError, TimeoutError as RedisTimeoutError

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError, NoCredentialsError, EndpointConnectionError

# Silence noisy loggers
logging.getLogger('urllib3').setLevel(logging.ERROR)
logging.getLogger('botocore').setLevel(logging.ERROR)
logging.getLogger('boto3').setLevel(logging.ERROR)
logging.getLogger('s3transfer').setLevel(logging.ERROR)

from improved_config import (
    RedisConfig, S3Config, QueueConfig, WorkerConfig, 
    MonitoringConfig, GRACEFUL_KILLER, logger
)

# === ENUMS AND DATA CLASSES ===

class ConnectionStatus(Enum):
    """Connection status enumeration"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"
    DEGRADED = "degraded"

class HealthStatus(Enum):
    """Health status enumeration"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"

@dataclass
class ConnectionMetrics:
    """Connection performance metrics"""
    total_connections: int = 0
    active_connections: int = 0
    failed_connections: int = 0
    avg_response_time: float = 0.0
    last_error: Optional[str] = None
    last_success: Optional[float] = None

@dataclass
class WorkerInfo:
    """Worker registration information"""
    worker_id: str
    hostname: str
    pid: int
    version: str
    started_at: float
    last_heartbeat: float
    jobs_processed: int = 0
    jobs_failed: int = 0
    status: str = "active"
    capabilities: List[str] = None

    def __post_init__(self):
        if self.capabilities is None:
            self.capabilities = ["esrgan", "image_processing", "variants"]

# === ENHANCED REDIS MANAGER ===

class EnhancedRedisManager:
    """Redis connection manager with simplified logging"""
    
    def __init__(self):
        self.pool: Optional[ConnectionPool] = None
        self.client: Optional[redis.Redis] = None
        self.status = ConnectionStatus.DISCONNECTED
        self.metrics = ConnectionMetrics()
        self.health_status = HealthStatus.UNKNOWN
        
        self._last_health_check = 0
        self._health_check_lock = threading.Lock()
        self._circuit_breaker_until = 0
        
        self._response_times = []
        self._max_response_history = 100
        
        logger.info("🔧 Redis Manager initialized")
    
    def connect(self) -> bool:
        """Establish Redis connection"""
        try:
            self.status = ConnectionStatus.CONNECTING
            logger.info(f"🔗 Connecting to Redis at {RedisConfig.HOST}:{RedisConfig.PORT}")
            
            self.pool = ConnectionPool(
                host=RedisConfig.HOST,
                port=RedisConfig.PORT,
                password=RedisConfig.PASSWORD,
                db=RedisConfig.DB,
                max_connections=RedisConfig.MAX_CONNECTIONS,
                socket_connect_timeout=RedisConfig.SOCKET_CONNECT_TIMEOUT,
                socket_timeout=RedisConfig.SOCKET_TIMEOUT,
                health_check_interval=RedisConfig.HEALTH_CHECK_INTERVAL,
                retry_on_timeout=True,
                retry_on_error=[ConnectionError, TimeoutError],
                encoding='utf-8',
                decode_responses=True
            )
            
            self.client = redis.Redis(
                connection_pool=self.pool,
                socket_keepalive=True,
                socket_keepalive_options={},
                health_check_interval=RedisConfig.HEALTH_CHECK_INTERVAL
            )
            
            start_time = time.time()
            result = self.client.ping()
            response_time = (time.time() - start_time) * 1000
            
            if result:
                self.status = ConnectionStatus.CONNECTED
                self.health_status = HealthStatus.HEALTHY if response_time < 500 else HealthStatus.DEGRADED
                self.metrics.total_connections += 1
                self.metrics.last_success = time.time()
                self._update_response_time(response_time)
                
                info = self.client.info()
                logger.info(f"✅ Connected to Redis (v{info.get('redis_version', 'unknown')})")
                logger.info(f"   Response: {response_time:.0f}ms ({self.health_status.value})")
                return True
            else:
                raise RedisError("Ping failed")
                
        except Exception as e:
            self.status = ConnectionStatus.ERROR
            self.health_status = HealthStatus.UNHEALTHY
            self.metrics.failed_connections += 1
            logger.error(f"❌ Redis connection failed: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from Redis"""
        try:
            if self.client:
                self.client.close()
                self.client = None
            if self.pool:
                self.pool.disconnect()
                self.pool = None
            self.status = ConnectionStatus.DISCONNECTED
            logger.info("✅ Redis disconnected")
        except Exception as e:
            logger.error(f"❌ Error disconnecting: {e}")
    
    def is_healthy(self) -> bool:
        """Check Redis health"""
        current_time = time.time()
        
        if current_time < self._circuit_breaker_until:
            return False
        
        with self._health_check_lock:
            if current_time - self._last_health_check < RedisConfig.HEALTH_CHECK_INTERVAL:
                return self.health_status in [HealthStatus.HEALTHY, HealthStatus.DEGRADED]
            self._last_health_check = current_time
        
        try:
            if not self.client:
                return False
            
            start_time = time.time()
            result = self.client.ping()
            response_time = (time.time() - start_time) * 1000
            
            if result:
                self._update_response_time(response_time)
                self.health_status = (HealthStatus.HEALTHY if response_time < 100 
                                     else HealthStatus.DEGRADED if response_time < 500 
                                     else HealthStatus.UNHEALTHY)
                return True
            else:
                self.health_status = HealthStatus.UNHEALTHY
                return False
                
        except Exception:
            self.health_status = HealthStatus.UNHEALTHY
            self._circuit_breaker_until = current_time + 30
            return False
    
    def execute_with_retry(self, operation: callable, *args, max_retries: int = 3, **kwargs):
        """Execute Redis operation with retry"""
        for attempt in range(max_retries + 1):
            try:
                if not self.is_healthy() and attempt == 0:
                    if not self.connect():
                        continue
                
                start_time = time.time()
                result = operation(*args, **kwargs)
                response_time = (time.time() - start_time) * 1000
                self._update_response_time(response_time)
                return result
                
            except (RedisConnectionError, RedisTimeoutError) as e:
                self.metrics.failed_connections += 1
                if attempt < max_retries:
                    time.sleep(min(2 ** attempt, RedisConfig.RETRY_BACKOFF_MAX))
                    self.connect()
                else:
                    raise
            except Exception:
                raise
        
        return None
    
    def _update_response_time(self, response_time: float):
        """Update response time metrics"""
        self._response_times.append(response_time)
        if len(self._response_times) > self._max_response_history:
            self._response_times.pop(0)
        self.metrics.avg_response_time = sum(self._response_times) / len(self._response_times)
    
    # === QUEUE OPERATIONS ===
    
    def push_job(self, queue: str, job_data: Dict[str, Any]) -> bool:
        """Push job to queue"""
        try:
            job_json = json.dumps(job_data, ensure_ascii=False)
            result = self.execute_with_retry(self.client.lpush, queue, job_json)
            return bool(result)
        except Exception:
            return False
    
    def pop_job(self, queues: List[str], timeout: int = 5) -> Optional[tuple]:
        """Pop job from queues"""
        try:
            result = self.execute_with_retry(self.client.brpop, queues, timeout=timeout)
            if result:
                queue_name, job_json = result
                job_data = json.loads(job_json)
                return queue_name, job_data
            return None
        except Exception:
            return None
    
    def push_event(self, queue: str, event_data: Dict[str, Any]) -> bool:
        """Push event to queue"""
        try:
            event_json = json.dumps(event_data, ensure_ascii=False)
            result = self.execute_with_retry(self.client.lpush, queue, event_json)
            return bool(result)
        except Exception:
            return False
    
    def get_queue_length(self, queue: str) -> int:
        """Get queue length"""
        try:
            return self.execute_with_retry(self.client.llen, queue)
        except Exception:
            return 0
    
    # === LOCKING OPERATIONS ===
    
    def acquire_lock(self, lock_key: str, worker_id: str, ttl: int = 300) -> bool:
        """Acquire distributed lock"""
        try:
            result = self.execute_with_retry(
                self.client.set, lock_key, worker_id, nx=True, ex=ttl
            )
            return bool(result)
        except Exception:
            return False
    
    def release_lock(self, lock_key: str, worker_id: str) -> bool:
        """Release distributed lock"""
        lua_script = """
        if redis.call("GET", KEYS[1]) == ARGV[1] then
            return redis.call("DEL", KEYS[1])
        else
            return 0
        end
        """
        try:
            result = self.execute_with_retry(
                self.client.eval, lua_script, 1, lock_key, worker_id
            )
            return bool(result)
        except Exception:
            return False
    
    # === KEY-VALUE OPERATIONS ===
    
    def set_with_ttl(self, key: str, value: Any, ttl: int) -> bool:
        """Set key with TTL"""
        try:
            if isinstance(value, (dict, list)):
                value = json.dumps(value)
            result = self.execute_with_retry(self.client.setex, key, ttl, value)
            return bool(result)
        except Exception:
            return False
    
    def get_value(self, key: str, as_json: bool = False) -> Optional[Any]:
        """Get key value"""
        try:
            value = self.execute_with_retry(self.client.get, key)
            if value and as_json:
                return json.loads(value)
            return value
        except Exception:
            return None
    
    def exists(self, key: str) -> bool:
        """Check if key exists"""
        try:
            return bool(self.execute_with_retry(self.client.exists, key))
        except Exception:
            return False
    
    def delete_key(self, key: str) -> bool:
        """Delete key"""
        try:
            result = self.execute_with_retry(self.client.delete, key)
            return bool(result)
        except Exception:
            return False
    
    # === METRICS ===
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get connection metrics"""
        pool_stats = {}
        if self.pool:
            pool_stats = {
                'max_connections': self.pool.max_connections,
                'created_connections': getattr(self.pool, '_created_connections', 0),
                'available_connections': len(getattr(self.pool, '_available_connections', [])),
                'in_use_connections': len(getattr(self.pool, '_in_use_connections', []))
            }
        
        return {
            'status': self.status.value,
            'health': self.health_status.value,
            'connection_metrics': asdict(self.metrics),
            'pool_stats': pool_stats
        }

# === ENHANCED S3 MANAGER ===

class EnhancedS3Manager:
    """S3/MinIO manager with simplified logging and 403 handling"""
    
    def __init__(self):
        self.client: Optional[boto3.client] = None
        self.status = ConnectionStatus.DISCONNECTED
        self.metrics = ConnectionMetrics()
        logger.info("🔧 S3 Manager initialized")
    
    def connect(self) -> bool:
        """Establish S3/MinIO connection"""
        try:
            self.status = ConnectionStatus.CONNECTING
            logger.info(f"🔗 Connecting to S3/MinIO")
            
            config = Config(
                region_name=S3Config.REGION,
                retries={'max_attempts': S3Config.MAX_ATTEMPTS, 'mode': 'adaptive'},
                max_pool_connections=S3Config.MAX_POOL_CONNECTIONS,
                connect_timeout=30,
                read_timeout=60,
                s3={
                    'multipart_threshold': S3Config.MULTIPART_THRESHOLD,
                    'multipart_chunksize': S3Config.MULTIPART_CHUNKSIZE,
                    'use_accelerate_endpoint': False,
                    'addressing_style': 'path'
                }
            )
            
            endpoint_url = S3Config.ENDPOINT
            if not endpoint_url.startswith(('http://', 'https://')):
                endpoint_url = f"{'https' if S3Config.USE_SSL else 'http'}://{endpoint_url}"
            
            self.client = boto3.client(
                's3',
                endpoint_url=endpoint_url,
                aws_access_key_id=S3Config.ACCESS_KEY,
                aws_secret_access_key=S3Config.SECRET_KEY,
                config=config,
                use_ssl=S3Config.USE_SSL,
                verify=S3Config.VERIFY_SSL
            )
            
            # Test connection - but don't fail on 403
            try:
                start_time = time.time()
                self.client.head_bucket(Bucket=S3Config.BUCKET)
                response_time = (time.time() - start_time) * 1000
                logger.info(f"✅ Connected to S3/MinIO ({response_time:.0f}ms)")
            except ClientError as e:
                error_code = e.response.get('Error', {}).get('Code', 'Unknown')
                if error_code == '403':
                    # 403 is OK if we can still download/upload
                    logger.info(f"✅ Connected to S3/MinIO (limited permissions)")
                else:
                    raise
            
            self.status = ConnectionStatus.CONNECTED
            self.metrics.total_connections += 1
            self.metrics.last_success = time.time()
            return True
            
        except Exception as e:
            self.status = ConnectionStatus.ERROR
            self.metrics.failed_connections += 1
            logger.error(f"❌ S3/MinIO connection failed: {e}")
            return False
    
    def download_file_with_retry(self, s3_key: str, local_path: str, max_retries: int = 3) -> bool:
        """Download file - simplified logging, handles 403"""
        filename = os.path.basename(s3_key)
        
        for attempt in range(max_retries + 1):
            try:
                start_time = time.time()
                
                self.client.download_file(
                    Bucket=S3Config.BUCKET,
                    Key=s3_key,
                    Filename=local_path
                )
                
                download_time = time.time() - start_time
                file_size = os.path.getsize(local_path) if os.path.exists(local_path) else 0
                
                if file_size > 0:
                    speed_mbps = (file_size / 1024 / 1024) / max(download_time, 0.1)
                    logger.info(f"📥 Downloaded {filename} ({file_size:,} bytes) in {download_time:.2f}s ({speed_mbps:.1f} MB/s)")
                    return True
                else:
                    raise Exception("Empty file")
                
            except ClientError as e:
                error_code = e.response.get('Error', {}).get('Code', 'Unknown')
                if error_code == '403' and attempt == 0:
                    # 403 on first attempt is common due to HeadObject check, just retry
                    time.sleep(1)
                    continue
                elif attempt < max_retries:
                    time.sleep(min(2 ** attempt, 30))
                else:
                    logger.error(f"❌ Download failed: {filename} ({error_code})")
                    return False
            except Exception as e:
                if attempt >= max_retries:
                    logger.error(f"❌ Download failed: {filename}")
                    return False
                time.sleep(min(2 ** attempt, 30))
        
        return False
    
    def upload_file_with_retry(self, local_path: str, s3_key: str, max_retries: int = 3, 
                              content_type: str = 'image/webp', 
                              extra_metadata: Dict[str, str] = None) -> bool:
        """Upload file - simplified logging"""
        if not os.path.exists(local_path):
            logger.error(f"❌ File not found")
            return False
        
        file_size = os.path.getsize(local_path)
        if file_size == 0:
            logger.error(f"❌ File is empty")
            return False
        
        extra_args = {
            'ContentType': content_type,
            'CacheControl': 'max-age=31536000',
            'Tagging': 'public=yes&processed=yes',
        }
        
        if extra_metadata:
            extra_args['Metadata'] = extra_metadata
        
        for attempt in range(max_retries + 1):
            try:
                start_time = time.time()
                
                self.client.upload_file(
                    Filename=local_path,
                    Bucket=S3Config.BUCKET,
                    Key=s3_key,
                    ExtraArgs=extra_args
                )
                
                upload_time = time.time() - start_time
                speed_mbps = (file_size / 1024 / 1024) / max(upload_time, 0.1)
                
                # Show variant and filename only
                variant = os.path.dirname(s3_key).split('/')[-1]
                filename = os.path.basename(s3_key)
                logger.info(f"📤 Uploaded {variant}/{filename} ({file_size:,} bytes) in {upload_time:.2f}s ({speed_mbps:.1f} MB/s)")
                return True
                
            except Exception:
                if attempt >= max_retries:
                    logger.error(f"❌ Upload failed: {os.path.basename(s3_key)}")
                    return False
                time.sleep(min(2 ** attempt, 30))
        
        return False
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get S3 metrics"""
        return {
            'status': self.status.value,
            'connection_metrics': asdict(self.metrics)
        }

# === WORKER REGISTRY ===

class EnhancedWorkerRegistry:
    """Worker registry"""
    
    def __init__(self, redis_manager: EnhancedRedisManager):
        self.redis = redis_manager
        self.worker_info = WorkerInfo(
            worker_id=WorkerConfig.WORKER_ID,
            hostname=socket.gethostname(),
            pid=os.getpid(),
            version=WorkerConfig.WORKER_VERSION,
            started_at=time.time(),
            last_heartbeat=time.time()
        )
        logger.info(f"🏷️ Worker {self.worker_info.worker_id}")
    
    def register(self, jobs_processed: int = 0, jobs_failed: int = 0) -> bool:
        """Register/update worker"""
        try:
            self.worker_info.last_heartbeat = time.time()
            self.worker_info.jobs_processed = jobs_processed
            self.worker_info.jobs_failed = jobs_failed
            
            worker_data = asdict(self.worker_info)
            
            pipeline = self.redis.client.pipeline()
            pipeline.sadd(QueueConfig.WORKER_REGISTRY, self.worker_info.worker_id)
            pipeline.setex(
                f"{QueueConfig.WORKER_REGISTRY}:{self.worker_info.worker_id}",
                WorkerConfig.REGISTRATION_TTL,
                json.dumps(worker_data)
            )
            pipeline.execute()
            return True
            
        except Exception:
            return False
    
    def unregister(self) -> bool:
        """Unregister worker"""
        try:
            pipeline = self.redis.client.pipeline()
            pipeline.srem(QueueConfig.WORKER_REGISTRY, self.worker_info.worker_id)
            pipeline.delete(f"{QueueConfig.WORKER_REGISTRY}:{self.worker_info.worker_id}")
            pipeline.execute()
            logger.info(f"📝 Worker unregistered")
            return True
        except Exception:
            return False

# === JOB MANAGER ===

class EnhancedJobManager:
    """Job management"""
    
    def __init__(self, redis_manager: EnhancedRedisManager):
        self.redis = redis_manager
        self.worker_id = WorkerConfig.WORKER_ID
        logger.info("🔧 Job Manager initialized")
    
    def claim_job(self, job_uuid: str) -> bool:
        """Claim job with lock"""
        lock_key = f"job:lock:{job_uuid}"
        return self.redis.acquire_lock(lock_key, self.worker_id, WorkerConfig.JOB_LOCK_TTL)
    
    def release_job_lock(self, job_uuid: str) -> bool:
        """Release job lock"""
        lock_key = f"job:lock:{job_uuid}"
        return self.redis.release_lock(lock_key, self.worker_id)
    
    def set_job_outcome(self, job_uuid: str, outcome: Dict[str, Any]) -> bool:
        """Set job outcome"""
        outcome_key = f"job:outcome:{job_uuid}"
        return self.redis.set_with_ttl(outcome_key, outcome, WorkerConfig.OUTCOME_TTL)
    
    def get_job_outcome(self, job_uuid: str) -> Optional[Dict[str, Any]]:
        """Get job outcome"""
        outcome_key = f"job:outcome:{job_uuid}"
        return self.redis.get_value(outcome_key, as_json=True)
    
    def outcome_exists(self, job_uuid: str) -> bool:
        """Check if outcome exists"""
        outcome_key = f"job:outcome:{job_uuid}"
        done_key = f"job:done:{job_uuid}"
        return self.redis.exists(outcome_key) or self.redis.exists(done_key)
    
    def move_to_dlq(self, job_data: Dict[str, Any], error: str) -> bool:
        """Move to dead letter queue"""
        dlq_entry = {
            **job_data,
            'failed_at': time.time(),
            'error': error,
            'worker_id': self.worker_id
        }
        return self.redis.push_job(QueueConfig.DLQ, dlq_entry)
