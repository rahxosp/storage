# Quick Reference Card - GPU Worker

## 🚀 Deployment

```powershell
# Deploy from Windows PowerShell
cd D:\xampp3\htdocs\readershub\ext-esrgan-laravel\v13
.\deploy_fixes.ps1
```

## 📊 Monitoring

### View Live Logs
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'tail -f /home/image-conversion/v13/worker.log'
```

### Check Worker Status
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'ps aux | grep improved_main.py'
```

### View Last 100 Lines
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'tail -100 /home/image-conversion/v13/worker.log'
```

## 🔧 Control

### Start Worker
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4
cd /home/image-conversion/v13
nohup python3 improved_main.py > worker.log 2>&1 &
```

### Stop Worker
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'pkill -f improved_main.py'
```

### Restart Worker
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4
cd /home/image-conversion/v13
pkill -f improved_main.py
sleep 2
nohup python3 improved_main.py > worker.log 2>&1 &
```

## 🐛 Debugging

### Test S3 Connection
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4
cd /home/image-conversion/v13
python3 -c "from simple_improved_storage import EnhancedS3Manager; s = EnhancedS3Manager(); print('OK' if s.connect() else 'FAIL')"
```

### Test Redis Connection
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4
cd /home/image-conversion/v13
python3 -c "from simple_improved_storage import EnhancedRedisManager; r = EnhancedRedisManager(); print('OK' if r.connect() else 'FAIL')"
```

### Check Python Imports
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4
cd /home/image-conversion/v13
python3 -c "from simple_improved_storage import *; from improved_worker import *; print('All imports OK')"
```

### View System Resources
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'nvidia-smi'
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'free -h'
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'df -h'
```

## 📁 Files

### View File Sizes
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'ls -lh /home/image-conversion/v13/*.py'
```

### Check Log Size
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'du -h /home/image-conversion/v13/worker.log'
```

### Clear Old Logs
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'echo "" > /home/image-conversion/v13/worker.log'
```

## 🔍 Verification

### ✅ Worker Running?
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'pgrep -f improved_main.py && echo "Running" || echo "Not running"'
```

### ✅ Processing Jobs?
```bash
# Look for recent "Processing job" entries in logs
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'tail -50 /home/image-conversion/v13/worker.log | grep "Processing job"'
```

### ✅ Any Errors?
```bash
# Look for ERROR level logs
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'tail -100 /home/image-conversion/v13/worker.log | grep ERROR'
```

## 💾 Backup

### Backup Current Config
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'tar -czf /tmp/worker-backup-$(date +%Y%m%d).tar.gz /home/image-conversion/v13/'
scp -i "C:\Users\AJU\.ssh\vast" -P 42576 root@171.247.185.4:/tmp/worker-backup-*.tar.gz ./
```

## 📈 Performance Stats

### View Worker Metrics (from logs)
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'grep "Worker Metrics" /home/image-conversion/v13/worker.log | tail -5'
```

### Count Processed Jobs
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'grep "Successfully processed" /home/image-conversion/v13/worker.log | wc -l'
```

### Count Errors
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'grep "ERROR" /home/image-conversion/v13/worker.log | wc -l'
```

## 🆘 Emergency

### Kill All Python Workers
```bash
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4 'pkill -9 -f python3'
```

### Clear Redis Queue (DANGER!)
```bash
# Only use if absolutely necessary
ssh -i "C:\Users\AJU\.ssh\vast" -p 42576 root@171.247.185.4
redis-cli -h 152.53.142.224 -p 6379 -a 'BwswSeXhpFwcxSaQYwcq7DLj1qmvmz9PDT1D5Rr62CTTSWf1jIiaP17'
# Then: FLUSHDB (clears current database)
```

## 📞 Server Connection

### SSH Alias (Optional - Add to ~/.ssh/config)
```
Host gpu-worker
    HostName 171.247.185.4
    Port 42576
    User root
    IdentityFile C:\Users\AJU\.ssh\vast
```

After adding alias, use:
```bash
ssh gpu-worker 'tail -f /home/image-conversion/v13/worker.log'
```

## 🎯 Common Scenarios

### "Worker not processing jobs"
1. Check if worker is running: `ps aux | grep improved_main.py`
2. Check Redis connection: Test Redis connection command
3. View recent logs: `tail -50 worker.log`
4. Restart worker

### "Lots of errors in logs"
1. Check error type: `grep ERROR worker.log | tail -20`
2. Check S3 connection: Test S3 connection command
3. Check GPU status: `nvidia-smi`
4. May need to restart worker

### "Want to update code"
1. Stop worker: `pkill -f improved_main.py`
2. Upload new files via `deploy_fixes.ps1`
3. Deployment script auto-restarts worker
4. Verify with logs

---

**💡 Pro Tip**: Keep this file open in a text editor for quick copy-paste access!
