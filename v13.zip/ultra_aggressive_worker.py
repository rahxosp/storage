#!/usr/bin/env python3
"""
ULTRA-AGGRESSIVE ESRGAN Worker - Maximum GPU ROI
Optimized for per-minute GPU rental billing.
Every idle second costs money - this worker eliminates ALL idle time.

Features:
- Pre-fetch 4 jobs ahead (keep download pipeline full)
- Parallel variant processing (HD/SD/DS simultaneously, not sequential)
- Fire-and-forget async uploads (don't block GPU)
- Minimal overhead between jobs
- Aggressive memory management
"""

import os
import sys
import time
import threading
import queue
import gc
from typing import Dict, Optional, Any
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from dataclasses import dataclass, field

from improved_config import (
    WorkerConfig, QueueConfig, PerformanceConfig, 
    GRACEFUL_KILLER, logger
)
from improved_storage import (
    EnhancedRedisManager, EnhancedS3Manager,
    EnhancedWorkerRegistry, EnhancedJobManager
)
from worker import EnhancedWorker, WorkerState

@dataclass
class AggressivePipelineJob:
    """Job optimized for maximum throughput"""
    job_uuid: str
    job_data: Dict[str, Any]
    source_queue: str
    event_queue: str
    
    prepared_data: Optional[Dict] = None
    result_data: Optional[Dict] = None
    
    enqueued_at: float = field(default_factory=time.time)
    gpu_start: Optional[float] = None
    gpu_end: Optional[float] = None

class UltraAggressiveWorker(EnhancedWorker):
    """
    Ultra-aggressive worker for per-minute GPU billing.
    
    Philosophy: Keep GPU at 100% utilization at ALL times.
    Trade-offs: Uses more RAM, network bandwidth, and CPU.
    Result: Maximum images processed per dollar spent.
    """
    
    def __init__(self):
        super().__init__()
        
        # Aggressive pipeline queues
        self.download_queue = queue.Queue()
        self.gpu_queue = queue.Queue(maxsize=3)  # Increased buffer - always have jobs ready
        self.upload_queue = queue.Queue(maxsize=15)  # Larger upload buffer
        
        # Active tracking
        self.active_jobs: Dict[str, AggressivePipelineJob] = {}
        self.active_jobs_lock = threading.Lock()
        
        # Aggressive thread pools - optimized for slow network
        self.download_pool = ThreadPoolExecutor(
            max_workers=6,  # Increased for slow S3 - keep pipeline full
            thread_name_prefix="aggressive-download"
        )
        self.variant_pool = ThreadPoolExecutor(
            max_workers=6,  # Parallel variant processing (was sequential)
            thread_name_prefix="aggressive-variant"
        )
        self.upload_pool = ThreadPoolExecutor(
            max_workers=8,  # Increased for concurrent uploads
            thread_name_prefix="aggressive-upload"
        )
        
        # Pipeline control
        self.pipeline_running = False
        self.gpu_thread = None
        self.prefetch_thread = None
        
        # Aggressive metrics
        self.ultra_metrics = {
            'jobs_in_download': 0,
            'jobs_in_gpu': 0,
            'jobs_in_upload': 0,
            'total_gpu_time': 0.0,
            'total_pipeline_time': 0.0,
            'gpu_idle_time': 0.0,
            'last_gpu_finish': None,
            'max_concurrent_jobs': 0,
        }
        self.metrics_lock = threading.Lock()
        
        logger.info("🔥 ULTRA-AGGRESSIVE Worker initialized")
        logger.info("   💰 Optimized for per-minute GPU billing")
        logger.info("   Download workers: 6 (aggressive pre-fetch)")
        logger.info("   Variant workers: 6 (parallel HD/SD/DS)")
        logger.info("   Upload workers: 8 (fire-and-forget)")
        logger.info("   🎯 Goal: 95%+ GPU utilization")
    
    def download_stage_aggressive(self, pipeline_job: AggressivePipelineJob) -> bool:
        """Ultra-fast download with minimal overhead"""
        from utils import temporary_file, parse_s3_path, validate_image, convert_image_format
        
        job_uuid = pipeline_job.job_uuid
        job_data = pipeline_job.job_data
        success = False
        
        with self.metrics_lock:
            self.ultra_metrics['jobs_in_download'] += 1
        
        try:
            s3_path = job_data.get('s3Original', '')
            logger.info(f"⬇️  [{job_uuid}] Download stage started")
            
            # Fast path: parse and download
            parsed = parse_s3_path(s3_path)
            if not parsed:
                logger.error(f"❌ [{job_uuid}] Could not parse S3 path")
                return False
            
            # Download directly to memory (faster than temp file)
            with temporary_file(suffix='.tmp') as temp_input:
                if not self.s3_manager.download_file_with_retry(s3_path, temp_input):
                    logger.error(f"❌ [{job_uuid}] Download failed")
                    return False
                
                # Quick validation (don't be too picky for speed)
                is_valid, error_msg, needs_split = validate_image(temp_input)
                if not is_valid:
                    logger.error(f"❌ [{job_uuid}] Invalid: {error_msg}")
                    return False
                
                # Convert to PNG
                with temporary_file(suffix='.png') as temp_png:
                    if not convert_image_format(temp_input, temp_png):
                        logger.error(f"❌ [{job_uuid}] Conversion failed")
                        return False
                    
                    # Load into memory
                    with open(temp_png, 'rb') as f:
                        png_data = f.read()
            
            pipeline_job.prepared_data = {
                'job_uuid': job_uuid,
                'job_data': job_data,
                'parsed': parsed,
                'png_data': png_data,
                'needs_split': needs_split
            }
            
            # Immediately queue for GPU
            self.gpu_queue.put(pipeline_job)
            
            logger.info(f"✅ [{job_uuid}] Downloaded and queued for GPU")
            success = True
            return True
            
        except Exception as e:
            logger.error(f"❌ [{job_uuid}] Download error: {e}", exc_info=True)
            return False
        finally:
            with self.metrics_lock:
                if self.ultra_metrics['jobs_in_download'] > 0:
                    self.ultra_metrics['jobs_in_download'] -= 1
            
            # Cleanup on failure
            if not success:
                self.handle_failed_job(
                    job_uuid, job_data,
                    "Download failed",
                    pipeline_job.event_queue
                )
                with self.active_jobs_lock:
                    self.active_jobs.pop(job_uuid, None)
                GRACEFUL_KILLER.remove_job(job_uuid)
                self.job_manager.release_job_lock(job_uuid)
    
    def process_variant_single(self, upscaled_path: str, parsed: Dict, 
                               variant: str, resource_state: str) -> Optional[tuple]:
        """Process single variant (runs in parallel with other variants)"""
        from utils import temporary_file, resize_image_with_degradation, generate_variant_s3_path
        from config import LEGACY_VARIANT_MAPPING
        
        try:
            if variant == 'og':
                return None
            
            mapped = LEGACY_VARIANT_MAPPING.get(variant, variant)
            
            with temporary_file(suffix='.webp') as temp_variant:
                from config import VARIANT_WIDTHS, WEBP_QUALITIES
                width = VARIANT_WIDTHS.get(mapped, 800)
                quality = WEBP_QUALITIES.get(mapped, 80)
                
                if resize_image_with_degradation(upscaled_path, temp_variant, 
                                                width, quality, mapped, resource_state):
                    s3_variant_path = generate_variant_s3_path(parsed, mapped)
                    if s3_variant_path and self.s3_manager.upload_file_with_retry(temp_variant, s3_variant_path):
                        return (variant, s3_variant_path)
            return None
        except Exception as e:
            logger.error(f"❌ Variant {variant} error: {e}")
            return None
    
    def gpu_stage_aggressive(self, pipeline_job: AggressivePipelineJob) -> bool:
        """GPU processing with parallel variant generation"""
        from esrgan_processor import ESRGANProcessor
        from utils import temporary_file
        import psutil
        
        job_uuid = pipeline_job.job_uuid
        prepared_data = pipeline_job.prepared_data
        
        if not prepared_data:
            return False
        
        pipeline_job.gpu_start = time.time()
        
        # Track GPU idle
        with self.metrics_lock:
            if self.ultra_metrics['last_gpu_finish']:
                idle = pipeline_job.gpu_start - self.ultra_metrics['last_gpu_finish']
                self.ultra_metrics['gpu_idle_time'] += idle
                if idle > 0.5:  # Log significant gaps
                    logger.warning(f"⚠️  GPU idle for {idle:.2f}s - need more aggressive pre-fetch!")
            self.ultra_metrics['jobs_in_gpu'] += 1
        
        try:
            job_data = prepared_data['job_data']
            parsed = prepared_data['parsed']
            png_data = prepared_data['png_data']
            variants = job_data.get('variants', ['hd', 'sd', 'ds'])
            
            # Write PNG
            with temporary_file(suffix='.png') as temp_png:
                with open(temp_png, 'wb') as f:
                    f.write(png_data)
                
                # ESRGAN upscaling
                esrgan_processor = ESRGANProcessor(self.s3_manager)
                with temporary_file(suffix='.png') as temp_upscaled:
                    if not esrgan_processor.run_esrgan_with_fallback(temp_png, temp_upscaled):
                        return False
                    
                    # Resource state
                    memory = psutil.virtual_memory()
                    resource_state = 'CRITICAL' if memory.percent > 90 else 'HIGH' if memory.percent > 80 else 'NORMAL'
                    
                    # ⚡ PARALLEL VARIANT PROCESSING (KEY OPTIMIZATION)
                    # Instead of sequential HD→SD→DS, do all 3 simultaneously
                    variant_futures = {}
                    for variant in variants:
                        future = self.variant_pool.submit(
                            self.process_variant_single,
                            temp_upscaled, parsed, variant, resource_state
                        )
                        variant_futures[future] = variant
                    
                    # Collect results as they complete
                    variant_results = {}
                    for future in as_completed(variant_futures, timeout=30):
                        result = future.result()
                        if result:
                            variant, s3_path = result
                            variant_results[variant] = s3_path
                    
                    if not variant_results:
                        return False
            
            pipeline_job.gpu_end = time.time()
            gpu_time = pipeline_job.gpu_end - pipeline_job.gpu_start
            
            pipeline_job.result_data = {
                'job_uuid': job_uuid,
                'job_data': job_data,
                'variant_results': variant_results,
                'resource_state': resource_state,
                'processing_time': gpu_time
            }
            
            with self.metrics_lock:
                self.ultra_metrics['jobs_in_gpu'] -= 1
                self.ultra_metrics['total_gpu_time'] += gpu_time
                self.ultra_metrics['last_gpu_finish'] = pipeline_job.gpu_end
            
            logger.info(f"✅ [{job_uuid}] GPU completed in {gpu_time:.2f}s")
            
            # Fire-and-forget upload
            self.upload_queue.put(pipeline_job)
            return True
            
        except Exception as e:
            logger.error(f"❌ [{job_uuid}] GPU error: {e}")
            return False
        finally:
            with self.metrics_lock:
                if self.ultra_metrics['jobs_in_gpu'] > 0:
                    self.ultra_metrics['jobs_in_gpu'] -= 1
            
            # Aggressive memory cleanup after each GPU job
            gc.collect()
    
    def upload_stage_aggressive(self, pipeline_job: AggressivePipelineJob) -> bool:
        """Fire-and-forget upload - don't block GPU"""
        job_uuid = pipeline_job.job_uuid
        result_data = pipeline_job.result_data
        
        if not result_data:
            return False
        
        with self.metrics_lock:
            self.ultra_metrics['jobs_in_upload'] += 1
        
        try:
            job_data = result_data['job_data']
            s3_path = job_data.get('s3Original', '')
            
            # FINAL IDEMPOTENCY CHECK: Prevent duplicate result events
            # Check if outcome already exists (another duplicate might have finished first)
            if self.job_manager.outcome_exists(job_uuid):
                logger.warning(f"⏭️  [{job_uuid}] DUPLICATE: Outcome already exists, not sending result event")
                with self.active_jobs_lock:
                    self.active_jobs.pop(job_uuid, None)
                return True  # Still success, just don't send duplicate event
            
            # Prepare result
            result = {
                'status': 'completed',
                'jobUuid': job_uuid,
                'chapterId': job_data.get('chapterId', 0),
                'pageIndex': job_data.get('pageIndex', 0),
                's3Original': s3_path,
                'paths': result_data['variant_results'],
                'processing_time': result_data['processing_time'],
                'worker_id': self.worker_id,
                'resource_state': result_data['resource_state']
            }
            
            # Send result (fire-and-forget - don't wait)
            self.handle_job_result(job_uuid, result, pipeline_job.event_queue)
            
            # Calculate metrics
            total_time = time.time() - pipeline_job.enqueued_at
            with self.metrics_lock:
                self.ultra_metrics['total_pipeline_time'] += total_time
            
            # Cleanup
            with self.active_jobs_lock:
                self.active_jobs.pop(job_uuid, None)
            
            return True
            
        except Exception as e:
            logger.error(f"❌ [{job_uuid}] Upload error: {e}")
            return False
        finally:
            with self.metrics_lock:
                if self.ultra_metrics['jobs_in_upload'] > 0:
                    self.ultra_metrics['jobs_in_upload'] -= 1
    
    def gpu_coordinator_aggressive(self):
        """Aggressive GPU coordinator - never let GPU idle"""
        logger.info("🔥 Aggressive GPU coordinator started")
        
        while self.pipeline_running and not GRACEFUL_KILLER.kill_now:
            try:
                # Block until GPU work available (but check shutdown frequently)
                try:
                    pipeline_job = self.gpu_queue.get(timeout=0.1)
                except queue.Empty:
                    continue
                
                # Process immediately
                success = self.gpu_stage_aggressive(pipeline_job)
                
                if not success:
                    self.handle_failed_job(
                        pipeline_job.job_uuid,
                        pipeline_job.job_data,
                        "GPU processing failed",
                        pipeline_job.event_queue
                    )
                    with self.active_jobs_lock:
                        self.active_jobs.pop(pipeline_job.job_uuid, None)
                
            except Exception as e:
                logger.error(f"❌ GPU coordinator error: {e}")
                time.sleep(0.1)
        
        logger.info("🛑 Aggressive GPU coordinator stopped")
    
    def prefetch_coordinator(self):
        """Aggressively pre-fetch jobs to keep GPU queue full"""
        logger.info("🔥 Aggressive pre-fetch coordinator started")
        
        while self.pipeline_running and not GRACEFUL_KILLER.kill_now:
            try:
                # Keep GPU queue full (pre-fetch ahead)
                gpu_queue_size = self.gpu_queue.qsize()
                
                # If GPU queue is low, fetch more jobs aggressively
                if gpu_queue_size < 2:
                    # Get job from Redis
                    job_result = self.get_job_from_queue(timeout=1)
                    
                    if job_result:
                        source_queue, job_data = job_result
                        job_uuid = job_data.get('jobUuid', 'unknown')
                        
                        # CRITICAL: Idempotency checks BEFORE claiming
                        # 1. Check if job is already in our active jobs (duplicate in queue)
                        with self.active_jobs_lock:
                            if job_uuid in self.active_jobs:
                                logger.warning(f"⏭️  [{job_uuid}] DUPLICATE: Already in pipeline, ignoring")
                                continue
                        
                        # 2. Check if already completed in Redis
                        if self.job_manager.outcome_exists(job_uuid):
                            logger.info(f"✅ [{job_uuid}] DUPLICATE: Already completed, ignoring")
                            continue
                        
                        # 3. Claim job atomically (prevents other workers)
                        if not self.job_manager.claim_job(job_uuid):
                            logger.debug(f"⏭️  [{job_uuid}] Already claimed by another worker, skipping")
                            continue
                        
                        GRACEFUL_KILLER.add_job(job_uuid)
                        
                        event_queue = self.determine_event_queue(source_queue)
                        pipeline_job = AggressivePipelineJob(
                            job_uuid=job_uuid,
                            job_data=job_data,
                            source_queue=source_queue,
                            event_queue=event_queue
                        )
                        
                        with self.active_jobs_lock:
                            # Add to active jobs (already verified not duplicate above)
                            self.active_jobs[job_uuid] = pipeline_job
                            # Track max concurrent
                            current = len(self.active_jobs)
                            if current > self.ultra_metrics['max_concurrent_jobs']:
                                self.ultra_metrics['max_concurrent_jobs'] = current
                        
                        # Start download immediately
                        self.download_pool.submit(
                            self.download_stage_aggressive, pipeline_job
                        )
                else:
                    # Queue is full, brief pause
                    time.sleep(0.1)
                    
            except Exception as e:
                logger.error(f"❌ Pre-fetch coordinator error: {e}")
                time.sleep(0.5)
        
        logger.info("🛑 Pre-fetch coordinator stopped")
    
    def upload_coordinator(self):
        """Process uploads in background"""
        logger.info("🔥 Upload coordinator started")
        
        while self.pipeline_running and not GRACEFUL_KILLER.kill_now:
            try:
                try:
                    pipeline_job = self.upload_queue.get(timeout=0.5)
                except queue.Empty:
                    continue
                
                # Upload in background
                self.upload_pool.submit(self.upload_stage_aggressive, pipeline_job)
                
                # Cleanup
                GRACEFUL_KILLER.remove_job(pipeline_job.job_uuid)
                self.job_manager.release_job_lock(pipeline_job.job_uuid)
                
            except Exception as e:
                logger.error(f"❌ Upload coordinator error: {e}")
                time.sleep(0.5)
        
        logger.info("🛑 Upload coordinator stopped")
    
    def handle_failed_job(self, job_uuid: str, job_data: Dict, error: str, event_queue: str):
        """Handle failures"""
        result = {
            'status': 'failed',
            'jobUuid': job_uuid,
            'chapterId': job_data.get('chapterId', 0),
            'pageIndex': job_data.get('pageIndex', 0),
            's3Original': job_data.get('s3Original', ''),
            'error': error,
            'worker_id': self.worker_id
        }
        self.handle_job_result(job_uuid, result, event_queue)
    
    def run(self) -> bool:
        """Main loop for ultra-aggressive worker"""
        logger.info(f"🔥 Starting ULTRA-AGGRESSIVE Worker v{WorkerConfig.WORKER_VERSION}")
        logger.info("💰 Optimized for per-minute GPU billing - maximum throughput!")
        
        try:
            # Initialize
            if not self.initialize_managers():
                logger.error("❌ Initialization failed")
                return False
            
            self.state = WorkerState.IDLE
            self.pipeline_running = True
            
            # Start coordinators
            self.gpu_thread = threading.Thread(
                target=self.gpu_coordinator_aggressive,
                name="gpu-coordinator",
                daemon=True
            )
            self.gpu_thread.start()
            
            self.prefetch_thread = threading.Thread(
                target=self.prefetch_coordinator,
                name="prefetch-coordinator",
                daemon=True
            )
            self.prefetch_thread.start()
            
            upload_thread = threading.Thread(
                target=self.upload_coordinator,
                name="upload-coordinator",
                daemon=True
            )
            upload_thread.start()
            
            logger.info("🏃 Ultra-aggressive pipeline ready")
            logger.info("   🎯 Target: 95%+ GPU utilization")
            logger.info("   💵 Every idle second costs money - let's eliminate them!")
            
            # Monitor loop
            last_heartbeat = 0
            last_metrics = 0
            
            while not GRACEFUL_KILLER.kill_now:
                try:
                    current_time = time.time()
                    
                    # Health check
                    if not self.health_check():
                        logger.error("❌ Health check failed")
                        break
                    
                    # Heartbeat
                    if current_time - last_heartbeat > WorkerConfig.REGISTRATION_TTL / 2:
                        self.register_heartbeat()
                        last_heartbeat = current_time
                    
                    # Metrics every 30 seconds (more frequent for billing optimization)
                    if current_time - last_metrics > 30:
                        self.log_ultra_metrics()
                        last_metrics = current_time
                    
                    time.sleep(1)
                    
                except KeyboardInterrupt:
                    logger.info("⌨️ Keyboard interrupt")
                    GRACEFUL_KILLER.kill_now = True
                    break
                    
                except Exception as e:
                    logger.error(f"❌ Main loop error: {e}")
                    time.sleep(2)
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Fatal error: {e}")
            return False
            
        finally:
            self.pipeline_running = False
            
            logger.info("⏳ Draining pipeline...")
            time.sleep(3)
            
            logger.info("🛑 Shutting down pools...")
            self.download_pool.shutdown(wait=True)
            self.variant_pool.shutdown(wait=True)
            self.upload_pool.shutdown(wait=True)
            
            self.cleanup_resources()
            logger.info("👋 Ultra-aggressive worker shutdown complete")
    
    def log_ultra_metrics(self):
        """Log ultra-aggressive metrics"""
        with self.metrics_lock:
            m = self.ultra_metrics.copy()
        
        total_jobs = self.job_metrics.total_processed + self.job_metrics.total_failed
        
        if total_jobs > 0:
            avg_gpu = m['total_gpu_time'] / total_jobs
            avg_total = m['total_pipeline_time'] / total_jobs
            
            # GPU utilization (critical for billing!)
            total_time = time.time() - self.start_time
            gpu_util = (m['total_gpu_time'] / total_time * 100) if total_time > 0 else 0
            
            logger.info(f"🔥 ULTRA-AGGRESSIVE METRICS ({total_jobs} jobs)")
            logger.info(f"   💰 GPU Utilization: {gpu_util:.1f}% (billing efficiency!)")
            logger.info(f"   Active Jobs: Download={m['jobs_in_download']}, GPU={m['jobs_in_gpu']}, Upload={m['jobs_in_upload']}")
            logger.info(f"   Max Concurrent: {m['max_concurrent_jobs']} jobs in pipeline")
            logger.info(f"   Avg GPU Time: {avg_gpu:.2f}s")
            logger.info(f"   Avg Pipeline: {avg_total:.2f}s")
            logger.info(f"   GPU Idle: {m['gpu_idle_time']:.1f}s total ({m['gpu_idle_time']/total_jobs:.3f}s per job)")
            
            # Money calculation (approximate)
            if gpu_util > 90:
                logger.info(f"   💵 Excellent! 90%+ utilization = minimal wasted billing")
            elif gpu_util > 80:
                logger.info(f"   💵 Good! 80%+ utilization")
            else:
                logger.warning(f"   ⚠️  GPU utilization below 80% - money being wasted!")
            
            # Throughput
            jobs_per_hour = self.job_metrics.jobs_per_hour
            logger.info(f"   📊 Throughput: {jobs_per_hour:.0f} jobs/hour")
        
        with self.active_jobs_lock:
            logger.info(f"   Pipeline depth: {len(self.active_jobs)} jobs")
        
        self.log_metrics()

def main():
    """Main entry point"""
    exit_code = 0
    
    try:
        logger.info("🔥🔥🔥 ULTRA-AGGRESSIVE MODE 🔥🔥🔥")
        logger.info("💰 Optimized for per-minute GPU billing")
        logger.info("🎯 Goal: Maximum images per dollar spent")
        
        worker = UltraAggressiveWorker()
        success = worker.run()
        exit_code = 0 if success else 1
        
    except KeyboardInterrupt:
        logger.info("⌨️ Keyboard interrupt - shutting down...")
        exit_code = 0
        
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        exit_code = 1
    
    finally:
        logger.info(f"🔚 Ultra-aggressive worker exiting with code {exit_code}")
        sys.exit(exit_code)

if __name__ == "__main__":
    main()
